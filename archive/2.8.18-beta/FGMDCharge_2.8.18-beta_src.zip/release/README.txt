FGMDCharge / FD_ROUND V2 — 2.8.18-beta firmware artifact (BETA, not tested on hardware)

  FGMDCharge_FD_ROUND_V2.bin — application image for OTA slot ota_1 (0x1A0000),
                               the same file as release asset FGMDCharge_2.8.18-beta.bin
                               SHA256 f89e48b64d907fdd125fd2168da8c5d02d4b4ee42e371c1500903370f84cca93

A fresh build writes build/FD_ROUND_V2.bin. Flash it with
  python tools/flash_app_to_ota1.py --port COMx --app build/FD_ROUND_V2.bin
Do not flash a whole-chip image and do not erase the chip if the factory image must stay.
