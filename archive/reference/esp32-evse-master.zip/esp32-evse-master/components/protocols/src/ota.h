#ifndef OTA_H
#define OTA_H

#include <esp_err.h>
#include <stdbool.h>

void ota_init(void);

void ota_get_channel(char* value, size_t value_size);

void ota_set_channel(const char* value);

esp_err_t ota_get_available(char* version, size_t version_size, char** path);

#endif /* OTA_H */