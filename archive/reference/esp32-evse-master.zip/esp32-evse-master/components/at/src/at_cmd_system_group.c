#include <esp_chip_info.h>
#include <esp_ota_ops.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <string.h>
#include <sys/time.h>

#include "cat.h"
#include "schedule_restart.h"
#include "scheduler.h"
#include "temp_sensor.h"
#include "vars.h"

static cat_return_state cmd_rst_run(const struct cat_command* cmd)
{
    schedule_restart();

    return CAT_RETURN_STATE_OK;
}

static int vars_chip_chip_cores_revision_read(const struct cat_variable* var)
{
    esp_chip_info_t chip_info;
    esp_chip_info(&chip_info);

    strlcpy(var_str32_1, CONFIG_IDF_TARGET, sizeof(var_str32_1));
    var_u8_1 = chip_info.cores;
    var_u16_1 = chip_info.revision;

    return 0;
}

static struct cat_variable vars_chip[] = {
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_1,
        .data_size = sizeof(var_str32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = vars_chip_chip_cores_revision_read,
    },
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u8_1,
        .data_size = sizeof(var_u8_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
    },
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u16_1,
        .data_size = sizeof(var_u16_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
    },
};

static int vars_heap_read(const struct cat_variable* var)
{
    multi_heap_info_t heap_info;
    heap_caps_get_info(&heap_info, MALLOC_CAP_INTERNAL);

    var_u32_1 = heap_info.total_allocated_bytes;
    var_u32_2 = heap_info.total_free_bytes + heap_info.total_allocated_bytes;

    return 0;
}

static struct cat_variable vars_heap[] = {
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u32_1,
        .data_size = sizeof(var_u32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = vars_heap_read,
    },
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u32_2,
        .data_size = sizeof(var_u32_2),
        .access = CAT_VAR_ACCESS_READ_ONLY,
    },

};

static int var_ver_read(const struct cat_variable* var)
{
    const esp_app_desc_t* app_desc = esp_app_get_description();

    strlcpy(var_str32_1, app_desc->version, sizeof(var_str32_1));

    return 0;
}

static struct cat_variable vars_ver[] = {
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_1,
        .data_size = sizeof(var_str32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = var_ver_read,
    },
};

static int var_idf_ver_read(const struct cat_variable* var)
{
    const esp_app_desc_t* app_desc = esp_app_get_description();

    strlcpy(var_str32_1, app_desc->idf_ver, sizeof(var_str32_1));

    return 0;
}

static struct cat_variable vars_idf_ver[] = {
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_1,
        .data_size = sizeof(var_str32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = var_idf_ver_read,
    },
};

static int var_buildtime_date_time_read(const struct cat_variable* var)
{
    const esp_app_desc_t* app_desc = esp_app_get_description();

    strlcpy(var_str32_1, app_desc->date, sizeof(var_str32_1));
    strlcpy(var_str32_2, app_desc->time, sizeof(var_str32_2));

    return 0;
}

static struct cat_variable vars_buildtime[] = {
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_1,
        .data_size = sizeof(var_str32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = var_buildtime_date_time_read,
    },
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_2,
        .data_size = sizeof(var_str32_2),
        .access = CAT_VAR_ACCESS_READ_ONLY,
    },
};

static int vars_temperature_read(const struct cat_variable* var)
{
    var_u8_1 = temp_sensor_get_count();
    var_i32_1 = temp_sensor_get_high();
    var_i32_2 = temp_sensor_get_low();

    return 0;
}

static struct cat_variable vars_temperature[] = {
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u8_1,
        .data_size = sizeof(var_u8_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = vars_temperature_read,
    },
    {
        .type = CAT_VAR_INT_DEC,
        .data = &var_i32_1,
        .data_size = sizeof(var_i32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
    },
    {
        .type = CAT_VAR_INT_DEC,
        .data = &var_i32_2,
        .data_size = sizeof(var_i32_2),
        .access = CAT_VAR_ACCESS_READ_ONLY,
    },
};

static int var_tz_read(const struct cat_variable* var)
{
    scheduler_get_timezone(var_str32_1, sizeof(var_str32_1));

    return 0;
}

static int var_tz_write(const struct cat_variable* var, const size_t write_size)
{
    return scheduler_set_timezone(var_str32_1) != ESP_OK;
}

static struct cat_variable vars_tz[] = {
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_1,
        .data_size = sizeof(var_str32_1),
        .access = CAT_VAR_ACCESS_READ_WRITE,
        .read = var_tz_read,
        .write = var_tz_write,
    },
};

static int var_tzrule_read(const struct cat_variable* var)
{
    strlcpy(var_str32_1, getenv("TZ"), sizeof(var_str32_1));

    return 0;
}

static struct cat_variable vars_tzrule[] = {
    {
        .type = CAT_VAR_BUF_STRING,
        .data = var_str32_1,
        .data_size = sizeof(var_str32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = var_tzrule_read,
    },
};

static int var_time_read(const struct cat_variable* var)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    var_u64_1 = tv.tv_sec;

    return 0;
}

static int var_time_write(const struct cat_variable* var, const size_t write_size)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    tv.tv_sec = var_u64_1;
    settimeofday(&tv, NULL);

    return 0;
}

static struct cat_variable vars_time[] = {
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u64_1,
        .data_size = sizeof(var_u64_1),
        .access = CAT_VAR_ACCESS_READ_WRITE,
        .read = var_time_read,
        .write = var_time_write,
    },
};

static int var_uptime_read(const struct cat_variable* var)
{
    var_u32_1 = esp_timer_get_time() / 1000000;

    return 0;
}

static struct cat_variable vars_uptime[] = {
    {
        .type = CAT_VAR_UINT_DEC,
        .data = &var_u32_1,
        .data_size = sizeof(var_u32_1),
        .access = CAT_VAR_ACCESS_READ_ONLY,
        .read = var_uptime_read,
    },
};

static struct cat_command cmds[] = {
    {
        .name = "+RST",
        .run = cmd_rst_run,
    },
    {
        .name = "+CHIP",
        .var = vars_chip,
        .var_num = sizeof(vars_chip) / sizeof(vars_chip[0]),
    },
    {
        .name = "+HEAP",
        .var = vars_heap,
        .var_num = sizeof(vars_heap) / sizeof(vars_heap[0]),
    },
    {
        .name = "+VER",
        .var = vars_ver,
        .var_num = sizeof(vars_ver) / sizeof(vars_ver[0]),
    },
    {
        .name = "+IDFVER",
        .var = vars_idf_ver,
        .var_num = sizeof(vars_idf_ver) / sizeof(vars_idf_ver[0]),
    },
    {
        .name = "+BUILDTIME",
        .var = vars_buildtime,
        .var_num = sizeof(vars_buildtime) / sizeof(vars_buildtime[0]),
    },
    {
        .name = "+TEMP",
        .var = vars_temperature,
        .var_num = sizeof(vars_temperature) / sizeof(vars_temperature[0]),
    },
    {
        .name = "+TZ",
        .var = vars_tz,
        .var_num = sizeof(vars_tz) / sizeof(vars_tz[0]),
    },
    {
        .name = "+TZRULE",
        .var = vars_tzrule,
        .var_num = sizeof(vars_tzrule) / sizeof(vars_tzrule[0]),
    },
    {
        .name = "+TIME",
        .var = vars_time,
        .var_num = sizeof(vars_time) / sizeof(vars_time[0]),
    },
    {
        .name = "+UPTIME",
        .var = vars_uptime,
        .var_num = sizeof(vars_uptime) / sizeof(vars_uptime[0]),
    },
};

struct cat_command_group at_cmd_system_group = {
    .cmd = cmds,
    .cmd_num = sizeof(cmds) / sizeof(cmds[0]),
};
