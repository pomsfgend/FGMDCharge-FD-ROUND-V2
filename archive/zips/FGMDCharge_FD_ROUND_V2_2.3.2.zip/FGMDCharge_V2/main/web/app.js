(() => {
  const $ = (id) => document.getElementById(id);
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  const MAX_OTA = 0x190000;

  async function api(path, opt) {
    const r = await fetch(path, Object.assign({ headers: { "Accept": "application/json" } }, opt || {}));
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.json();
  }

  function paint(s) {
    $("conn").textContent = "ONLINE";
    $("conn").classList.add("on");
    set("voltage", s.voltage_v != null ? Number(s.voltage_v).toFixed(1) : "—");
    set("current", s.current_a != null ? Number(s.current_a).toFixed(1) : "—");
    set("power", s.power_w != null ? Math.round(s.power_w) : "—");
    set("time", s.time_min != null ? s.time_min : "—");
    set("stage", s.stage || "—");
    set("relays", "A"+(s.relay_a||0)+" B"+(s.relay_b||0));
    set("session", s.session_active ? "ON" : "OFF");
    set("permit", s.permit || "—");
    set("ccsStatus", s.ccs || "—");
    set("can", s.can || "—");
    set("limitsV", s.limit_v || "—");
    set("limitsI", s.limit_i || "—");
    set("request", s.request || "—");
    set("mode", s.mode || "—");
    set("mainState", s.main_state || "—");
    set("subState", s.sub_state != null ? s.sub_state : "—");
    set("relayA", s.relay_a || "OFF");
    set("relayB", s.relay_b || "OFF");
    set("version", s.version || "—");
    set("cpuTemp", s.cpu_temp_c != null ? Number(s.cpu_temp_c).toFixed(1) + " °C" : "—");
    set("heap", s.heap != null ? Math.round(s.heap / 1024) + " KB" : "—");
    set("wifi", s.wifi || "—");
    set("txState", s.tx_enabled ? "ON" : "OFF");
  }

  async function tick() {
    try {
      paint(await api("/api/status"));
    } catch (e) {
      $("conn").textContent = "OFFLINE";
      $("conn").classList.remove("on");
    }
  }

  async function loadCan() {
    try {
      const d = await api("/api/can");
      const tb = $("frames");
      if (!d.frames || !d.frames.length) {
        tb.innerHTML = '<tr><td colspan="4" class="empty">Нет кадров</td></tr>';
        return;
      }
      tb.innerHTML = d.frames.map(f =>
        `<tr><td>${f.t || ""}</td><td>${f.id || ""}</td><td>${f.dlc || ""}</td><td><code>${f.data || ""}</code></td></tr>`
      ).join("");
    } catch (_) {}
  }

  function otaUpload(file) {
    return new Promise((resolve, reject) => {
      if (file.size > MAX_OTA) {
        reject(new Error("file larger than 0x190000"));
        return;
      }
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/ota", true);
      xhr.timeout = 120000;
      xhr.setRequestHeader("Content-Type", "application/octet-stream");
      xhr.upload.onprogress = (ev) => {
        if (!ev.lengthComputable) return;
        const pct = Math.min(100, Math.round((ev.loaded / ev.total) * 100));
        $("bar").style.width = pct + "%";
        $("otaText").textContent = "Загрузка " + pct + "%";
      };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.responseText);
        else reject(new Error("HTTP " + xhr.status));
      };
      xhr.onerror = () => reject(new Error("network"));
      xhr.ontimeout = () => reject(new Error("timeout"));
      xhr.send(file);
    });
  }

  $("startBtn") && $("startBtn").addEventListener("click", () => api("/api/start", { method: "POST" }).catch(() => {}));
  $("stopBtn") && $("stopBtn").addEventListener("click", () => api("/api/stop", { method: "POST" }).catch(() => {}));
  $("txBtn") && $("txBtn").addEventListener("click", () => api("/api/tx_enable", { method: "POST" }).then(tick).catch(() => {}));
  $("rebootBtn") && $("rebootBtn").addEventListener("click", () => api("/api/reboot", { method: "POST" }).catch(() => {}));
  $("refreshCan") && $("refreshCan").addEventListener("click", loadCan);

  $("otaBtn") && $("otaBtn").addEventListener("click", async () => {
    const f = $("otaFile").files && $("otaFile").files[0];
    if (!f) { $("otaText").textContent = "Выберите .bin"; return; }
    $("otaText").textContent = "Загрузка…";
    $("bar").style.width = "0%";
    try {
      await otaUpload(f);
      $("bar").style.width = "100%";
      $("otaText").textContent = "OK — перезагрузка (лимит 0x190000)";
    } catch (e) {
      $("otaText").textContent = "Сбой: " + e.message;
    }
  });

  tick();
  loadCan();
  setInterval(tick, 1000);
  setInterval(loadCan, 3000);
})();
