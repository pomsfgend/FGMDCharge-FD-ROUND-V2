const $=(id)=>document.getElementById(id);
let pick="";
document.querySelectorAll(".nav:not(.dim)").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("on"));
  b.classList.add("on");
  document.querySelectorAll("main section").forEach(s=>s.classList.add("hide"));
  $(b.dataset.tab).classList.remove("hide");
});
async function tick(){
  try{
    const s=await (await fetch("/api/status?t="+Date.now())).json();
    const live=s.ccs_voltage_0p1v>0;
    $("v").textContent=live?(s.ccs_voltage_0p1v/10).toFixed(0)+" В":"--";
    $("a").textContent=live?(Math.abs(s.ccs_current_0p1a)/10).toFixed(1)+" А":"--";
    $("p").textContent=live?(s.power_w||0)+" Вт":"--";
    $("soc").textContent=(s.soc||0)+" %";
    $("st").textContent=s.main_state_name||"нет сессии";
    $("stage").textContent=s.stage||"--";
    $("proto").textContent=s.protocol||"GB/T DC";
    $("rel").textContent=(s.relay_a||0)+" / "+(s.relay_b||0);
    $("ch").textContent=s.ap_channel||"--";
    $("sta").textContent=s.ap_clients||0;
    $("sip").textContent=s.sta_ip||"--";
    $("ver").textContent=s.version||"2.4.6";
    $("fw").textContent=s.version||"2.4.6";
    $("frame").textContent=(s.last_id||"--")+" "+(s.last_data||"");
    $("xchg").textContent=s.charger_online?("кадры "+s.rx_count+" / "+s.tx_count):"тишина";
    const vmin=s.cml_min_voltage_0p1v?(s.cml_min_voltage_0p1v/10).toFixed(0):"--";
    const vmax=s.cml_max_voltage_0p1v?(s.cml_max_voltage_0p1v/10).toFixed(0):"--";
    const imax=s.cml_max_current_0p1a?(Math.abs(s.cml_max_current_0p1a)/10).toFixed(0):"--";
    $("lim").textContent=vmin+"–"+vmax+" В, до "+imax+" А";
    $("req").textContent=((s.bcl_voltage_0p1v||2400)/10).toFixed(0)+" В / "+(Math.abs(s.bcl_current_0p1a||500)/10).toFixed(0)+" А";
  }catch(e){}
}
setInterval(tick,1000); tick();
$("set").onsubmit=async(e)=>{e.preventDefault();
  await fetch("/api/setpoints",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"v="+$("vv").value+"&i="+$("ii").value+"&soc="+$("ss").value});
};
let t0=0; $("hold").onpointerdown=()=>t0=Date.now();
$("hold").onpointerup=async()=>{ if(Date.now()-t0>700) await fetch("/api/stop",{method:"POST"}); };
$("scan").onclick=async()=>{
  const r=await (await fetch("/api/wifi/scan")).json();
  $("nets").innerHTML="";
  (r.nets||[]).forEach(n=>{
    const li=document.createElement("li"); li.textContent=n;
    li.onclick=()=>{pick=n; document.querySelectorAll("#nets li").forEach(x=>x.classList.remove("on")); li.classList.add("on");};
    $("nets").appendChild(li);
  });
};
$("join").onclick=async()=>{
  await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sta_ssid:pick,sta_pass:$("pw").value})});
};
$("ota").onclick=()=>{
  const f=$("bin").files[0]; if(!f||f.size>0x190000) return;
  const xhr=new XMLHttpRequest(); xhr.timeout=120000; xhr.open("POST","/api/ota");
  xhr.upload.onprogress=(e)=>{ if(e.lengthComputable) $("bar").value=e.loaded/e.total*100; };
  xhr.send(f);
};
