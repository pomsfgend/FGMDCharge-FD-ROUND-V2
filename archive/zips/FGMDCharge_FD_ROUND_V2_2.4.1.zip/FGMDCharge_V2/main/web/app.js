const $ = (id) => document.getElementById(id);
document.querySelectorAll("nav button").forEach((b) => b.onclick = () => {
  document.querySelectorAll("nav button").forEach((x) => x.classList.remove("on"));
  b.classList.add("on");
  document.querySelectorAll("main section").forEach((s) => s.classList.add("hide"));
  $(b.dataset.tab).classList.remove("hide");
});
["vs","is","sos","br"].forEach((id) => $(id).oninput = () => {
  const map = {vs:"vv", is:"ii", sos:"ss", br:"brv"};
  $(map[id]).textContent = $(id).value;
});
$("apply").onclick = async () => {
  await fetch("/api/setpoints", {method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body: "v="+$("vs").value+"&i="+$("is").value+"&soc="+$("sos").value});
};
$("ota").onclick = () => {
  const f = $("bin").files[0];
  if (!f || f.size > 0x190000) return;
  const xhr = new XMLHttpRequest();
  xhr.timeout = 120000;
  xhr.open("POST", "/api/ota");
  xhr.upload.onprogress = (e) => { if (e.lengthComputable) $("bar").value = e.loaded / e.total * 100; };
  xhr.send(f);
};
async function tick() {
  try {
    const s = await (await fetch("/api/status")).json();
    const live = s.ccs_voltage_0p1v > 0;
    $("v").textContent = live ? (s.ccs_voltage_0p1v/10).toFixed(0)+" V" : "--";
    $("a").textContent = live ? (Math.abs(s.ccs_current_0p1a)/10).toFixed(1)+" A" : "--";
    $("p").textContent = live ? (s.power_w||0)+" W" : "--";
    $("soc").textContent = (s.soc||0)+"%";
    $("kwh").textContent = ((s.csd_energy_0p1kwh||0)/10).toFixed(2)+" кВт·ч";
    $("proto").textContent = s.protocol || "--";
    $("rel").textContent = (s.relay_a||0)+" / "+(s.relay_b||0);
    $("pill").textContent = s.main_state_name || "нет сессии";
    $("fw").textContent = s.version || "2.4.1";
  } catch (e) {}
}
setInterval(tick, 1000); tick();
