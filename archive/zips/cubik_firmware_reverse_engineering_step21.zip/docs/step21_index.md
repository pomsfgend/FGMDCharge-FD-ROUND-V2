# Step 21 Index

**Focus:** Consolidated reconstruction baseline — single authoritative model for porting/replacement firmware.

## New documents

- `step21_consolidated_reconstruction_baseline.md`
- `reconstruction_baseline_step21.json`
- `src/reconstruction/relay_and_state_baseline.c`
- `step21_index.md`

## Key outcome

All CONFIRMED hardware, state machine, relay sequence, CAN IDs, BLE overrides, and fail-safe rules are now in one place. Residual items (GPIO7 LOW xref, ADC primary unit, LEDC duty) are listed honestly and do not block a correct charging-path reconstruction if fail-safe rules are followed.

## Next

Step 22+: when full RISC-V xref is available — close residual call-sites; otherwise proceed to implement reconstruction against this baseline.
