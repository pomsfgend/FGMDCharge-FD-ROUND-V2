# ПРОХОД 21 — Consolidated Reconstruction Baseline

**Дата:** 2026-10-06  
**Фокус:** Единая базовая модель для реконструкции прошивки. Все подтверждённые факты, все HIGH-гипотезы, все residual gaps в одном месте. Дизассемблерный residual sweep ограничен инструментами среды; новые callers без бинарного следа не выдумываются.

## 1. Аппаратная база [CONFIRMED]

| Подсистема | Конфигурация |
|------------|--------------|
| MCU | ESP32-C3, ESP-IDF ~5.0.9, FreeRTOS |
| LCD | ILI9341 (или совместимый), SPI host1, MOSI=5, SCLK=19, CS=4, DC=18, RST=-1, 20 MHz, logical 240×280, LVGL tick 2 ms |
| Touch | CST816x @ I2C 0x15, SDA=1, SCL=8, 100 kHz, polling (no IRQ GPIO found) |
| CAN | TWAI, TX=10, RX=9, 250 kbit/s, extended 29-bit IDs, J1939/GB/T transport |
| BLE | GATTS, service 0xFFE0, chars 0xFFE1/FFE2/FFE3, name default `q7FGMDCharge` / NVS `BLEname` |
| ADC | GPIO0 → ADC1 CH0 oneshot + filter |
| PWM | GPIO3 → LEDC CH0 ~60 kHz 10-bit |
| Relays | GPIO6 + GPIO7 (sequenced) |
| Strapping | GPIO2 init HIGH — **never drive as output** |

## 2. FreeRTOS tasks [CONFIRMED]

| Task | Role |
|------|------|
| `myTask_CAN` | TWAI RX/TX + central state machine `0x4200C078` every loop |
| `myTask_BLE` | GATTS events + application command dispatcher |
| `myTask_lcd` | LVGL + UI |
| `myTask_Timer` | periodic / data producer path |

## 3. GB/T State Machine [CONFIRMED core]

**Timebase:** 10 ms (`function_B910(10)`).

**Main state:** `0x3FCA0B1D` (values 0..7).

| State | Name | TX (key) | Relay action | Notes |
|------:|------|----------|--------------|-------|
| 0 | IDLE_RESET | — | both OFF (init) | full clear |
| 1 | HANDSHAKE_INIT | — | — | immediate → 2 |
| 2 | WAIT_CRM | BHM `0x182756F4`, BRM | — | wait CRM[0]==0xAA |
| 3 | PARAM_CONFIG | BCP `0x180656F4` | — | wait CTS+CML |
| 4 | READY_WAIT_CRO | BRO `0x100956F4` data0=0xAA | **GPIO6=HIGH** | wait CRO[0]==0xAA; substate→3 |
| 5 | CHARGING | BCL, BSM, BCS | after **10 s** + substate==3: **GPIO6=LOW, GPIO7=HIGH** | one-shot hand-off |
| 6 | STOP | BST `0x101956F4` | GPIO6 usually LOW | counter ≤9, ~1 s |
| 7 | FINALIZE | BSD / optional BEM | expected both OFF | timeout 5 s → idle |

**Substate / application byte:** `0x3FCA0B0C` (and/or `0x3FCA0B15` in earlier docs).  
Values 2/3/4/5 track internal phase; BLE can force 3 or 6.

## 4. Relay model [CONFIRMED sequence, residual LOW path]

```
Wrappers:
  0x4200C870 → GPIO6 = 1
  0x4200C882 → GPIO6 = 0
  0x4200C894 → GPIO7 = 1
  0x4200C8A6 → GPIO7 = 0

Confirmed call sites:
  State4          → 0x4200C870
  State5+10s+sub3 → 0x4200C882 then 0x4200C894
  BLE 0x66=0      → 0x4200C882 + write substate 6
  BLE 0x66=1      → 0x4200C870 + write substate 3
  BOOT            → GPIO6=0, GPIO7=0, GPIO2=1

Residual:
  No CONFIRMED caller of 0x4200C8A6 outside init.
  Reconstruction MUST force GPIO7=0 on stop/error/idle (fail-safe).
```

**Physical interpretation [HIGH]:** sequenced contactors — GPIO6 prepares, after 10 s settle GPIO7 engages main power path to the two ~65.7 V / 7 A chargers.

## 5. CAN message map (core) [CONFIRMED IDs + key fields]

### RX (charger → vehicle/adapter)

| ID | Msg | Key handling |
|----|-----|--------------|
| `0x1826F456` | CHM | timestamp |
| `0x1801F456` | CRM | timestamp; byte0 → recognition (0xAA) |
| `0x1807F456` | CTS | timestamp |
| `0x1808F456` | CML | limits; current encoding /10 − 400 |
| `0x100AF456` | CRO | timestamp; byte0 == 0xAA gate |
| `0x1812F456` | CCS | V = raw/10; I = raw/10 − 400 |
| `0x101AF456` | CST | timestamp |
| `0x181DF456` | CSD | timestamp |
| `0x081FF456` | CEM | timestamp / error |

### TX (adapter/BMS → charger)

| ID | Msg | Notes |
|----|-----|-------|
| `0x182756F4` | BHM | 2-byte, ~200 ms gate |
| `0x180256F4` | BRM | long transport |
| `0x180656F4` | BCP | long transport; uses `0x3FCA0A80`, `0x3FCA0AA8` |
| `0x100956F4` | BRO | data[0]=0xAA |
| `0x181056F4` | BCL | periodic in charging |
| `0x181356F4` | BSM | periodic |
| `0x181156F4` | BCS | periodic; current from `0x3FC9820C` |
| `0x101956F4` | BST | stop |
| `0x081E56F4` | BEM | optional error |

Transport: RTS/CTS/EOM multi-frame for BRM/BCP (`0x1CEC56F4` / `0x1CEB56F4` family).

## 6. Key RAM globals (reconstruction-oriented)

| Address | Role | Confidence |
|---------|------|------------|
| `0x3FCA0B1D` | main charging state 0..7 | CONFIRMED |
| `0x3FCA0B0C` | app/protocol substate; BLE target | HIGH |
| `0x3FCA0B15` | internal substate 2/3/4/5 | HIGH |
| `0x3FC9820C` | signed current source for BCS/BRM | CONFIRMED |
| `0x3FCA0AA8` | voltage-related eng. value (0.1 V class) | HIGH |
| `0x3FCA0A80` | voltage/limit related for BCP | HIGH |
| `0x3FCA0AE8` | 32-bit time/energy accumulator | HIGH |
| `0x3FCA0C04` | primary ADC filtered result | CONFIRMED runtime |
| `0x3FCA0C08` | secondary from `0x3FCA0AA8` | CONFIRMED runtime |
| `0x3FC981B0` | 16-byte identity/config block | CONFIRMED |
| `0x3FC98170` | 64-byte status/telemetry packet | CONFIRMED |

## 7. ADC [CONFIRMED path, unit partial]

```
GPIO0 → ADC1_CH0 → oneshot → 0x4200D0C4
  IIR-like: acc += sample; acc -= acc>>6
  scale → 0x3FCA0C04          (unit UNKNOWN)
  secondary from 0x3FCA0AA8 → 0x3FCA0C08  (voltage-linked)
```

`0x3FCA0AA8` also fed by CCS RX path and BLE `0x0E`, consumed by BCP — treat as **voltage setpoint/measurement** in reconstruction.

## 8. BLE application commands (subset) [CONFIRMED]

| Cmd | Effect |
|-----|--------|
| `0x66` | val0 → GPIO6 LOW + substate 6; val1 → GPIO6 HIGH + substate 3 |
| `0x0D` | substate = 6 |
| `0x0E` | bytes → `0x3FCA0A88`, /10 → `0x3FCA0AA8` |
| `0x09` | stores to `0x3FCA0A80` area |
| `0x07` | factory init `0x4200930E` |
| `0x03`/`0x08` | copy config / rebuild Alldata |

OTA path exists (`esp_ota_*`, partitions ota_0/ota_1).

## 9. Reconstruction rules (must-follow)

1. **Never drive GPIO2** as a normal output.  
2. **Relay sequence:** State4 → GPIO6=1; only after 10000 ms in State5 with substate==3 → GPIO6=0, GPIO7=1.  
3. **Fail-safe:** any transition to idle/stop/error → GPIO6=0 **and** GPIO7=0.  
4. **BLE override** must only affect GPIO6 + substate 3/6 (do not let BLE directly drive GPIO7).  
5. **Timebase** of SM = 10 ms.  
6. **LVGL tick** = 2 ms.  
7. **CAN** = 250 kbit/s, extended IDs, source/dest filtering 0x56/0xF4 as observed.  
8. Treat `0x3FCA0AA8` as voltage-related for UI and BCP.

## 10. Residual gaps (honest)

| Item | Status |
|------|--------|
| Exact file-offset mapping of all `jal` to `0x4200C8A6` | Residual — needs full RISC-V xref |
| Complete store list into `0x3FCA0B00..B30` | Residual |
| Readers of `0x3FCA0C04` → UI widgets | Residual |
| LEDC duty update call-sites / physical load on GPIO3 | Residual |
| Exact electrical role of GPIO6 vs GPIO7 on PCB | HIGH hypothesis only |
| GPIO11 / 20 / 21 | Unknown / reconstruction-only for 20 |

These gaps **do not block** a functionally correct charging-path reconstruction if fail-safe rules above are observed.

## 11. Recommended next work (Step 22+)

If a proper RISC-V disassembler / Ghidra project on the mapped image becomes available:

1. XREF all references to `0x4200C870..C8A6`.  
2. XREF all stores to `0x3FCA0B1D`, `0x3FCA0B0C`, `0x3FCA0B15`.  
3. XREF reads of `0x3FCA0C04`.  
4. Find LEDC `ledc_set_duty` / channel update sites.  
5. Expand `gbt_payload_generators.c` into a full state-machine + relay module.

Until then, the baseline in this document + JSON/CSV maps is the authoritative reconstruction input.

## 12. Deliverables of this pass

- This baseline document  
- Updated `reconstruction_baseline_step21.json`  
- Updated GPIO residual CSV  
- Expanded notes in `src/reconstruction/`  
- Archive `cubik_firmware_reverse_engineering_step21.zip`
