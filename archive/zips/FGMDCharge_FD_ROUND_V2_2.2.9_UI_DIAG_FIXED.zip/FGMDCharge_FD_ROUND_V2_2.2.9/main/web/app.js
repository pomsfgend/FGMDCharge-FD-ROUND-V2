(() => {
  const $ = id => document.getElementById(id);
  const cachedKey = () => localStorage.getItem('cubeKey') || '';
  const setText = (id,v) => { const e=$(id); if(e) e.textContent=String(v); };
  const n = v => Number.isFinite(Number(v)) ? Number(v) : null;
  const volt = v => { const x=n(v); return x===null || x===0 ? '—' : (x/10).toFixed(1)+' V'; };
  const amp = v => { const x=n(v); return x===null || x<=-32000 ? '—' : (x/10).toFixed(1)+' A'; };

  async function getJson(url, options={}) {
    const headers=Object.assign({'Accept':'application/json'},options.headers||{});
    const r=await fetch(url,Object.assign({},options,{headers}));
    const text=await r.text(); let d={}; try{d=JSON.parse(text)}catch(_){}
    if(!r.ok) throw new Error(d.error||`HTTP ${r.status}`);
    return d;
  }
  async function getAuthKey() {
    const cached=cachedKey(); if(cached) return cached;
    let required=true; try{const s=await getJson('/api/settings'); required=s.web_key_required!==false}catch(_){}
    if(!required)return '';
    const entered=prompt('Введите X-Cube-Key'); if(entered===null)return null;
    const k=entered.trim(); if(k)localStorage.setItem('cubeKey',k); return k;
  }

  function render(s) {
    const online=!!(s.charger_online||s.can);
    const conn=$('conn'); conn.classList.toggle('online',online);
    setText('conn',s.charger_online?'CHARGER ONLINE':(s.can?'CAN ONLINE':'OFFLINE'));
    setText('version',`${s.fw||'FD_ROUND_V2'} · ${s.version||''}`);
    setText('voltage',s.ccs_voltage_0p1v?(Number(s.ccs_voltage_0p1v)/10).toFixed(1):'—');
    setText('current',Number(s.ccs_current_0p1a)>-32000?(Number(s.ccs_current_0p1a)/10).toFixed(1):'—');
    setText('power',s.power_w>0?Math.round(Number(s.power_w)):'—');
    const tempValid=!!s.cpu_temp_valid, temp=n(s.cpu_temp_c);
    setText('temp',tempValid&&temp!==null?temp.toFixed(1):'—');
    setText('tempState',tempValid?(temp>=75?'HIGH TEMP':'CPU sensor'):'sensor unavailable');
    setText('stage',s.stage||'NO DATA');
    setText('stageMs',s.stage_age_ms!=null?Math.round(Number(s.stage_age_ms)/1000)+'s':'—');
    setText('permit',s.ccs_charge_permit===1?'ALLOWED':String(s.ccs_charge_permit??'—'));
    setText('ccsStatus',`0x${Number(s.ccs_status_raw||0).toString(16).padStart(2,'0').toUpperCase()}`);
    setText('can',s.can?'ONLINE':'OFFLINE');
    setText('time',s.ccs_time_min||'—');
    setText('mainState',s.main_state_name||('ST'+s.main_state));
    setText('substate',s.substate??'—');
    setText('relayA',s.relay_a?'ON':'OFF'); setText('relayB',s.relay_b?'ON':'OFF');
    setText('handoff',s.handoff_done?'YES':'NO');
    setText('batV',s.battery_voltage_0p1v?(Number(s.battery_voltage_0p1v)/10).toFixed(1)+' V':'—');
    setText('soc',s.soc!=null?s.soc+'%':'—');
    setText('limitsV',`${volt(s.cml_min_voltage_0p1v)} … ${volt(s.cml_max_voltage_0p1v)}`);
    setText('limitsI',`${amp(s.cml_min_current_0p1a)} … ${amp(s.cml_max_current_0p1a)}`);
    setText('request',`${volt(s.bcl_voltage_0p1v)} · ${amp(s.bcl_current_0p1a)}`);
    setText('mode',s.bcl_mode??'—');
    setText('cpuLoad',s.cpu_load_percent!=null?s.cpu_load_percent+'%':'—');
    setText('heap',s.heap_free_bytes?Math.round(Number(s.heap_free_bytes)/1024)+' KiB':'—');
    setText('touch',s.touch?(s.touch_pressed?'PRESSED':'READY'):'UNAVAILABLE');
    setText('rx',s.rx_count||0); setText('txState',s.tx_enabled?'ENABLED':'OFF');
    const tx=$('txBtn'); if(tx)tx.textContent=s.tx_enabled?'Выключить CAN TX':'Включить CAN TX';
    const br=Math.max(10,Math.min(100,Number(s.brightness_percent||100)));
    $('brightness').value=br; setText('brightnessValue',br+'%');
  }

  async function refresh(){try{render(await getJson('/api/status'))}catch(_){setText('conn','WEB ERROR')}}
  async function refreshFrames(){
    try{
      const d=await getJson('/api/can/recent');
      const rows=(d.frames||[]).map(f=>`<tr><td>${f.ms}</td><td>${f.id}</td><td>${f.dlc}</td><td><code>${f.data}</code></td></tr>`).join('');
      $('frames').innerHTML=rows||'<tr><td colspan="4" class="empty">Нет кадров</td></tr>';
    }catch(_){$('frames').innerHTML='<tr><td colspan="4" class="empty">Ошибка чтения истории CAN</td></tr>'}
  }

  let brightnessTimer=0;
  $('brightness').addEventListener('input',()=>{
    const v=Number($('brightness').value); setText('brightnessValue',v+'%');
    clearTimeout(brightnessTimer);
    brightnessTimer=setTimeout(async()=>{
      const k=await getAuthKey(); if(k===null)return;
      try{await getJson('/api/settings',{method:'POST',headers:{'Content-Type':'application/json','X-Cube-Key':k},body:JSON.stringify({brightness:v})})}
      catch(e){setText('brightnessValue','ERR')}
    },180);
  });

  $('txBtn').addEventListener('click',async()=>{
    const k=await getAuthKey();if(k===null)return;
    try{const s=await getJson('/api/status');await getJson('/api/settings',{method:'POST',headers:{'Content-Type':'application/json','X-Cube-Key':k},body:JSON.stringify({tx_enabled:!s.tx_enabled})});refresh()}
    catch(e){alert(e.message)}
  });
  $('rebootBtn').addEventListener('click',async()=>{const k=await getAuthKey();if(!k)return;try{await getJson('/api/reboot',{method:'POST',headers:{'X-Cube-Key':k}})}catch(e){if(!/fetch|network/i.test(e.message))alert(e.message)}});
  $('refreshCan').addEventListener('click',refreshFrames);

  $('sendCan').addEventListener('click',async()=>{
    const k=await getAuthKey();if(!k)return;
    const idText=$('canId').value.trim(), dlc=Number($('canDlc').value);
    const parts=$('canData').value.trim().replace(/,/g,' ').split(/\s+/).filter(Boolean);
    const data=parts.map(v=>Number(v.startsWith('0x')?v:'0x'+v)), id=Number(idText);
    if(!Number.isInteger(dlc)||dlc<0||dlc>8||data.length!==dlc||data.some(v=>!Number.isInteger(v)||v<0||v>255)||!Number.isInteger(id)||id<0||id>0x1FFFFFFF){setText('canSendText','Неверный CAN кадр');return}
    try{await getJson('/api/can/raw',{method:'POST',headers:{'Content-Type':'application/json','X-Cube-Key':k},body:JSON.stringify({id,dlc,data})});setText('canSendText',`Отправлено 0x${id.toString(16).toUpperCase()} / DLC ${dlc}`);refreshFrames()}
    catch(e){setText('canSendText',e.message)}
  });

  $('otaBtn').addEventListener('click',()=>{
    const f=$('otaFile').files[0];if(!f)return alert('Выберите .bin');if(f.size>0x190000)return alert('Файл больше OTA1');
    getAuthKey().then(k=>{if(!k)return;const xhr=new XMLHttpRequest();xhr.open('POST','/api/update');xhr.timeout=120000;xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.setRequestHeader('X-Cube-Key',k);
      xhr.upload.onprogress=e=>{if(e.lengthComputable){const pct=Math.round(e.loaded/e.total*100);$('bar').style.width=pct+'%';setText('otaText',`Загрузка ${pct}%`)}};
      xhr.onload=()=>{try{const d=JSON.parse(xhr.responseText);setText('otaText',d.ok?'Прошивка принята, устройство перезагружается':(d.error||'OTA failed'))}catch(_){setText('otaText','Соединение закрыто устройством')}}
      xhr.onerror=()=>setText('otaText','Ошибка соединения');xhr.ontimeout=()=>setText('otaText','Таймаут OTA');xhr.send(f)
    });
  });

  $('startBtn').addEventListener('click',async()=>{const k=await getAuthKey();if(!k)return;try{await getJson('/api/session/start',{method:'POST',headers:{'X-Cube-Key':k}});setText('handoff','STARTING…')}catch(e){alert(e.message)}});
  $('stopBtn').addEventListener('click',async()=>{const k=await getAuthKey();if(!k)return;try{await getJson('/api/session/stop',{method:'POST',headers:{'X-Cube-Key':k}});setText('handoff','STOPPING…')}catch(e){alert(e.message)}});

  refresh();refreshFrames();setInterval(refresh,1000);setInterval(refreshFrames,3000);
})();
