const $=(id)=>document.getElementById(id);
let pick="", cap=7.5;
document.querySelectorAll(".nav:not([disabled])").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("on"));
  b.classList.add("on");
  document.querySelectorAll("main section").forEach(s=>s.classList.add("hide"));
  $(b.dataset.tab).classList.remove("hide");
});
async function tick(){
  try{
    const s=await (await fetch("/api/status?t="+Date.now())).json();
    const live=s.ccs_voltage_0p1v>0;
    $("v").textContent=live?(s.ccs_voltage_0p1v/10).toFixed(0)+" В":"--";
    $("a").textContent=live?(Math.abs(s.ccs_current_0p1a)/10).toFixed(1)+" А":"--";
    $("p").textContent=live?(s.power_w||0)+" Вт":"--";
    const kwh=(s.energy_kwh||0);
    $("kwh").textContent=kwh.toFixed?kwh.toFixed(3)+" кВт·ч":"--";
    $("kwh2").textContent=$("kwh").textContent;
    const soc=Math.min(100, Math.round((s.soc||0) + (cap? kwh/cap*100 : 0)));
    $("soc").textContent=(s.soc||0)+" %";
    $("soc2").textContent=soc+" %";
    $("st").textContent=s.main_state_name||"нет сессии";
    $("proto").textContent=(s.protocol||"GB/T")+" · "+(s.stage||"");
    $("stage").textContent=s.stage||"--";
    $("mins").textContent=(s.ccs_time_min||0)+" мин";
    $("lim").textContent=s.cml_max_voltage_0p1v?((s.cml_min_voltage_0p1v/10)+"-"+(s.cml_max_voltage_0p1v/10)+" В"):"ждём CML";
    $("ch").textContent=s.ap_channel||"--";
    $("sta").textContent=s.ap_clients||0;
    $("sip").textContent=s.sta_ip&&s.sta_ip!=="wait"?("http://"+s.sta_ip+"/"):"ещё нет";
    $("xchg").textContent=s.charger_online?("обмен "+s.rx_count+"/"+s.tx_count):"тишина";
    $("req").textContent=((s.bcl_voltage_0p1v||2400)/10)+" В / "+(Math.abs(s.bcl_current_0p1a||500)/10)+" А";
    $("rel").textContent=(s.relay_a?"замкн":"откр")+" / "+(s.relay_b?"замкн":"откр");
    $("vin").textContent=s.vin||$("vinin").value||"не задан";
    $("capv").textContent=cap+" кВт·ч";
  }catch(e){}
}
setInterval(tick,1000); tick();
$("set").onsubmit=async(e)=>{e.preventDefault(); cap=+$("cap").value||7.5;
  await fetch("/api/setpoints",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"v="+$("vv").value+"&i="+$("ii").value+"&soc="+$("ss").value+"&vin="+encodeURIComponent($("vinin").value)});
};
$("scan").onclick=async()=>{
  const r=await (await fetch("/api/wifi/scan")).json();
  $("nets").innerHTML=""; $("sheet").classList.add("hide");
  (r.nets||[]).forEach(n=>{const li=document.createElement("li"); li.textContent=n; li.onclick=()=>{pick=n; $("chosen").textContent=n; $("sheet").classList.remove("hide"); $("pw").focus();}; $("nets").appendChild(li);});
};
$("cancel").onclick=()=>$("sheet").classList.add("hide");
$("join").onclick=async()=>{ $("sip").textContent="wait"; $("sheet").classList.add("hide"); await fetch("/api/wifi/join",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"ssid="+encodeURIComponent(pick)+"&pass="+$("pw").value}); };
$("relay").onclick=async()=>{await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:"{\"relay_test\":true}"});};
$("orig").onclick=async()=>{await fetch("/api/boot/original",{method:"POST"});};
$("getlog").onclick=async()=>{ $("esplog").textContent=await (await fetch("/api/log")).text(); $("canlog").textContent=await (await fetch("/api/can")).text(); };
let hold;
$("hold").addEventListener("pointerdown",(e)=>{e.preventDefault(); hold=setTimeout(async()=>{await fetch("/api/stop",{method:"POST"});},700);});
$("hold").addEventListener("pointerup",()=>clearTimeout(hold));
function animate(p,txt){ $("bar").style.width=p+"%"; $("otatxt").textContent=txt; }
$("ota").onclick=()=>{
  const f=$("bin").files[0]; if(!f||f.size>0x190000) return;
  const xhr=new XMLHttpRequest(); xhr.timeout=120000; xhr.open("POST","/api/ota");
  xhr.upload.onprogress=(e)=>{ if(e.lengthComputable) animate(e.loaded/e.total*100, "прошивка "+Math.round(e.loaded/e.total*100)+"%"); };
  xhr.onload=()=>animate(100, xhr.responseText);
  xhr.send(f);
};
$("netfw").onclick=async()=>{
  animate(15, "запрос файла");
  const body="url="+encodeURIComponent($("url").value)+"&user="+encodeURIComponent($("wu").value)+"&pass="+encodeURIComponent($("wp").value);
  const r=await fetch("/api/ota/url",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
  animate(100, await r.text());
};
