/*
 * Reconstruction baseline — relay + state machine skeleton
 * Derived from firmware reverse engineering steps 3–21.
 * NOT a drop-in module: timing, CAN, and exact substate addresses
 * must be wired to the rest of the ported firmware.
 */
#include <stdint.h>
#include <stdbool.h>

/* GPIO mapping from original binary */
#define RELAY_A_GPIO  6
#define RELAY_B_GPIO  7
#define STRAPPING_GPIO 2  /* NEVER drive as output */

/* Main state values */
enum {
    ST_IDLE = 0,
    ST_HANDSHAKE_INIT = 1,
    ST_WAIT_CRM = 2,
    ST_PARAM_CONFIG = 3,
    ST_READY_WAIT_CRO = 4,
    ST_CHARGING = 5,
    ST_STOP = 6,
    ST_FINALIZE = 7
};

/* External HAL stubs */
void gpio_set_level_safe(int gpio, int level);
uint32_t sm_time_ms(void); /* 10 ms quantum timebase */

static uint8_t main_state = ST_IDLE;
static uint8_t substate = 0;
static uint32_t state_entry_ms = 0;
static bool handoff_done = false;

void relay_fail_safe(void) {
    gpio_set_level_safe(RELAY_A_GPIO, 0);
    gpio_set_level_safe(RELAY_B_GPIO, 0);
}

void relay_enter_ready(void) {
    /* State 4: prepare */
    gpio_set_level_safe(RELAY_A_GPIO, 1);
}

void relay_charging_handoff(void) {
    /* State 5 after 10 s + substate==3 */
    gpio_set_level_safe(RELAY_A_GPIO, 0);
    gpio_set_level_safe(RELAY_B_GPIO, 1);
}

void sm_set_state(uint8_t s) {
    main_state = s;
    state_entry_ms = sm_time_ms();
    handoff_done = false;
    if (s == ST_IDLE || s == ST_STOP || s == ST_FINALIZE) {
        relay_fail_safe();
    }
    if (s == ST_READY_WAIT_CRO) {
        substate = 3;
        relay_enter_ready();
    }
}

/* BLE override path — only GPIO6 + substate, never GPIO7 */
void ble_cmd_0x66(uint8_t val) {
    if (val == 0) {
        gpio_set_level_safe(RELAY_A_GPIO, 0);
        substate = 6;
        /* application may also force main state toward STOP */
    } else if (val == 1) {
        gpio_set_level_safe(RELAY_A_GPIO, 1);
        substate = 3;
    }
}

void ble_cmd_0x0D(void) {
    substate = 6;
}

/* Called every 10 ms from CAN task */
void sm_tick(void) {
    switch (main_state) {
    case ST_HANDSHAKE_INIT:
        sm_set_state(ST_WAIT_CRM);
        break;
    case ST_CHARGING:
        if (!handoff_done && substate == 3) {
            if ((sm_time_ms() - state_entry_ms) >= 10000u) {
                relay_charging_handoff();
                handoff_done = true;
                /* original advances internal substate after hand-off */
            }
        }
        break;
    case ST_STOP:
    case ST_FINALIZE:
        relay_fail_safe();
        break;
    default:
        break;
    }
}

void sm_boot_init(void) {
    /* Do not touch STRAPPING_GPIO as a normal output */
    relay_fail_safe();
    main_state = ST_IDLE;
    substate = 0;
    handoff_done = false;
}
