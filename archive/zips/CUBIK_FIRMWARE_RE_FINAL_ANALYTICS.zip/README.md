# Аналитика прошивки GB/T DC-адаптера (кубик)

Готовый пакет для самостоятельного воссоздания прошивки.

## С чего начать

1. Прочитайте **`docs/ИТОГОВЫЙ_ОТЧЁТ_РЕВЕРС_ПРОШИВКИ.md`** — полный отчёт.
2. Таблицы для импорта:
   - `maps/gpio_map.csv` — все пины
   - `maps/can_message_map.json` — CAN ID
   - `maps/state_machine.json` — состояния и реле
   - `maps/reconstruction_baseline.json` — сводный baseline
3. Каркас кода:
   - `src/relay_and_state_baseline.c` — state machine + реле + BLE 0x66
   - `src/gbt_payload_generators.c` — формулы BCP/BCS/BRM

## Критические правила

- GPIO2 **не драйвить**
- Реле: State4 → GPIO6=1; через 10 с в State5 → GPIO6=0, GPIO7=1
- На stop/error/idle: **оба реле = 0**
- CAN 250 kbit/s, TX=10, RX=9
- LCD ILI9341 SPI 5/19/4/18, 240×280, LVGL tick 2 ms, RST/BL = -1
- Touch CST816 @ 0x15, SDA=1, SCL=8

`dump1.bin` — исходный полный flash-дамп (по желанию).
