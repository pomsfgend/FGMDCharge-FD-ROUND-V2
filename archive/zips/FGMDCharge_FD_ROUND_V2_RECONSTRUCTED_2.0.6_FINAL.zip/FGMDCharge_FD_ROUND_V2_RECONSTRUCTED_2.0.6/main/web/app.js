(() => {
  const key = () => localStorage.getItem('cubeKey') || '';
  const $ = id => document.getElementById(id);
  const setText = (id, v) => { const e=$(id); if(e) e.textContent=String(v); };
  const num = v => Number.isFinite(Number(v)) ? Number(v) : null;
  const amp = raw => { const n=num(raw); if(n===null||n<=-32000) return '—'; return `${(n/10).toFixed(1)} A`; };
  const volt = raw => { const n=num(raw); if(n===null||n===0) return '—'; return `${(n/10).toFixed(1)} V`; };
  async function getJson(url, options={}) {
    const headers = Object.assign({'Accept':'application/json'}, options.headers||{});
    const r = await fetch(url, Object.assign({}, options, {headers}));
    const t = await r.text(); let data={}; try { data=JSON.parse(t); } catch (_) {}
    if(!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  }
  async function getAuthKey() {
    const cached = key();
    if (cached) return cached;
    let required = true;
    try {
      const s = await getJson('/api/settings');
      required = s.web_key_required !== false;
    } catch (_) {}
    if (!required) return '';
    const entered = prompt('Enter X-Cube-Key');
    if (entered === null) return null;
    const k = entered.trim();
    if (k) localStorage.setItem('cubeKey', k);
    return k;
  }
  function render(s) {
    setText('conn', s.charger_online ? 'CHARGER ONLINE' : (s.can ? 'CAN ONLINE' : 'OFFLINE'));
    setText('version', `${s.fw || 'FD_ROUND_V2'} • ${s.version || ''}`);
    setText('voltage', s.ccs_voltage_0p1v ? (Number(s.ccs_voltage_0p1v)/10).toFixed(1) : '—');
    setText('current', Number(s.ccs_current_0p1a) > -32000 ? (Number(s.ccs_current_0p1a)/10).toFixed(1) : '—');
    setText('power', s.power_w > 0 ? Number(s.power_w).toFixed(0) : '—');
    setText('time', s.ccs_time_min || '—');
    setText('stage', s.stage || 'NO DATA');
    setText('stageMs', s.stage_ms ? `${Math.round((Date.now()%4294967296 - Number(s.stage_ms))/1000)}s` : '—');
    setText('permit', s.ccs_charge_permit === 1 ? 'ALLOWED' : String(s.ccs_charge_permit));
    setText('ccsStatus', `0x${Number(s.ccs_status_raw||0).toString(16).padStart(2,'0').toUpperCase()}`);
    setText('can', s.can ? 'ONLINE' : 'OFFLINE');
    setText('limitsV', `${volt(s.cml_min_voltage_0p1v)} … ${volt(s.cml_max_voltage_0p1v)}`);
    setText('limitsI', `${amp(s.cml_min_current_0p1a)} … ${amp(s.cml_max_current_0p1a)}`);
    setText('request', `${volt(s.bcl_voltage_0p1v)} • ${amp(s.bcl_current_0p1a)}`);
    setText('mode', s.bcl_mode ?? '—');
    setText('ble', s.ble ? (s.notify ? 'CONNECTED / NOTIFY' : 'CONNECTED') : 'DISCONNECTED');
    setText('touch', s.touch ? (s.touch_pressed ? 'PRESSED' : 'READY') : 'UNAVAILABLE');
    setText('rx', s.rx_count || 0);
    setText('txState', s.tx_enabled ? 'ENABLED' : 'OFF');
    const btn=$('txBtn'); if(btn) btn.textContent = s.tx_enabled ? 'Disable CAN TX' : 'Enable CAN TX';
  }
  async function refresh() { try { const s=await getJson('/api/status'); render(s); } catch(e) { setText('conn','WEB ERROR'); } }
  async function refreshFrames() {
    try { const d=await getJson('/api/can/recent'); const rows=(d.frames||[]).map(f=>`<tr><td>${f.ms}</td><td>${f.id}</td><td>${f.dlc}</td><td><code>${f.data}</code></td></tr>`).join(''); $('frames').innerHTML=rows || '<tr><td colspan="4" class="empty">No frames yet</td></tr>'; } catch(e) { $('frames').innerHTML='<tr><td colspan="4" class="empty">Failed to read CAN history</td></tr>'; }
  }
  $('txBtn').addEventListener('click', async()=>{
    const k=await getAuthKey(); if(k===null)return;
    const s=await getJson('/api/status'); const next=!s.tx_enabled;
    const headers={'Content-Type':'application/json'}; if(k) headers['X-Cube-Key']=k;
    try { await getJson('/api/settings',{method:'POST',headers,body:JSON.stringify({tx_enabled:next})}); refresh(); } catch(e) { alert(e.message); }
  });
  $('rebootBtn').addEventListener('click',async()=>{ const k=await getAuthKey(); if(!k)return; try { await getJson('/api/reboot',{method:'POST',headers:{'X-Cube-Key':k}}); } catch(e) { if(!/fetch|network/i.test(e.message)) alert(e.message); } });
  $('refreshCan').addEventListener('click',refreshFrames);
  $('sendCan').addEventListener('click',async()=>{
    const k=await getAuthKey(); if(!k)return;
    const idText=$('canId').value.trim(); const dlc=Number($('canDlc').value);
    const parts=$('canData').value.trim().replace(/,/g,' ').split(/\s+/).filter(Boolean);
    const data=parts.map(v=>Number(v.startsWith('0x')?v:('0x'+v)));
    if(!Number.isInteger(dlc)||dlc<0||dlc>8||data.length!==dlc||data.some(v=>!Number.isInteger(v)||v<0||v>255)||!idText){ setText('canSendText','Invalid CAN frame. Use ID, DLC 0…8 and exactly DLC data bytes.'); return; }
    const id=Number(idText); if(!Number.isInteger(id)||id<0||id>0x1FFFFFFF){ setText('canSendText','Invalid CAN ID.'); return; }
    try{ const d=await getJson('/api/can/raw',{method:'POST',headers:{'Content-Type':'application/json','X-Cube-Key':k},body:JSON.stringify({id:id,dlc:dlc,data:data})}); setText('canSendText',`Sent ID 0x${id.toString(16).toUpperCase()} / DLC ${dlc}.`); refreshFrames(); } catch(e){ setText('canSendText',e.message); }
  });
  $('otaBtn').addEventListener('click',()=>{
    const f=$('otaFile').files[0]; if(!f)return alert('Choose a firmware .bin file.'); if(f.size>0x190000)return alert('Firmware exceeds OTA1 slot (0x190000 bytes).');
    getAuthKey().then(k=>{ if(!k)return;
    const xhr=new XMLHttpRequest(); xhr.open('POST','/api/update'); xhr.timeout=120000; xhr.setRequestHeader('Content-Type','application/octet-stream'); xhr.setRequestHeader('X-Cube-Key',k);
    xhr.upload.onprogress=e=>{ if(e.lengthComputable){ const pct=Math.round(e.loaded/e.total*100); $('bar').style.width=pct+'%'; setText('otaText',`Uploading ${pct}%`); } };
    xhr.onload=()=>{ try{const d=JSON.parse(xhr.responseText); if(d.ok)setText('otaText','Update accepted. Device is rebooting.'); else setText('otaText',d.error||'OTA failed');}catch(_){setText('otaText','Device rebooted or closed connection.');} };
    xhr.onerror=()=>setText('otaText','OTA connection failed.');
    xhr.ontimeout=()=>setText('otaText','OTA upload timed out.');
    xhr.send(f);
    });
  });
  refresh(); refreshFrames(); setInterval(refresh,1000); setInterval(refreshFrames,3000);
})();
