/*
 * LEDC/PWM hardware configuration recovered from main/ADC.c.
 *
 * The timer configuration is:
 *   speed_mode=0
 *   duty_resolution=10 bits
 *   timer_num=0
 *   freq_hz=60000
 *   clk_cfg=0
 *
 * The channel config explicitly sets gpio_num=3 and uses channel 0.
 */
#include "driver/ledc.h"

#define PWM_GPIO 3

void cubik_pwm_init(void)
{
    ledc_timer_config_t timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .timer_num = LEDC_TIMER_0,
        .freq_hz = 60000,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer));

    ledc_channel_config_t channel = {
        .gpio_num = PWM_GPIO,
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .channel = LEDC_CHANNEL_0,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = LEDC_TIMER_0,
        .duty = 0,
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&channel));
}
