/*
 * Minimal CST816S-compatible touch reconstruction.
 *
 * The original firmware initializes I2C0 as:
 *   SDA=GPIO1, SCL=GPIO8, 100 kHz, internal pull-ups enabled.
 *
 * It accesses device address 0x15 and performs the distinctive startup reads:
 *   register 0x15, then register 0xA7.
 * It then reads register 0x02 (finger count), and if non-zero reads 0x03..0x06
 * for X/Y coordinates.
 */
#include "driver/i2c.h"

#define TOUCH_I2C_NUM I2C_NUM_0
#define TOUCH_SDA     1
#define TOUCH_SCL     8
#define TOUCH_ADDR    0x15

static esp_err_t touch_read_reg(uint8_t reg, uint8_t *data, size_t len)
{
    return i2c_master_write_read_device(
        TOUCH_I2C_NUM,
        TOUCH_ADDR,
        &reg, 1,
        data, len,
        pdMS_TO_TICKS(100)
    );
}

void cubik_touch_init(void)
{
    i2c_config_t cfg = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = TOUCH_SDA,
        .scl_io_num = TOUCH_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 100000,
    };

    ESP_ERROR_CHECK(i2c_param_config(TOUCH_I2C_NUM, &cfg));
    ESP_ERROR_CHECK(i2c_driver_install(TOUCH_I2C_NUM, cfg.mode, 0, 0, 0));

    uint8_t dummy;
    // Exact startup wake/probe sequence recovered from the firmware.
    touch_read_reg(0x15, &dummy, 1);
    touch_read_reg(0xA7, &dummy, 1);
}

bool cubik_touch_read(uint16_t *x, uint16_t *y)
{
    uint8_t n;
    if (touch_read_reg(0x02, &n, 1) != ESP_OK || n == 0) {
        *x = *y = 0;
        return false;
    }

    uint8_t b[4];
    if (touch_read_reg(0x03, b, 4) != ESP_OK) {
        *x = *y = 0;
        return false;
    }

    *x = ((uint16_t)b[0] << 8) | b[1];
    *y = ((uint16_t)b[2] << 8) | b[3];
    return true;
}
