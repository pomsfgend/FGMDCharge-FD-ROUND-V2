/*
 * TWAI/CAN configuration reconstructed from main/CAN.c.
 */
#include "driver/twai.h"

#define CAN_TX 10
#define CAN_RX 9

void cubik_can_init(void)
{
    twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(
        CAN_TX, CAN_RX, TWAI_MODE_NORMAL
    );
    g_config.tx_queue_len = 10;
    g_config.rx_queue_len = 10;
    g_config.alerts_enabled = 0;
    g_config.clkout_divider = 0;
    g_config.intr_flags = 2;

    // The original then calls twai_driver_install(), twai_start(),
    // twai_transmit() and twai_receive().
    //
    // Bitrate is NOT safely inferred from the pin/config structure alone;
    // recover it from the TWAI timing configuration used by the original
    // firmware before assuming a CAN bitrate.
}
