#pragma once
#include <stdint.h>

/*
 * Reconstructed from the original Cubik firmware dump.
 * Target MCU: ESP32-C3.
 *
 * IMPORTANT:
 * GPIO6/7 are confirmed as two switched outputs, but which physical relay
 * is "relay A/B" is a board-level naming issue. Verify with a multimeter.
 */

// LCD / ILI9341
#define LCD_SPI_HOST        1       // SPI2_HOST on this ESP32-C3 firmware
#define LCD_MOSI_GPIO       5
#define LCD_MISO_GPIO      -1
#define LCD_SCLK_GPIO      19
#define LCD_CS_GPIO          4
#define LCD_DC_GPIO         18
#define LCD_RST_GPIO        -1
#define LCD_SPI_MODE         0
#define LCD_PCLK_HZ   20000000
#define LCD_QUEUE_DEPTH     10
#define LCD_CMD_BITS        8
#define LCD_PARAM_BITS      8
#define LCD_WIDTH          240
#define LCD_HEIGHT         280

// Touch: CST816S-compatible register protocol
#define TOUCH_I2C_PORT       0
#define TOUCH_SDA_GPIO       1
#define TOUCH_SCL_GPIO       8
#define TOUCH_I2C_HZ    100000
#define TOUCH_I2C_ADDR    0x15
#define TOUCH_REG_FINGER   0x02
#define TOUCH_REG_XH       0x03
#define TOUCH_REG_XL       0x04
#define TOUCH_REG_YH       0x05
#define TOUCH_REG_YL       0x06
#define TOUCH_REG_CHIP_ID  0xA7

// CAN / TWAI
#define CAN_TX_GPIO         10
#define CAN_RX_GPIO          9

// Board outputs
#define RELAY_A_GPIO         6
#define RELAY_B_GPIO         7
#define AUX_GPIO             2
#define PWM_GPIO             3

// PWM reconstructed configuration
#define PWM_MODE             0
#define PWM_CHANNEL          0
#define PWM_TIMER             0
#define PWM_DUTY_RES_BITS   10
#define PWM_FREQUENCY_HZ 60000
