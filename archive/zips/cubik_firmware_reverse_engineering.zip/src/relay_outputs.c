/*
 * Board output reconstruction.
 *
 * Firmware calls gpio_set_level():
 *   GPIO6 -> initial LOW, can be set HIGH/LOW
 *   GPIO7 -> initial LOW, can be set HIGH/LOW
 *   GPIO2 -> initial HIGH
 *
 * GPIO6 and GPIO7 are the two confirmed switched outputs and are the
 * strongest relay candidates. The binary does not contain a semantic name
 * saying which physical relay is which.
 */
#include "driver/gpio.h"

#define RELAY_A 6
#define RELAY_B 7
#define AUX_OUT 2

void cubik_outputs_init(void)
{
    gpio_config_t io = {
        .pin_bit_mask = (1ULL << RELAY_A) |
                        (1ULL << RELAY_B) |
                        (1ULL << AUX_OUT),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&io));

    gpio_set_level(RELAY_A, 0);
    gpio_set_level(RELAY_B, 0);
    gpio_set_level(AUX_OUT, 1);
}

// State helpers reconstructed from the firmware's GPIO operations.
static inline void relay_a_on(void)  { gpio_set_level(RELAY_A, 1); }
static inline void relay_a_off(void) { gpio_set_level(RELAY_A, 0); }
static inline void relay_b_on(void)  { gpio_set_level(RELAY_B, 1); }
static inline void relay_b_off(void) { gpio_set_level(RELAY_B, 0); }
