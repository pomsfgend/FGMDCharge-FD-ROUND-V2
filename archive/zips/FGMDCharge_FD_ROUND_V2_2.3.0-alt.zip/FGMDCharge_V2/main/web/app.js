(() => {
  const $ = (id) => document.getElementById(id);
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  let online = false;

  async function api(path, opt) {
    const r = await fetch(path, Object.assign({ headers: { "Accept": "application/json" } }, opt || {}));
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.json();
  }

  function paint(s) {
    online = true;
    $("conn").textContent = "ONLINE";
    $("conn").classList.add("on");
    set("voltage", s.voltage_v != null ? Number(s.voltage_v).toFixed(1) : "—");
    set("current", s.current_a != null ? Number(s.current_a).toFixed(1) : "—");
    set("power", s.power_w != null ? Math.round(s.power_w) : "—");
    set("time", s.time_min != null ? s.time_min : "—");
    set("stage", s.stage || "—");
    set("permit", s.permit || "—");
    set("ccsStatus", s.ccs || "—");
    set("can", s.can || "—");
    set("limitsV", s.limit_v || "—");
    set("limitsI", s.limit_i || "—");
    set("request", s.request || "—");
    set("mode", s.mode || "—");
    set("mainState", s.main_state || "—");
    set("subState", s.sub_state != null ? s.sub_state : "—");
    set("relayA", s.relay_a || "OFF");
    set("relayB", s.relay_b || "OFF");
    set("version", s.version || "—");
    set("cpuTemp", s.cpu_temp_c != null ? Number(s.cpu_temp_c).toFixed(1) + " °C" : "—");
    set("heap", s.heap != null ? Math.round(s.heap / 1024) + " KB" : "—");
    set("wifi", s.wifi || "—");
    set("txState", s.tx_enabled ? "ON" : "OFF");
  }

  async function tick() {
    try {
      const s = await api("/api/status");
      paint(s);
    } catch (e) {
      online = false;
      $("conn").textContent = "OFFLINE";
      $("conn").classList.remove("on");
    }
  }

  async function loadCan() {
    try {
      const d = await api("/api/can");
      const tb = $("frames");
      if (!d.frames || !d.frames.length) {
        tb.innerHTML = '<tr><td colspan="4" class="empty">Нет кадров</td></tr>';
        return;
      }
      tb.innerHTML = d.frames.map(f =>
        `<tr><td>${f.t || ""}</td><td>${f.id || ""}</td><td>${f.dlc || ""}</td><td><code>${f.data || ""}</code></td></tr>`
      ).join("");
    } catch (_) {}
  }

  $("startBtn") && $("startBtn").addEventListener("click", () => api("/api/start", { method: "POST" }).catch(() => {}));
  $("stopBtn") && $("stopBtn").addEventListener("click", () => api("/api/stop", { method: "POST" }).catch(() => {}));
  $("txBtn") && $("txBtn").addEventListener("click", () => api("/api/tx_enable", { method: "POST" }).then(tick).catch(() => {}));
  $("rebootBtn") && $("rebootBtn").addEventListener("click", () => api("/api/reboot", { method: "POST" }).catch(() => {}));
  $("refreshCan") && $("refreshCan").addEventListener("click", loadCan);

  $("otaBtn") && $("otaBtn").addEventListener("click", async () => {
    const f = $("otaFile").files && $("otaFile").files[0];
    if (!f) { $("otaText").textContent = "Выберите .bin"; return; }
    $("otaText").textContent = "Загрузка…";
    try {
      const r = await fetch("/api/ota", { method: "POST", body: f, headers: { "Content-Type": "application/octet-stream" } });
      $("bar").style.width = "100%";
      $("otaText").textContent = r.ok ? "OK — перезагрузка" : "Ошибка OTA";
    } catch (e) {
      $("otaText").textContent = "Сбой: " + e.message;
    }
  });

  tick();
  loadCan();
  setInterval(tick, 1000);
  setInterval(loadCan, 3000);
})();
