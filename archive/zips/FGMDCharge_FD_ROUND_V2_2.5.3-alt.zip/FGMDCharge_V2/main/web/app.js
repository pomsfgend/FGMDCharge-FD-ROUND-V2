const $=(id)=>document.getElementById(id);
let pick="";
document.querySelectorAll(".nav:not([disabled])").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("on"));
  b.classList.add("on");
  document.querySelectorAll("main section").forEach(s=>s.classList.add("hide"));
  $(b.dataset.tab).classList.remove("hide");
});
async function tick(){
  try{
    const s=await (await fetch("/api/status?t="+Date.now())).json();
    const live=s.ccs_voltage_0p1v>0;
    $("v").textContent=live?(s.ccs_voltage_0p1v/10).toFixed(0)+" В":"--";
    $("a").textContent=live?(Math.abs(s.ccs_current_0p1a)/10).toFixed(1)+" А":"--";
    $("p").textContent=live?(s.power_w||0)+" Вт":"--";
    $("soc").textContent=(s.soc||0)+" %";
    $("st").textContent=s.main_state_name||"нет сессии";
    $("proto").textContent=(s.protocol||"GB/T")+" · "+(s.stage||"");
    $("ch").textContent=s.ap_channel||"--";
    $("sta").textContent=s.ap_clients||0;
    $("sip").textContent=s.sta_ip||"--";
    $("xchg").textContent=s.charger_online?("обмен "+s.rx_count+"/"+s.tx_count):"тишина";
    $("req").textContent=((s.bcl_voltage_0p1v||2400)/10)+" В / "+(Math.abs(s.bcl_current_0p1a||500)/10)+" А";
  }catch(e){}
}
setInterval(tick,1000); tick();
$("set").onsubmit=async(e)=>{e.preventDefault();
  await fetch("/api/setpoints",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"v="+$("vv").value+"&i="+$("ii").value+"&soc="+$("ss").value});
};
$("scan").onclick=async()=>{
  const r=await (await fetch("/api/wifi/scan")).json();
  $("nets").innerHTML=""; $("pwbox").classList.add("hide");
  (r.nets||[]).forEach(n=>{
    const li=document.createElement("li"); li.textContent=n;
    li.onclick=()=>{pick=n; $("chosen").textContent=n; $("pwbox").classList.remove("hide");};
    $("nets").appendChild(li);
  });
};
$("join").onclick=async()=>{
  $("sip").textContent="wait";
  await fetch("/api/wifi/join",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"ssid="+encodeURIComponent(pick)+"&pass="+$("pw").value});
};
$("orig").onclick=async()=>{ await fetch("/api/boot/original",{method:"POST"}); };
$("ota").onclick=()=>{
  const f=$("bin").files[0]; if(!f||f.size>0x190000) return;
  const xhr=new XMLHttpRequest(); xhr.timeout=120000; xhr.open("POST","/api/ota");
  xhr.upload.onprogress=(e)=>{ if(e.lengthComputable) $("bar").value=e.loaded/e.total*100; };
  xhr.onload=()=>{ $("sip").textContent=xhr.responseText; };
  xhr.send(f);
};
