#pragma once
#include "lvgl.h"
extern const lv_font_t lv_font_ru_14;
