# Step 20 Index

**Focus:** Residual state-byte model, error/stop relay paths, ADC–protocol correlation, updated call graph.

## New documents

- `step20_residual_state_error_adc.md`
- `call_graph_step20.json`
- `gpio_residual_step20.csv`
- `step20_index.md`

## Key results

1. Main state `0x3FCA0B1D` confirmed; substate model tightened (`0x3FCA0B0C` / `0x3FCA0B15`).
2. GPIO7 LOW outside init still has **no confirmed call-site** — expected in stop/error/idle.
3. `0x3FCA0AA8` is voltage-related (CAN CCS path, BCP, ADC secondary, BLE 0x0E).
4. Primary ADC `0x3FCA0C04` unit still open.
5. Safe reconstruction rule: always force both relays OFF on stop/error/idle.

## Next (Step 21)

Disassembly residual sweep: all jal to relay wrappers, all stores in 0x3FCA0B00..B30, readers of 0x3FCA0C04, LEDC duty sites.
