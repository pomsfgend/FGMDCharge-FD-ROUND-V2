# ПРОХОД 20 — Residual State Bytes + Error/Stop Paths + ADC Correlation + Call Graph Update

**Дата:** 2026-10-06  
**Фокус:** Уточнение модели state/substate, error/stop пути реле, связь ADC-глобалей с протоколом/UI, обновлённый call graph.

## 1. Scope

- Консолидация всех известных writers/readers байтов в зоне `0x3FCA0B0x`.
- Поиск и классификация error/stop/idle путей, где GPIO7 должен возвращаться в LOW.
- Корреляция ADC-результатов с уже известными protocol globals.
- Residual GPIO и обновлённый логический call graph.
- Без изобретения callers, которых нет в предыдущих дизассемблерных следах.

## 2. Модель state / substate (уточнённая) [HIGH → частично CONFIRMED]

| Адрес | Роль | Confidence | Примечание |
|-------|------|------------|-----------|
| `0x3FCA0B1D` | **Main GB/T state** (0..7) | CONFIRMED | Диспетчер `0x4200C078`; читается в `0x4200C102` |
| `0x3FCA0B0C` | Application / protocol substate + BLE target | HIGH | Пишется BLE `0x66`/`0x0D`; используется как gate реле в части документов |
| `0x3FCA0B15` | Internal protocol substate (2/3/4/5) | HIGH | В step4 явно: state3→2, state4→3, после реле→4, stop→5 |
| `0x3FCA0B13` | Transport/substate (earlier docs) | MEDIUM | Может быть alias или соседний байт |
| `0x3FCA0B20` | Protocol timing / entry timestamp | HIGH | Записывается при переходах |
| `0x3FCA0B24` | Protocol status/flag | MEDIUM | |

**Рабочая модель для реконструкции:**

```
Main state (0x3FCA0B1D)     = 0..7   ← диспетчеризация SM
Protocol substate           = 2/3/4/5 ← gate реле и фаза внутри charging
Application override byte   = 0x3FCA0B0C ← BLE может писать 3 или 6
```

Точное побайтовое совпадение `0x3FCA0B0C` ↔ `0x3FCA0B15` остаётся **HIGH** (не полностью доказано одним дизассемблерным xref). Функционально оба участвуют в gate и external control.

### Известные writers main state `0x3FCA0B1D`

| Контекст | Значение | Confidence |
|----------|----------|------------|
| State 1 → 2 | 2 | CONFIRMED |
| Все переходы внутри `0x4200C078` | 0..7 | CONFIRMED |
| Idle / reset path | 0 | CONFIRMED |
| BLE path | косвенно (через substate 3/6) | HIGH |

### Известные writers `0x3FCA0B0C`

| Источник | Значение | Confidence |
|----------|----------|------------|
| BLE cmd `0x66` val=0 | 6 | CONFIRMED |
| BLE cmd `0x66` val=1 | 3 | CONFIRMED |
| BLE cmd `0x0D` | 6 | CONFIRMED |

## 3. Error / Stop / Idle пути и GPIO7 [HIGH / частично UNKNOWN]

### Что подтверждено

- **State 6 (STOP_CHARGING):** отправляет BST, termination counter ≤ 9, ~1 с.  
  Документы отмечают «обычно GPIO6 LOW». Прямого call-site `0x4200C8A6` (GPIO7 LOW) в state 6 пока **не найдено**.
- **State 7 (FINALIZE_ERROR_CHECK):** timeout 5 с, возможны BSD / BEM.  
  Возврат в idle. Прямого call-site GPIO7 LOW не выделен.
- **BOOT init:** GPIO6=0, GPIO7=0, GPIO2=1 — **CONFIRMED**.
- **BLE путь:** никогда не драйвит GPIO7.

### Гипотеза (HIGH CONFIDENCE, требует xref)

GPIO7 LOW (`0x4200C8A6`) вызывается:

1. В общем reset/idle path при возврате в state 0.
2. Возможно в error handling внутри state 7 или при CEM/timeout.
3. Возможно в `0x4200AAD0` при определённых флагах (timer producer).

Пока **нет CONFIRMED call-site** `0x4200C8A6` кроме init. Это главный residual по реле.

### Безопасная модель для реконструкции

При любом выходе из charging (state 6/7 → 0) и при fault:

```c
GPIO6 = 0;
GPIO7 = 0;   // даже если оригинальный call-site ещё не найден
```

Это соответствует init и ожидаемому fail-safe поведению.

## 4. ADC correlation — прогресс [HIGH]

### Primary ADC path (GPIO0)

```
GPIO0 → ADC1 ch0 → oneshot → calibration → 0x4200D0C4 filter
  acc = acc + sample; acc -= (acc >> 6);
  x = ((acc & ~0x3F) - (acc >> 6)) * 5 / 0x500;
  → 0x3FCA0C04
```

Readers of `0x3FCA0C04` пока **не полностью восстановлены**.

### Secondary path (связь с протоколом)

```
0x3FCA0AA8  ←  CAN RX path (CCS-related voltage raw / 10)
             ←  BLE cmd 0x0E (value/10)
             ←  factory default 0x0168 (360)
             →  used in BCP generator: 10 * (0x3FCA0AA8 - 20)
             →  used in ADC secondary: v = ((0x3FCA0AA8 - 0x14) * 5 * 256) / 0xFD
             →  0x3FCA0C08
```

**Вывод [HIGH]:**  
`0x3FCA0AA8` — это **voltage-related engineering value** (0.1 V resolution class), который одновременно:

- кормится из CAN (CCS),
- может перезаписываться BLE,
- участвует в BCP,
- участвует во втором ADC-масштабировании.

Primary ADC result `0x3FCA0C04` скорее всего связан с другой физической величиной (ток / температура / feedback), но прямого доказательства ещё нет.

### Связь с UI

LVGL/UI использует runtime-глобали из зоны `0x3FCA0Axx` / status packet `0x3FC98170`.  
Прямая привязка `0x3FCA0C04` → конкретный widget пока **UNKNOWN**.  
Status packet builder `0x420093FE` включает state byte и configuration block, но ADC-поля в нём ещё не размечены.

## 5. Обновлённый consolidated call graph

```
BOOT
  └─ GPIO6=0, GPIO7=0, GPIO2=1

myTask_CAN loop
  └─ 0x4200C078 (SM, 10 ms)
        ├─ State 4 ──────────────► 0x4200C870 (GPIO6=1)
        ├─ State 5 + 10s + sub==3 ► 0x4200C882 (GPIO6=0)
        │                          0x4200C894 (GPIO7=1)
        ├─ State 6 (STOP) ───────► GPIO6 обычно 0; GPIO7 LOW? [UNKNOWN site]
        └─ State 7 / return 0 ───► expected both relays OFF [site pending]

myTask_BLE / GATTS WRITE
  └─ 0x66 / 0x0D ───────────────► только GPIO6 + 0x3FCA0B0C = 3|6

0x4200AAD0 (timer/data producer)
  └─ flags 0x3FCA0A9C / AA4 / AC8 ─► possible relay wrappers [HIGH]

ADC path (GPIO0)
  └─ 0x4200D0C4 ─► 0x3FCA0C04 (primary)
                 ─► 0x3FCA0C08 (from 0x3FCA0AA8 voltage-related)
```

## 6. Residual GPIO status (step 20)

| GPIO | Status | Confidence | Notes |
|------|--------|------------|-------|
| 0 | ADC runtime | CONFIRMED | Unit of primary result still open |
| 1 | I2C SDA | CONFIRMED | CST816 |
| 2 | Strapping | CONFIRMED | Never drive as output |
| 3 | LEDC PWM 60 kHz | CONFIRMED HW | Duty + load UNKNOWN |
| 4 | SPI CS | CONFIRMED | |
| 5 | SPI MOSI | CONFIRMED | |
| 6 | Relay A | CONFIRMED | Sequenced |
| 7 | Relay B | CONFIRMED | Main power; LOW path residual |
| 8 | I2C SCL | CONFIRMED | |
| 9 | TWAI RX | CONFIRMED | |
| 10 | TWAI TX | CONFIRMED | |
| 11 | — | UNKNOWN | |
| 18 | SPI DC | CONFIRMED | |
| 19 | SPI SCLK | CONFIRMED | |
| 20 | — | HYPOTHESIS only | Not in original app gpio_set_level |
| 21 | — | UNKNOWN | |

## 7. Практические выводы для реконструкции прошивки

1. **Fail-safe:** при любом stop/error/idle явно ставить оба реле в 0.  
2. **10 s settle** обязателен перед GPIO7 HIGH.  
3. **GPIO2** не трогать.  
4. **External control** (BLE/app) должен уметь только GPIO6 + state 3/6, как оригинал.  
5. **0x3FCA0AA8** трактовать как voltage-related (0.1 V class) — это уже можно использовать в UI и BCP.  
6. Primary ADC (`0x3FCA0C04`) пока не привязывать к конкретной величине без дополнительных данных.

## 8. Что осталось неизвестным (приоритет)

1. **CONFIRMED call-site `0x4200C8A6`** (GPIO7 LOW) — главный residual реле.  
2. Полный список store в `0x3FCA0B1D` / `0x3FCA0B0C` / `0x3FCA0B15` (один дизассемблерный xref pass).  
3. Readers `0x3FCA0C04` → UI / BCL / BCS.  
4. Duty-cycle set points GPIO3.  
5. Точная роль `0x4200AAD0` в управлении реле.  
6. Residual GPIO 11/20/21.

## 9. Следующий крупный проход (ПРОХОД 21)

**Дизассемблерный residual sweep + GPIO7 LOW site + ADC readers + PWM duty.**

Конкретно:
- Поиск всех `jal` / `jalr` на `0x4200C870..C8A6`.
- Поиск всех store в диапазон `0x3FCA0B00..0x3FCA0B30`.
- Readers `0x3FCA0C04` / `0x3FCA0C08`.
- Любые LEDC duty update call-sites.
- Финальная consolidated reconstruction map (state + relay + ADC + tasks).

---

**Уровни доказательности:**

- Main state `0x3FCA0B1D` + SM transitions — **CONFIRMED**.  
- BLE пишет только GPIO6 + `0x3FCA0B0C` — **CONFIRMED**.  
- `0x3FCA0AA8` = voltage-related (CAN + BCP + ADC secondary) — **HIGH**.  
- GPIO7 LOW вне init — **UNKNOWN site** (ожидается в stop/error).  
- Primary ADC unit — **UNKNOWN**.
