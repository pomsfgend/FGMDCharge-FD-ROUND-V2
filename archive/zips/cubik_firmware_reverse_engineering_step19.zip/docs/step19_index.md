# Step 19 Index

**Focus:** Relay call-site XREF, state/substate writers, ADC/PWM residual, consolidated logical call graph.

## New documents

- `step19_relay_xref_state_writers_residual.md` — полный отчёт
- `relay_call_map_step19.json` — машиночитаемая карта callers реле
- `state_bytes_step19.json` — разделение main state vs application substate
- `step19_index.md`

## Key results

1. Main power hand-off (GPIO6↓ + GPIO7↑) occurs **only** from State 5 timed path.
2. BLE `0x66` / `0x0D` control **only GPIO6** and write `0x3FCA0B0C`.
3. Main state byte `0x3FCA0B1D` confirmed; substate address still has aliasing (`0x3FCA0B0C` / `0x3FCA0B15`).
4. `0x4200AAD0` is a third potential relay path (HIGH).
5. ADC runtime formulas confirmed; physical unit still UNKNOWN.
6. GPIO2 strapping confirmed; GPIO20 not in original app code.

## Next (Step 20)

Full residual store/xref sweep on `0x3FCA0B00..B30`, all `jal` to relay wrappers, ADC↔UI correlation, error-path GPIO7 LOW.
