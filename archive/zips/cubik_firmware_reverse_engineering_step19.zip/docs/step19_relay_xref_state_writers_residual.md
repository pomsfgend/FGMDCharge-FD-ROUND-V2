# ПРОХОД 19 — Relay XREF + State Writers + ADC/PWM Residual + Call Graph

**Дата:** 2026-10-06  
**Фокус:** Полный известный граф вызовов обёрток реле, места изменения charging state / substate, residual ADC/PWM, консолидация противоречий адресов.

## 1. Scope и метод

- Собраны все уже доказанные call-sites обёрток `0x4200C870 / C882 / C894 / C8A6`.
- Уточнены два связанных байта состояния (`0x3FCA0B1D` vs `0x3FCA0B0C` / `0x3FCA0B15`).
- Проверены secondary paths (BLE `0x66`, `0x0D`, timer producer `0x4200AAD0`).
- Residual: ADC runtime, PWM, GPIO2/20.
- Не изобретались новые callers без бинарного следа.

## 2. Relay wrappers — полный известный call map [CONFIRMED]

```text
0x4200C870  →  gpio_set_level(GPIO6, 1)   // HIGH
0x4200C882  →  gpio_set_level(GPIO6, 0)   // LOW
0x4200C894  →  gpio_set_level(GPIO7, 1)   // HIGH
0x4200C8A6  →  gpio_set_level(GPIO7, 0)   // LOW
```

### Известные call-sites

| Call site          | Вызываемая обёртка | Эффект              | Контекст / условие                                      | Confidence  |
|--------------------|-------------------|---------------------|---------------------------------------------------------|-------------|
| `0x4200C2FA`       | `0x4200C882`      | GPIO6 = LOW         | State 5, elapsed ≥ 10000 ms **и** substate == 3         | CONFIRMED   |
| `0x4200C2FC`       | `0x4200C894`      | GPIO7 = HIGH        | сразу после предыдущего (one-shot hand-off)             | CONFIRMED   |
| State 4 entry path | `0x4200C870`      | GPIO6 = HIGH        | READY_WAIT_CRO / pre-charge                             | CONFIRMED   |
| BLE cmd `0x66` val=0 | `0x4200C882`    | GPIO6 = LOW         | Application protocol; одновременно state/substate → 6  | CONFIRMED   |
| BLE cmd `0x66` val=1 | `0x4200C870`    | GPIO6 = HIGH        | Application protocol; одновременно state/substate → 3  | CONFIRMED   |
| Init path          | direct            | GPIO6=0, GPIO7=0, GPIO2=1 | Output initialization at boot                        | CONFIRMED   |

**Не найдено (пока):**
- Прямых callers `0x4200C8A6` (GPIO7 LOW) вне init / error-path (возможны в state 0/6/7, но точный адрес ещё не выделен).
- Callers GPIO7 HIGH кроме `0x4200C2FC`.

**Вывод:** основной силовой hand-off (GPIO6↓ + GPIO7↑) происходит **только** из state-5 timer path. BLE путь управляет **только GPIO6** и связанным state/substate.

## 3. Два байта состояния — консолидация [HIGH / частично CONFIRMED]

В документации предыдущих шагов встречаются три близких адреса:

| Адрес        | Роль в разных проходах                          | Текущий статус                          |
|--------------|------------------------------------------------|-----------------------------------------|
| `0x3FCA0B1D` | main GB/T charging state (0..7), читается в `0x4200C102` | **CONFIRMED** как главный диспетчер SM |
| `0x3FCA0B0C` | в relay check (step3/18) и в BLE `0x66`/`0x0D` | используется и как substate, и как target записи BLE |
| `0x3FCA0B15` | internal substate (step4: =2 в state3, =3 в state4, =4 после реле, =5 в stop) | **HIGH** — transport/protocol substate |

**Рабочая модель (HIGH CONFIDENCE):**

- `0x3FCA0B1D` — **главный state** (0–7), по которому диспетчеризуется `0x4200C078`.
- `0x3FCA0B0C` / `0x3FCA0B15` — **связанные substate / application state** байты.  
  BLE-команды пишут в `0x3FCA0B0C`.  
  Проверка «substate == 3» перед реле в state 5 использует значение, которое в разных проходах называлось `0x3FCA0B0C` или `0x3FCA0B15`.  
  Точное совпадение адресов требует ещё одного pass по дизассемблеру; функционально оба байта участвуют в gate реле и в external control.

**Известные writers главного state `0x3FCA0B1D`:**

| Writer context              | Новое значение | Confidence |
|-----------------------------|----------------|------------|
| State 1 → 2 transition      | 2              | CONFIRMED  |
| Внутри `0x4200C078` (все переходы 0↔7) | 0..7     | CONFIRMED  |
| BLE / application path      | косвенно через 0x3FCA0B0C → влияние на SM | HIGH     |
| Reset / idle path           | 0              | CONFIRMED  |

**Известные writers `0x3FCA0B0C` (BLE/application):**

| Command | Действие                                      | Confidence |
|---------|-----------------------------------------------|------------|
| `0x66` val=0 | GPIO6 LOW + write 6                           | CONFIRMED  |
| `0x66` val=1 | GPIO6 HIGH + write 3                          | CONFIRMED  |
| `0x0D`       | write 6                                       | CONFIRMED  |

## 4. Timer / data producer `0x4200AAD0` [HIGH]

Функция:

- Читает 32-bit аккумулятор `0x3FCA0AE8`.
- Делит на `0xEA60` (60000).
- Обновляет `0x3FCA0A92` / `0x3FCA0A94..95`.
- Оценивает флаги `0x3FCA0A9C`, `0x3FCA0AA4`, `0x3FCA0AC8`.
- **Вызывает relay wrappers** (по step9) — точные условия вызова ещё не полностью разобраны, но это третий потенциальный путь управления реле помимо SM и BLE.

Это связывает local timing/charge-data с силовым контуром.

## 5. ADC residual (GPIO0) [CONFIRMED runtime, unit UNKNOWN]

Функция `0x4200D0C4`:

```c
acc = acc + sample;
acc = acc - (acc >> 6);          // IIR-like
x   = (acc & ~0x3F) - (acc >> 6);
x   = x * 5;
x   = x / 0x500;
// result → 0x3FCA0C04
```

Вторая величина:

```c
v = ((value - 0x14) * 5 * 256) / 0xFD;   // value from 0x3FCA0AA8
// → 0x3FCA0C08
```

**Физическая величина по-прежнему UNKNOWN.** Кандидаты: напряжение шины, ток, температура, analog feedback силовой части. Требуется либо PCB, либо корреляция с отображаемыми UI-значениями / CAN fields.

## 6. PWM residual (GPIO3) [CONFIRMED hardware, load UNKNOWN]

- LEDC channel 0, ≈60 кГц, 10-bit resolution.
- Duty-cycle transitions в application code пока не восстановлены до конкретных call-sites.
- Возможные потребители: вентилятор, buzzer, PWM-управление зарядным модулем, индикация.  
  **Не backlight** (в оригинале BL GPIO = –1).

## 7. GPIO2 / GPIO20

| GPIO | Статус | Примечание |
|------|--------|------------|
| 2    | CONFIRMED strapping | Init HIGH. Driving as output → POWERON reboot loop (аппаратно подтверждено). |
| 20   | HYPOTHESIS / reconstruction only | В оригинальном application code прямых `gpio_set_level(20, …)` не обнаружено. Появляется в реконструированных прошивках. |

## 8. Consolidated call graph (логический)

```
myTask_CAN
   │
   └─► 0x4200C078  (GB/T state machine, 10 ms quantum)
          │
          ├─ State 4 ──► 0x4200C870  (GPIO6 = 1)
          │
          └─ State 5 + 10s + substate==3
                 ├─► 0x4200C882  (GPIO6 = 0)
                 └─► 0x4200C894  (GPIO7 = 1)

myTask_BLE / GATTS WRITE
   │
   └─► cmd 0x66 / 0x0D
          ├─► 0x4200C882 or 0x4200C870  (только GPIO6)
          └─► write 0x3FCA0B0C = 6 or 3

0x4200AAD0  (timer/data producer)
   │
   └─► (evaluates flags) ──► possible relay wrappers   [HIGH, exact sites pending]

BOOT init
   └─► GPIO6=0, GPIO7=0, GPIO2=1
```

## 9. Что это значит для реконструкции поведения

1. Силовой hand-off (оба реле) жёстко привязан к **state 5 + 10 с + substate gate**.  
2. Внешний BLE/application протокол может только управлять GPIO6 и «подталкивать» state/substate между 3 и 6.  
3. Для безопасной замены прошивки необходимо:
   - воспроизвести 10-секундный settle timer;
   - не драйвить GPIO2;
   - сохранить возможность external override через команду, эквивалентную `0x66`.

## 10. Оставшиеся неизвестные (приоритет следующего прохода)

1. Точный адрес всех writers `0x3FCA0B1D` вне центральной SM (полный xref).  
2. Единая таблица соответствия `0x3FCA0B0C` ↔ `0x3FCA0B15` ↔ substate values 2/3/4/5.  
3. Все callers `0x4200C8A6` (GPIO7 LOW) — особенно в error / stop / idle.  
4. Точные условия, при которых `0x4200AAD0` вызывает реле.  
5. Duty-cycle set points на GPIO3.  
6. Физическая единица ADC на GPIO0.  
7. Residual GPIO 11/20/21 и любые interrupt-driven GPIO.

## 11. Следующий крупный проход (ПРОХОД 20)

**Полный residual sweep + точная таблица state/substate bytes + error-path реле + ADC/UI correlation.**

Приоритет:
- Дизассемблерный pass по всем store в диапазон `0x3FCA0B00..0x3FCA0B30`.
- Поиск всех `jal` на `0x4200C870..C8A6`.
- Связь ADC-результатов `0x3FCA0C04/C08` с UI / BCL / BCS полями.
- Финальная consolidated GPIO + relay + state machine карта для реконструкции.

---

**Уровни доказательности в этом проходе:**

- Известные call-sites реле — **CONFIRMED**.  
- Главный state `0x3FCA0B1D` — **CONFIRMED**.  
- BLE пишет в `0x3FCA0B0C` и управляет только GPIO6 — **CONFIRMED**.  
- Точное совпадение адресов substate (`0x3FCA0B0C` vs `0x3FCA0B15`) — **HIGH / требует уточнения**.  
- `0x4200AAD0` вызывает реле — **HIGH**.  
- Физические роли GPIO0/3 — **UNKNOWN**.
