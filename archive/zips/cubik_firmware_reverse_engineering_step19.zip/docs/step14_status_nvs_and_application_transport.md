# Cubik firmware reverse engineering — Step 14

## Scope
Large correction/expansion pass for the 64-byte application status frame, its persistence path, and the runtime application transport around `0x4200A5xx..0x4200ACxx`.

## 1. Exact 64-byte frame

`0x420093FE` constructs exactly 64 bytes at `0x3FC98170` and copies them as four 16-byte blocks.

| offset | source / expression | encoding | confidence |
|---:|---|---|---|
| 0 | constant `0xFB` | byte | CONFIRMED |
| 1 | `0x3FCA0AF4` | byte | CONFIRMED |
| 2 | `0x3FCA0AC9` | byte | CONFIRMED |
| 3 | `0x3FCA0AC8` | byte | CONFIRMED |
| 4..20 | `0x3FC981B0..0x3FC981C0` | raw 17-byte block | CONFIRMED |
| 21 | `0` | byte | CONFIRMED |
| 22..23 | `0x3FCA0A88` | LE16 | CONFIRMED |
| 24..25 | `0x3FCA0A84` | signed LE16 | CONFIRMED |
| 26..27 | `0x3FCA0A80` | LE16 | CONFIRMED |
| 28..29 | `0` | bytes | CONFIRMED |
| 30..31 | `0x3FCA0A9E` | BE16 | CONFIRMED |
| 32 | `0x3FCA0A9C` | byte | CONFIRMED |
| 33..34 | `0x3FCA0AB0` | raw 2 bytes | CONFIRMED |
| 35..36 | `0x3FCA0AFC` | raw 2 bytes | CONFIRMED |
| 37..38 | `0x3FCA0B04` | raw 2 bytes | CONFIRMED |
| 39 | `0x3FCA0A9D` | byte | CONFIRMED |
| 40..41 | `0x3FCA0AF8` / `+1` | raw 2 bytes | CONFIRMED |
| 42 | `0x34` | constant | CONFIRMED |
| 43..44 | `0x3FCA0B00` | raw 2 bytes | CONFIRMED |
| 45 | `0x9B` | constant | CONFIRMED |
| 46..47 | derived from `0x3FCA0C24`: `((5*x)<<1)>>8`, `(5*(x&0xFF))<<1` | bytes | CONFIRMED |
| 48..49 | `0x3FCA0B0C` / `+1` | raw 2 bytes | CONFIRMED |
| 50 | `0x9B` | constant | CONFIRMED |
| 51..52 | `0x3FCA0A94` | raw 2 bytes | CONFIRMED |
| 53..54 | `0x3FCA0A7C` | raw 2 bytes | CONFIRMED |
| 55..57 | `0x3FCA0AAC` | 24-bit raw | CONFIRMED |
| 58..59 | high/low bytes of `0x3FCA0C24` | BE-style split | CONFIRMED |
| 60 | `0xFE` | byte | CONFIRMED |
| 61 | `0xFE`? see note | byte | HIGH |
| 62 | `0xFE` | byte | CONFIRMED |
| 63 | `0x7C` | terminator | CONFIRMED |

### Alignment correction
The compiler writes byte 0x3E as `0xFE` and byte 0x3F as `0x7C`. The exact byte 0x3D is the low byte of `0x3FCA0C24`; therefore any semantic interpretation must use the raw disassembly rather than the earlier approximate field map.

## 2. Critical correction: persistence, not direct BLE notify

Earlier analysis incorrectly described the 64-byte builder as if the direct caller at `0x4200993C` were a BLE notification call.

The actual call sequence is:

```text
0x420093FE
    -> builds 64 bytes at 0x3FC98170
0x4200993C / 0x420099C8 / 0x4200A666 / 0x4200ABE4
    -> open NVS handle
    -> 0x420BE2CE(handle, "Alldata", buffer, 0x40)
    -> commit/close path
```

`0x420BE2CE` dispatches through an object vtable at offset `+0x0C` with `(key, data, length)`, matching a blob-write operation. The key pointer used by these callers is the DROM string `"Alldata"`.

Therefore:

**The 64-byte frame is a persistent `Alldata` NVS blob. It is not, by itself, evidence of a BLE notification payload.**

This correction is important for replacement firmware architecture.

## 3. Runtime update path

`0x4200A566..0x4200A666` updates application variables from incoming data and immediately calls the 64-byte builder, then persists the resulting blob as `Alldata`.

The sequence is therefore:

```text
incoming application command/data
        |
        v
runtime configuration globals 0x3FCA....
        |
        v
0x420093FE
        |
        v
64-byte Alldata snapshot @ 0x3FC98170
        |
        v
NVS blob key "Alldata"
```

## 4. Persistent configuration block

Factory/default initializer `0x4200930E` writes:

- `0x3FCA0A88 = {0x000E, 0x0010}`
- `0x3FCA0A80 = {0x0010, 0x0068}`
- `0x3FCA0A84 = {0x0003, 0x00E8}`
- `0x3FCA0AA8 = 0x0168`
- `0x3FCA0AA6 = 0x0064`
- `0x3FCA0A9D = 0xE8` (signed interpretation depends on consumer)
- `0x3FCA0A9E = 0x0064`
- `0x3FCA0A90..91 = 03 E8`
- `0x3FCA0A7C..7D = 0D 08`
- zeroes `0x3FCA0AAC..AE`
- `0x3FCA0AC9 = 1`
- copies a 20-byte factory structure from DROM `0x3C0F66A0` to runtime `0x3FC981B0`.

## 5. Application transport path

The calls at `0x4200ABE4` show another layer after the NVS update:

```text
Alldata persisted
      |
      +--> 0x42046492(...)
             |
             +--> builds a small framed message
             +--> 0x42081E20(...)
```

`0x42046492` constructs a message with header bytes including `0x00 0x02 0x0C` and copies runtime identifiers/length/data into it. This is a candidate application transport/queue path, but it is **not yet labeled as BLE** without tracing `0x42081E20` and its consumers.

## 6. New semantic observation

`0x4200ABE4` first calls the status builder, then reads the 64-byte buffer and passes it into the generic transport call. Therefore `Alldata` is both:

1. persisted configuration/status state, and
2. an input to a separate application transport mechanism.

The transport mechanism is the next target; it must not be conflated with the NVS operation.

## 7. Corrected architecture

```text
                    +------------------+
                    | GB/T CAN runtime |
                    +---------+--------+
                              |
                              v
                    +------------------+
                    | 0x3FCA... state  |
                    +---------+--------+
                              |
             +----------------+----------------+
             |                                 |
             v                                 v
      64-byte Alldata                    CAN payloads
             |
       +-----+-----+
       |           |
       v           v
      NVS      application transport
                  |
                  v
          BLE/other transport
          (still to prove)
```

## 8. Next large-pass targets

1. Trace `0x42081E20` and identify its transport backend.
2. Identify the exact BLE notify/indicate sender and handles.
3. Decode the `Alldata` semantic fields using all writers/readers.
4. Continue the LVGL/CST816 event tree and connect UI fields to the same `0x3FCA...` variables.
5. Resolve OTA framing.
