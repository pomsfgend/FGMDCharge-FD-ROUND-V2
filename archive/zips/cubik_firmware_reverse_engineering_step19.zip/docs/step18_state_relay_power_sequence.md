# ПРОХОД 18 — State Machine → CAN → Timers → GPIO6/GPIO7 Power Sequence

**Дата:** 2026-10-06  
**Фокус:** Полная причинно-следственная реконструкция зарядной state machine, 10-секундной задержки и последовательности включения силовой части.

## 1. Scope

- Центральная функция `0x4200C078` (вызывается из `myTask_CAN`).
- Обёртки реле `0x4200C870` / `0x4200C882` / `0x4200C894` / `0x4200C8A6`.
- Прямые вызовы в state 4 и state 5.
- Time quantum 10 ms (`0x4200B910(10)`).
- Константа `0x2710` = 10000 → 10 с.
- Два независимых пути управления реле (протокольный + application/BLE).
- Коррекция полярности GPIO6/GPIO7 на основе всех предыдущих дизассемблерных следов.

## 2. Time base [CONFIRMED]

Каждый активный цикл state machine:

```c
function_B910(10);   // 0x4200B910
```

Аккумулятор 16-bit по адресу `0x3FC981F0`.  
Следовательно:

| Константа | Значение | Физическое время |
|-----------|----------|------------------|
| 0x64      | 100      | 100 мс           |
| 0xC8      | 200      | 200 мс           |
| 0x3E8     | 1000     | 1 с              |
| 0x1388    | 5000     | 5 с              |
| **0x2710**| **10000**| **10 с**         |

## 3. Главная переменная состояния [CONFIRMED]

```text
0x3FCA0B1D   // main GB/T charging state (0..7)
```

Чтение в `0x4200C102`, запись во всех переходах.

Ключевые соседние флаги/таймеры (структура от `0x3FC98200`):

| Адрес        | Offset | Назначение                          |
|--------------|--------|-------------------------------------|
| 0x3FC98218   | +0x18  | CHM timestamp                       |
| 0x3FC9821C   | +0x1C  | CRM timestamp                       |
| 0x3FC98220   | +0x20  | CTS timestamp                       |
| 0x3FC98224   | +0x24  | CML timestamp                       |
| 0x3FC98228   | +0x28  | CRO timestamp                       |
| 0x3FC9822C   | +0x2C  | CCS timestamp                       |
| 0x3FC98230   | +0x30  | CST timestamp                       |
| 0x3FC98234   | +0x34  | CSD timestamp                       |
| 0x3FC98238   | +0x38  | CEM timestamp                       |
| 0x3FC9823C   | +0x3C  | CRM status byte (0xAA = success)    |
| 0x3FC9823E   | +0x3E  | CRO status byte (0xAA = ready)      |
| 0x3FC98208   | +0x08  | state-machine elapsed counter       |
| 0x3FCA0B0C   | —      | protocol substate (критичен для реле)|
| 0x3FCA0B13   | —      | transport/substate                  |
| 0x3FCA0B20   | —      | protocol timing/flag                |

## 4. Обёртки реле [CONFIRMED]

```text
0x4200C870  →  gpio_set_level(6, 1)   // GPIO6 HIGH
0x4200C882  →  gpio_set_level(6, 0)   // GPIO6 LOW
0x4200C894  →  gpio_set_level(7, 1)   // GPIO7 HIGH
0x4200C8A6  →  gpio_set_level(7, 0)   // GPIO7 LOW
```

Инициализация при старте (из output-init функции):

```c
gpio_set_level(6, 0);
gpio_set_level(7, 0);
gpio_set_level(2, 1);   // strapping pin — НЕ использовать как выход
```

## 5. Точная последовательность реле [CONFIRMED]

### State 4 (READY_WAIT_CRO / pre-charge)

При входе / в активной фазе:

- вызывается `0x4200C870` → **GPIO6 = HIGH**
- substate устанавливается в 3
- отправляется BRO с data[0] = 0xAA
- ожидается CRO с data[0] = 0xAA

### State 5 (CHARGING) — 10-секундная задержка

После входа в state 5 elapsed counter идёт от нуля.  
Когда одновременно:

1. `elapsed >= 0x2710` (10 000 мс)
2. `substate (0x3FCA0B0C) == 3`

выполняется:

```text
0x4200C2FA  →  call 0x4200C882  →  GPIO6 = 0   (LOW)
0x4200C2FC  →  call 0x4200C894  →  GPIO7 = 1   (HIGH)
```

Это **однократный** переход (не периодический).

### Интерпретация (HIGH CONFIDENCE)

Последовательность выглядит как **sequenced contactors**:

1. GPIO6 HIGH в state 4 — подготовка / pre-charge / isolation-side / auxiliary.
2. После 10 с стабильного charging + подтверждённого substate GPIO6 сбрасывается, GPIO7 включается — основное силовое реле (или вторая группа контактов на два зарядных модуля).

Точная электрическая роль (какое именно реле на плате) требует PCB-трассировки. Бинарник доказывает только порядок и условия.

## 6. Полная карта состояний 0–7 (уточнённая)

| State | Имя                        | Confidence   | Основные TX                          | Условия перехода / действия                  | Реле / GPIO                  | Timeout / delay |
|-------|----------------------------|--------------|--------------------------------------|----------------------------------------------|------------------------------|-----------------|
| 0     | IDLE_RESET                 | CONFIRMED    | —                                    | Сброс timestamps, counters, substate         | 6=0, 7=0 (init)              | —               |
| 1     | HANDSHAKE_INIT             | CONFIRMED    | —                                    | Мгновенный переход в 2, очистка флагов       | —                            | очень короткий  |
| 2     | WAIT_CRM_IDENTIFICATION    | CONFIRMED    | BHM 0x182756F4, BRM 0x180256F4       | CRM status == 0xAA                           | —                            | ~1 с retry      |
| 3     | PARAMETER_CONFIGURATION    | CONFIRMED    | BCP 0x180656F4                       | CTS + CML timestamps заполнены               | —                            | —               |
| 4     | READY_WAIT_CRO             | CONFIRMED    | BRO 0x100956F4 (data[0]=0xAA)        | CRO data[0]==0xAA; substate=3                | **GPIO6 = HIGH**             | —               |
| 5     | CHARGING                   | CONFIRMED    | BCL 0x181056F4, BSM 0x181356F4, BCS 0x181156F4 | —                                        | после 10 с + substate==3: **GPIO6=LOW, GPIO7=HIGH** | **10 000 мс** |
| 6     | STOP_CHARGING              | CONFIRMED    | BST 0x101956F4 (+ BCL tail)          | termination counter ≤ 9                      | обычно GPIO6 LOW             | ~1 с            |
| 7     | FINALIZE_ERROR_CHECK       | HIGH         | BSD / optional BEM 0x081E56F4        | —                                            | —                            | 5 000 мс        |

## 7. Два независимых пути управления реле [CONFIRMED]

1. **Протокольный путь** (выше) — жёстко привязан к state machine.
2. **Application / BLE путь** (GATTS WRITE, команда типа `0x66`):
   - byte 10 == 0 → GPIO6 LOW + state = 6
   - byte 10 == 1 → GPIO6 HIGH + state = 3

Следствие: устройство не является прозрачным мостом. Локальный протокол (в т.ч. через BLE) может принудительно менять силовое состояние.

## 8. Физическая интерпретация (согласование с наблюдениями пользователя)

Наблюдаемая пользователем последовательность:

1. Подключение → готовность адаптера
2. Handshake
3. Проверка кабеля / изоляции
4. Станция замыкает силовой тракт
5. Согласование параметров
6. Передача энергии

Бинарник добавляет:

- После CRO (state 4) GPIO6 поднимается HIGH.
- Только через **10 секунд** пребывания в state 5 + подтверждённый substate происходит переключение GPIO6→LOW / GPIO7→HIGH.
- Это даёт дополнительное окно settle / pre-charge / isolation confirm перед полной коммутацией двух зарядных модулей (~65,7 В / 7 А).

## 9. ADC / PWM (уточнение статуса)

### ADC GPIO0 [CONFIRMED hardware + runtime]

- Function `0x4200D0C4`
- Фильтр: `acc = acc + sample; acc = acc - (acc >> 6);`
- Масштабирование с константами 5 / 0x500
- Результат → `0x3FCA0C04`
- Вторая величина из `0x3FCA0AA8` → `0x3FCA0C08`
- **Физическая величина всё ещё UNKNOWN** (напряжение / ток / температура / feedback).

### PWM GPIO3 [CONFIRMED hardware]

- LEDC channel 0, ~60 кГц, 10-bit
- Физический потребитель (вентилятор / buzzer / DC-DC / charge module) — **UNKNOWN**
- Duty-cycle transitions пока не восстановлены полностью.

### GPIO2

- Strapping pin ESP32-C3.
- При инициализации выставляется HIGH.
- **Никогда не использовать как обычный выход** — вызывает POWERON reboot loop (подтверждено аппаратно в реконструкции).

### GPIO20

- В оригинальном дампе прямых `gpio_set_level(20, …)` в application code не обнаружено.
- Упоминание в проектной памяти относится к попыткам реконструированной прошивки, а не к оригинальному бинарнику.

## 10. FreeRTOS задачи (подтверждённые имена)

| Задача         | Роль                          | Confidence |
|----------------|-------------------------------|------------|
| myTask_CAN     | TWAI RX/TX + state machine    | CONFIRMED  |
| myTask_BLE     | GATTS + application commands  | CONFIRMED  |
| myTask_lcd     | LVGL + UI                     | CONFIRMED  |
| myTask_Timer   | периодические таймеры/данные  | CONFIRMED  |

CAN task в цикле вызывает `0x4200C078` (state machine).

## 11. Что осталось неизвестным

1. Полный xref всех callers обёрток реле (кроме уже найденных в state 4/5 и BLE 0x66).
2. Все места записи в `0x3FCA0B1D` (не только внутри 0x4200C078).
3. Точный смысл substate `0x3FCA0B0C` и флагов вокруг `0x3FCA0B20/B24`.
4. Физическая величина на GPIO0 (ADC).
5. Физический потребитель PWM на GPIO3.
6. Полный residual sweep оставшихся GPIO (20, 21 и др.).
7. Точные формулы всех payload BCL/BCS/BSM/BST/BSD/BEM (частично уже есть в step 7–9).

## 12. Следующий крупный проход (ПРОХОД 19)

**Полный xref-граф реле + все записи state + ADC/PWM duty + residual GPIO map + consolidated call graph.**

Приоритет:

1. Найти все callers `0x4200C870/C882/C894/C8A6`.
2. Найти все записи в `0x3FCA0B1D`.
3. Разобрать `0x4200AAD0` (timer/data producer) до конца.
4. Восстановить duty-cycle изменения на GPIO3.
5. Финальная таблица GPIO с уровнем доказательности.
6. Обновлённый `state_machine.json` + `relay_call_map.json`.

---

**Уровни доказательности в этом проходе:**

- Последовательность GPIO6 HIGH (state 4) → GPIO6 LOW + GPIO7 HIGH (state 5 + 10 с) — **CONFIRMED**.
- 10-секундная задержка — **CONFIRMED**.
- Два пути управления реле — **CONFIRMED**.
- Электрическая роль конкретного реле на плате — **HIGH CONFIDENCE / требует PCB**.
