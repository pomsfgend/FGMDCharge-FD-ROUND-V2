# Cubik firmware reverse engineering — Step 15

## Scope
Large pass over the application transport boundary, BLE GATT static data, and LVGL/BLE source remnants. The main correction is that `0x42081E20` is **not proven to be a BLE sender**.

## 1. `0x42081E20` — corrected classification

The function at `0x42081E20` accepts five arguments and constructs an owned message object:

- validates `a0` and the null/non-null consistency of `a1`/`a2`;
- allocates `payload_length + 4` bytes through `0x4208282E`;
- copies a 4-byte message header from `a0`;
- zero-fills and copies `a2` bytes from `a1` when payload exists;
- optionally invokes callback `a3(message, payload)`;
- posts the allocated message through `0x42081DF4`;
- optionally invokes completion/free callback `a4`;
- releases the message object on failure.

`0x42081DF4` forwards the message into the global application queue/context at `0x3FCA1E30` through `0x42085866`.

The consumer at `0x42085866` uses a queue/buffer object with counters and a dispatch callback table. This is therefore a **generic internal asynchronous message/queue layer**. It is not sufficient evidence to call it BLE transport.

Confidence:
- generic async message transport: HIGH
- direct BLE transport: NOT PROVEN

This corrects the previous Step 14 wording.

## 2. BLE GATT static table — exact binary evidence

At file offset `0x173A0` the firmware contains the characteristic UUID set:

```
E1 FF
E2 FF
E3 FF
E0 FF
3A 08 00 00
11 22 33 44
02 29
03 28
```

The UUIDs are therefore:

| UUID | role | confidence |
|---|---|---|
| `0xFFE0` | primary service UUID | CONFIRMED |
| `0xFFE1` | characteristic UUID | CONFIRMED |
| `0xFFE2` | characteristic UUID | CONFIRMED |
| `0xFFE3` | characteristic UUID | CONFIRMED |
| `0x2902` | CCC descriptor | CONFIRMED |
| `0x2803` | characteristic declaration descriptor | CONFIRMED |

The characteristic initial value is the exact four bytes:

`11 22 33 44`

The adjacent 32-bit value `0x0000083A` is present in the static attribute database and must not be mistaken for a UUID.

## 3. BLE application source is genuine, not generic-only

The binary contains `/main/BLE.c` and the following application log strings:

- `GATTS_TABLE_DEMO`
- `ESP_GATTS_READ_EVT`
- `GATT_WRITE_EVT`
- `notify enable`
- `indicate enable`
- `notify/indicate disable`
- `ESP_GATTS_EXEC_WRITE_EVT`
- `ESP_GATTS_MTU_EVT`
- `ESP_GATTS_CONNECT_EVT`
- `ESP_GATTS_DISCONNECT_EVT`
- `ota-control = %x`
- `=====beginota=====`
- `esp_ota_begin`
- `esp_ota_write`
- `esp_ota_end`
- `esp_ota_set_boot_partition`

This establishes that the custom application uses the normal ESP-IDF Bluedroid GATTS event path and has a real BLE OTA implementation.

## 4. BLE OTA behavior

The firmware explicitly calls the ESP-IDF OTA sequence:

```text
OTA control received
    -> esp_ota_begin
    -> repeated esp_ota_write
    -> esp_ota_end
    -> image validation
    -> esp_ota_set_boot_partition
    -> restart
```

The binary also contains `ota_0` and `ota_1`, confirming the two OTA application slots already identified in the flash map.

The OTA framing command bytes still require correlation with the exact GATT write handler; do not infer them solely from the log strings.

## 5. LVGL/display source evidence

The application source remnants prove:

- task name: `myTask_lcd`;
- display task/application function: `lcd_main`;
- ILI9341 driver is the ESP-IDF `esp_lcd` implementation;
- LVGL is initialized from the application;
- a display driver is registered with LVGL;
- an `esp_timer` periodic timer is installed for `lvgl_tick`;
- the application creates/displays an **LVGL Meter Widget**;
- source file is `/main/esp_lcd_ili9341.c`.

The exact LVGL tick period constant remains to be recovered from the compiled timer configuration rather than guessed from common LVGL examples.

## 6. Existing touch conclusion remains valid

CST816x remains confirmed at the hardware/protocol level:

- SDA GPIO1
- SCL GPIO8
- I2C address `0x15`
- 100 kHz
- register reads `0x02`, `0x03..0x06`, `0xA7`

No definitive interrupt GPIO has been found in the application binary, so the current evidence favors polling rather than an IRQ-driven touch path.

## 7. Current architecture correction

```text
GB/T CAN state machine
        |
        +--> runtime 0x3FCA...
        |       |
        |       +--> CAN payload generators
        |       +--> 64-byte Alldata
        |       +--> UI-visible values
        |       +--> BLE/application commands
        |
        +--> generic async application queue
                    |
                    +--> consumers (BLE/other app paths)

BLE GATTS
  +-- service 0xFFE0
  +-- chars 0xFFE1 / 0xFFE2 / 0xFFE3
  +-- CCC 0x2902
  +-- notify/indicate
  +-- OTA

LCD
  +-- ILI9341
  +-- LVGL
  +-- CST816x touch
```

## 8. Next large pass

1. Recover the exact BLE GATT handles and callback branches.
2. Identify which characteristic carries commands, telemetry, and OTA data.
3. Recover the OTA command/framing bytes.
4. Recover the exact LVGL tick period and object/event tree.
5. Trace CST816 coordinate data into LVGL input events.
6. Finish all remaining GPIO/PWM writers and then perform a full residual code/data sweep.
