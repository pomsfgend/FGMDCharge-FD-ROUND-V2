# Step 18 Index

**Focus:** State machine 0–7 full causal chain → CAN timestamps → 10 s delay → GPIO6/GPIO7 sequenced relay control.

## New / updated documents

- `step18_state_relay_power_sequence.md` — полный отчёт прохода
- `state_machine_step18.json` — машиночитаемая карта состояний + реле
- `gpio_map_step18.csv` — актуальная таблица GPIO с confidence

## Key confirmed results

1. Timebase = 10 ms.
2. State 4: GPIO6 = HIGH (via 0x4200C870).
3. State 5 + elapsed ≥ 10000 ms + substate==3: GPIO6 = LOW, GPIO7 = HIGH (one-shot).
4. Two independent relay control paths (protocol + BLE/app 0x66).
5. GPIO2 is strapping — never drive as output.
6. GPIO0 ADC runtime arithmetic recovered; physical unit still open.
7. GPIO3 LEDC 60 kHz confirmed; load still open.

## Next (Step 19)

Full xref of all relay wrappers + all writers of 0x3FCA0B1D + ADC/PWM residual + consolidated call graph.
