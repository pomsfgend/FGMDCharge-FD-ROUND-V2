# Cubik firmware reverse engineering — Step 10

## Scope
Large functional pass covering the display/UI path, CST816x touch path, BLE application layer, and the boundary between these modules and the already reconstructed GB/T runtime.

## 1. LCD / ILI9341 — reconstructed hardware interface

CONFIRMED from application configuration and Espressif driver strings:

- controller: ILI9341
- logical LVGL area: 240 x 280
- SPI host: SPI2 / host 1
- MOSI GPIO5
- SCLK GPIO19
- CS GPIO4
- DC GPIO18
- MISO unused (-1)
- reset GPIO = -1 (no firmware-controlled reset line)
- SPI mode 0
- pixel clock 20 MHz
- command bits 8
- parameter bits 8
- transaction queue depth 10
- max transfer size 38400 bytes
- RGB order
- 16 bpp

Driver path explicitly present in the image:
`esp_lcd_new_panel_io_spi` -> `esp_lcd_new_panel_ili9341` -> `esp_lcd_panel_reset` -> `esp_lcd_panel_init` -> `esp_lcd_panel_mirror(false,false)` -> `esp_lcd_panel_disp_on_off(true)`.

The image contains the application task name `lcd_main` and LVGL strings including:
- `Initialize LVGL library`
- `Register display driver to LVGL`
- `Install LVGL tick timer`
- `lvgl_tick`
- `Display LVGL Meter Widget`

Therefore the display is not a raw framebuffer-only implementation: LVGL is an active application layer.

The firmware also contains the ILI9341-specific panel operations `panel_ili9341_invert_color`, `panel_ili9341_mirror`, `panel_ili9341_swap_xy`, `panel_ili9341_disp_on_off`, `panel_ili9341_reset`, `panel_ili9341_init`, and `panel_ili9341_draw_bitmap`.

### Important physical implication

ILI9341 silicon normally supports 240x320-class displays, while this firmware exposes 240x280 to LVGL. The 280-pixel logical height must therefore be treated as an application/display-window choice until the actual glass is measured.

## 2. Touch controller — CST816x family

CONFIRMED application I2C configuration:

- I2C master
- SDA GPIO1
- SCL GPIO8
- pull-ups enabled
- 100 kHz
- 7-bit address 0x15

The recovered touch access sequence is characteristic of CST816S/CST816x:

1. device access at 0x15
2. read chip identification register 0xA7
3. read touch/finger count register 0x02
4. when touch exists, read 0x03..0x06
5. X = ((reg03 & 0x0F) << 8) | reg04
6. Y = ((reg05 & 0x0F) << 8) | reg06

No firmware-controlled touch reset GPIO was found in the recovered application path. No dedicated touch IRQ GPIO configuration was found either; the application path therefore behaves as polling/I2C-read driven rather than an IRQ-driven design.

This is strongly consistent with public CST816S documentation/drivers: register 0x02 is finger count, 0x03/04 are X, 0x05/06 are Y, and 0xA7 is chip ID.

### Identification confidence

- CST816x family: HIGH
- exact CST816S silicon revision: MEDIUM-HIGH
- IRQ absent from this firmware path: HIGH
- touch coordinate format: HIGH

## 3. LVGL/application boundary

The firmware has a dedicated `myTask_lcd` task and a dedicated LVGL tick timer. The LCD task is therefore a separate FreeRTOS execution context from the CAN task.

The application also contains a `Display LVGL Meter Widget` string. This is significant: at least one meter/gauge widget is intentionally used for the charging UI. The exact object tree/text labels should be recovered from the remaining application data/functions rather than guessed from the standard LVGL example.

The display subsystem is therefore best represented as:

`GB/T state/RX cache -> application variables -> myTask_lcd/LVGL -> ILI9341 SPI`

and touch as:

`CST816x I2C -> coordinate/event polling -> LVGL/application event path`.

## 4. BLE application layer

The image contains a custom application BLE module:

- source path `./main/BLE.c`
- init function name `BLE_init`
- profile callback `gatts_profile_event_handler`
- prepare-write handler `example_prepare_write_event_env`
- GATT attribute-table architecture (`GATTS_TABLE_DEMO`)
- notifications and indications
- CCC enable/disable handling
- MTU event handling
- connect/disconnect handling
- NVS persistence of a key named `BLEname`

The image contains the default/name-related data:

`q7FGMDCharge`

and the persistent NVS key:

`BLEname`

This means the BLE name is not simply a compile-time GAP name: the firmware has explicit persistence/read/write logic for the name.

The BLE implementation is based on ESP-IDF Bluedroid GATTS, not NimBLE. This is confirmed by the presence of `esp_ble_gatts_send_response`, `esp_ble_gatts_send_indicate`, Bluedroid GATT/BLE stack strings, and the application-side GATTS profile callback.

## 5. BLE attribute-table evidence

The binary contains an application-side attribute table region immediately following `GATTS_TABLE_DEMO` data and the profile/prepare-write function names. The table includes multiple service/characteristic/descriptor records and CCC-related state.

Exact UUID values are deliberately not marked CONFIRMED yet because the binary contains several IDF/Bluetooth UUIDs and the attribute table uses pointers into the image's DROM data. The next BLE pass should resolve those pointers and produce a complete service/characteristic/descriptor map rather than assigning UUIDs based on the ESP-IDF example.

## 6. NVS / persistent configuration relevant to UI/BLE

Application strings show NVS access for BLE name storage and the key `BLEname`. The dump also contains the ESP-IDF NVS/OTA infrastructure.

The firmware additionally contains application data strings such as:
- `Alldata`
- `cal_data`
- `cal_mac`
- `cal_version`

These should be treated as separate persistent/configuration domains until their writers/readers are traced.

## 7. Replacement-firmware hardware interface

At this point the complete high-confidence front-panel hardware interface is:

| Function | MCU resource |
|---|---|
| LCD MOSI | GPIO5 |
| LCD SCLK | GPIO19 |
| LCD CS | GPIO4 |
| LCD DC | GPIO18 |
| LCD reset | none in firmware |
| Touch SDA | GPIO1 |
| Touch SCL | GPIO8 |
| Touch address | 0x15 |
| CAN TX | GPIO10 |
| CAN RX | GPIO9 |
| Relay/control A | GPIO6 |
| Relay/control B | GPIO7 |
| Auxiliary output | GPIO2, startup HIGH |
| PWM | GPIO3, 60 kHz, 10-bit |
| ADC | GPIO0 / ADC1 channel 0 |

## 8. Architecture after Step 10

```text
                    +----------------------+
                    |     ESP32-C3          |
                    |      FreeRTOS         |
                    +----------+-----------+
                               |
             +-----------------+------------------+
             |                 |                  |
          CAN task          LCD task           Timer task
             |                 |                  |
      TWAI 250 kbit/s     LVGL/display       10-ms-ish
      GPIO10/9             |                  timing base
             |              +----+             |
       GB/T state           |    |             +---> GB/T timing
       machine              |    |
             |           ILI9341 CST816x
             |           SPI      I2C
             |           |        |
             +-----------+--------+-------------+
                         |
                  application state
                         |
                  GPIO6 / GPIO7 / GPIO2

      BLE task/module -> Bluedroid GATTS -> NVS BLEname
      ADC/PWM module  -> GPIO0 / GPIO3
```

## 9. Next large pass

The remaining high-value application blocks are now:

1. resolve the complete LVGL object tree and all displayed values;
2. recover touch event mapping into LVGL/application actions;
3. resolve BLE service/characteristic/descriptor UUIDs and exact write/notify payloads;
4. trace NVS `Alldata`/calibration structures;
5. fully map ADC conversion/calibration and PWM duty writers;
6. then sweep the entire remaining application code and unreferenced data.

No semantic field is assigned merely because it resembles an ESP-IDF example; unresolved items remain explicitly marked as such.
