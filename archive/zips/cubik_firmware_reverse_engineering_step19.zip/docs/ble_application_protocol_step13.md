# Cubik firmware reverse engineering — Step 13

## Scope
Large application sweep of the BLE/application command dispatcher and its generated status packet. This pass follows the actual RISC-V code around `0x4200A4D0..0x4200A9B0` and the packet builder at `0x420093FE`.

## 1. BLE/application packet layout

The dispatcher uses the GATTS write payload pointer as a byte array. A command byte is read from offset `+8` of the prepared application structure (`0x4200A518` onward). Parameters are then read from offsets `+9`, `+10`, and in one command `+11`.

This is distinct from the earlier 2-byte selector path at `0x4200A17C`:

```text
GATTS write payload
    |
    +-- length == 2 -> little-endian selector 0x0000/0x0001/0x0002
    |
    +-- application command packet -> command at payload/application offset +8
```

## 2. Recovered application command map

The following mappings are directly visible in the dispatcher. The names are intentionally descriptive rather than protocol-standard names.

| command | parameter source | effect | confidence |
|---:|---|---|---|
| `0x03` | bytes +9,+10,+11 | stores 24-bit value in `0x3FCA0AAC..A` and also as word at `0x3FCA0AA0`; zero clears `0x3FCA0B25` | CONFIRMED |
| `0x04` | internal/subcommand path | enters handler at `0x4200A872` | CONFIRMED |
| `0x05` | byte +10 | stores to `0x3FCA0AC9` | CONFIRMED |
| `0x06` | byte +10 | stores to `0x3FCA0AC8` | CONFIRMED |
| `0x07` | none | calls `0x4200930E`, restoring default application values | CONFIRMED |
| `0x08` | byte +1 when command byte differs | clears `0x3FCA0AC8` | CONFIRMED |
| `0x09` | byte +10 | stores to `0x3FCA0A80` | CONFIRMED |
| `0x0A` | bytes +9,+10, big-endian | stores to `gp-0x79C`; snapshots timer at `0x3FCA0A80` path | CONFIRMED |
| `0x0B` | byte +10 | stores to `0x3FCA0AA4` | CONFIRMED |
| `0x0C` | byte +10 | stores to `0x3FCA0A9C` | CONFIRMED |
| `0x0D` | none | forces application state byte `0x3FCA0B1C` to `6` | CONFIRMED |
| `0x0E` | bytes +9,+10, big-endian | stores pair at `0x3FCA0A88`; derived value `/10` to `0x3FCA0AA8` | CONFIRMED |
| `0x0F` | bytes +9,+10, big-endian | stores pair at `0x3FCA0A84`; derived value `/10` to `0x3FCA0AA6` | CONFIRMED |
| `0x11` | separate one-byte path | application/configuration operation | CONFIRMED |
| `0x13` | separate one-byte path | invokes application value conversion and stores result at `0x3FCA0AA4` | CONFIRMED |
| `0x53` | byte +10 | stores to `0x3FCA0A9D` | CONFIRMED |
| `0x5B` | bytes +9,+10, big-endian | stores to `0x3FCA0A9E` | CONFIRMED |
| `0x66` | byte +10 | `0` -> GPIO6 LOW + state 6; `1` -> GPIO6 HIGH + state 3 | CONFIRMED |

The exact semantic meaning of several values remains intentionally unresolved; their electrical/application effects are now known.

## 3. Default/reset command `0x07`

`0x4200930E` is a concrete application default initializer. It writes a coherent group of configuration values, including:

```text
0x3FCA0A88 = 0x000E / 0x0010 (pair)
0x3FCA0AA8 = 0x0168
0x3FCA0A80 = 0x0010 / 0x0068
0x3FCA0A84 = 0x0003 / 0x00E8
0x3FCA0AA6 = 0x0064
0x3FCA0A90.. = protocol/status bytes
0x3FCA0A9D = 0xE2 (signed byte -30)
0x3FCA0A9E = 0x0064
0x3FCA0A8C.. = zeroed 24-bit value
0x3FCA0AC9 = 1
```

It then copies a 20-byte factory structure from DROM around `0x3C0F66A0` into the runtime configuration area beginning at `0x3FC981B0`.

This is strong evidence that `0x4200930E` is a factory/default configuration initializer rather than an arbitrary protocol helper.

## 4. Relay command `0x66`

The previously reconstructed relay behavior can now be tied to the application command protocol directly:

```c
if (cmd == 0x66) {
    if (payload[10] == 0) {
        GPIO6 = LOW;
        state = 6;
    } else if (payload[10] == 1) {
        GPIO6 = HIGH;
        state = 3;
    }
}
```

This does **not** directly manipulate GPIO7.

Therefore the firmware has a deliberate external-control path capable of forcing the charging state machine between state 3 and state 6 while controlling relay A.

## 5. 64-byte status/telemetry packet builder

Function `0x420093FE` constructs a fixed **64-byte application status packet** at runtime buffer `0x3FC98170`.

It starts with:

```text
byte 0 = 0xFB   (code writes -5)
byte 1 = state byte `0x3FCA0B0C`
byte 2 = `0x3FCA0AC9`
byte 3 = `0x3FCA0AC8`
bytes 4..19 = 16-byte block at `0x3FC981B0`
bytes 22..23 = `0x3FCA0A88`
bytes 24..25 = signed pair at `0x3FCA0A84`
bytes 26..27 = `0x3FCA0A80`
bytes 30..31 = `0x3FCA0A9E`
byte 32 = `0x3FCA0A9C`
bytes 33..34 = `0x3FCA0A90`
bytes 35..36 = `0x3FCA0A94`
bytes 37..38 = `0x3FCA0A7C`
bytes 39..41 = 24-bit `0x3FCA0AAC`
bytes 42..45 = derived/calculated values
bytes 46..47 = scaled `0x3FCA0A80`-related value
bytes 48..49 = `0x3FCA0A??` application values
...
byte 63 = `0x7C`
```

The exact semantic field names are not assigned solely from byte positions. The important finding is that this is a structured status snapshot assembled from the same variables that the BLE command dispatcher modifies.

## 6. Packet construction / transmission boundary

`0x420093FE` only constructs the snapshot. Callers subsequently invoke the application transport/notification machinery. Therefore this 64-byte buffer is the primary candidate for the BLE status/telemetry payload and must be treated as an application protocol frame, not as CAN data.

A replacement firmware should preserve this separation:

```text
GB/T state variables
       |
       +--> CAN messages
       |
       +--> 64-byte application status snapshot
                    |
                    +--> BLE transport
```

## 7. Additional protocol fields recovered from dispatcher

The dispatcher also parses charger-side/runtime data into the same variable bank:

- bytes +9/+10 are frequently interpreted as big-endian 16-bit values;
- selected values are divided by 10 before storage;
- bytes +9/+10/+11 are treated as a 24-bit integer by command `0x03`;
- command `0x0A` stores a 16-bit value and snapshots a timer/reference value;
- command `0x0D` is a direct state/termination command;
- command `0x66` is a direct relay/state command.

This explains why several RAM variables previously looked like configuration values in the GB/T path: they are also writable through the application command channel.

## 8. OTA functionality exposed through BLE

The BLE event dispatcher contains an OTA-control branch and the firmware includes the complete ESP-IDF OTA logging/API strings:

```text
ota-control
======beginota======
Writing to partition subtype %d at offset 0x%x
esp_ota_begin
esp_ota_write
esp_ota_end
esp_ota_set_boot_partition
======endota======
Prepare to restart system!
```

The flash layout already recovered is:

```text
0x10000  ota_0  0x190000
0x1A0000  ota_1  0x190000
```

Thus BLE is not merely a configuration interface: the firmware contains a field-update path capable of selecting an OTA application partition and rebooting into it. The exact OTA command framing is left as a separate trace target rather than guessed from log strings.

## 9. Consequence for replacement firmware

The application layer is now best represented as four distinct protocols:

```text
1. GB/T 27930 CAN protocol
2. Internal application command protocol
3. BLE GATT transport of application commands/status
4. BLE OTA firmware-update protocol
```

The second protocol is now substantially reconstructed at byte/variable level. This is a major dependency for a faithful replacement firmware because it controls charging parameters and at least one relay/state transition independently of the GB/T state machine.
