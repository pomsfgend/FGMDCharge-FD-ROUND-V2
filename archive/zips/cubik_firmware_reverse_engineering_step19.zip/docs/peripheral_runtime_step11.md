# Cubik firmware reverse engineering — Step 11
## BLE + NVS + task integration + ADC/PWM runtime

### 1. BLE/NVS block — confirmed

The application contains a real Bluedroid GATTS application, not a generic string-only BLE stub.
The binary contains the application strings `GATTS_TABLE_DEMO`, `GATTS_NVS_DEMO`, `ESP_GATTS_*_EVT`, `notify enable`, `indicate enable`, `notify/indicate disable`, and the source path `main/BLE.c`.

The NVS path is directly visible in executable code:

- function `0x42009A9E` opens/uses an NVS table handle at `0x3FCA1AB8`-derived storage;
- it passes the literal key `BLEname` to the NVS get/set helpers;
- the returned length is explicitly initialized to `10` bytes in the read path;
- error handling distinguishes NVS-not-found / invalid-state style return values and logs the corresponding BLE-name failure/success messages;
- the saved BLE name is subsequently consumed by the BLE initialization path.

The literal default BLE name `q7FGMDCharge` is present in the image. Therefore the device has a persistent BLE-name configuration with a factory/default value.

### 2. GATTS event handler — confirmed

`0x42009E1C` is an application-level GATTS event dispatcher. Its first argument is treated as an event number and the second as the event parameter structure.
Observed branches include:

- event 0/1/2/3 paths;
- event 4/5 paths which clear application notification/connection flags;
- event 6 path with connection/attribute data handling;
- event 0x11 path which consumes characteristic/write data;
- event 0x14 path which logs connection/MTU-like parameters.

The handler explicitly reads fields at offsets `0x0, 0x4, 0x8, 0xA, 0xC, 0xE, 0x10, 0x12, 0x14, 0x18` from the event parameter structure. This matches the ESP-IDF `esp_ble_gatts_cb_param_t` union layout rather than a custom transport parser.

The write-data path compares the first two bytes of the received attribute payload as a little-endian 16-bit command selector. Values `0`, `1`, and `2` have separate application branches. This is an important control surface for the eventual replacement firmware.

### 3. BLE profile/attribute state — confirmed, UUID values not yet claimed

`0x42009294` initializes a compact profile/attribute state block at `0x3FC981D4`. The block starts with:

`02 01 06 03 03 E0 FF FF (conn_id+1) 09 ...`

The following bytes are copied from the active BLE name/application buffer. This is evidence of a GATT/profile metadata structure, but the exact UUID assignment should not be guessed until the attribute-table creation call and static UUID objects are traced together.

### 4. BLE initialization — confirmed at application level

The main BLE initialization path performs, in order, application/NVS preparation and then Bluetooth/GATTS setup. The binary contains the expected Bluedroid calls and error strings for:

- controller enable;
- Bluetooth stack enable;
- GATTS callback registration;
- application registration;
- attribute-table creation;
- successful table creation / handle-count validation.

The application therefore uses an ESP-IDF table-based GATTS design.

### 5. Task integration — confirmed

The firmware has four application task names embedded in the image:

- `myTask_BLE`
- `myTask_CAN`
- `myTask_lcd`
- `myTask_Timer`

The task-name strings are referenced from the application task-creation region around `0x42007D84..0x42007DF4`. The names are passed as task metadata to the FreeRTOS creation machinery.

This establishes four independently scheduled application domains rather than one monolithic loop.

### 6. ADC/PWM — confirmed

The binary contains `main/ADC.c` and the following ESP-IDF APIs:

- `adc_oneshot_new_unit`
- `adc_oneshot_config_channel`
- `adc_oneshot_read`
- `adc_cali_raw_to_voltage`
- `ledc_timer_config`
- `ledc_channel_config`
- `ledc_set_duty`
- `ledc_update_duty`

Previously confirmed hardware mapping remains:

- ADC channel 0 -> GPIO0;
- LEDC channel 0 -> GPIO3;
- LEDC timer 0;
- 10-bit duty;
- 60 kHz PWM.

The runtime ADC block around `0x4200D0C4..0x4200D2DE` performs a read/calculation pipeline and writes derived 16-bit values into application globals. It contains averaging/scaling arithmetic, including a division by `0x500` (1280) and a second normalized calculation. These values feed the application state rather than being dead test code.

### 7. PWM semantic status

The firmware explicitly sets/updates LEDC duty and also has a zero-duty path. The electrical load controlled by GPIO3 is still not assigned with sufficient confidence to a specific physical component. It is therefore kept as `PWM_OUTPUT_GPIO3` rather than incorrectly naming it as a backlight/LED/relay.

### 8. GPIO status after this pass

Confirmed application-controlled GPIOs remain:

| GPIO | Function | Confidence |
|---|---|---|
| 0 | ADC channel 0 | CONFIRMED |
| 1 | CST816x SDA | CONFIRMED |
| 2 | startup output, HIGH | CONFIRMED |
| 3 | LEDC PWM channel 0 | CONFIRMED |
| 4 | ILI9341 CS | CONFIRMED |
| 5 | ILI9341 MOSI | CONFIRMED |
| 6 | relay/control output | CONFIRMED |
| 7 | relay/control output | CONFIRMED |
| 8 | CST816x SCL | CONFIRMED |
| 9 | TWAI RX | CONFIRMED |
| 10 | TWAI TX | CONFIRMED |
| 18 | ILI9341 DC | CONFIRMED |
| 19 | ILI9341 SCLK | CONFIRMED |

### 9. What remains

The next large sweep should resolve the remaining application-specific peripheral semantics rather than re-reading generic ESP-IDF code:

1. exact GATT service/characteristic UUIDs and attribute indexes;
2. BLE write-command map and notification payloads;
3. exact ADC GPIO0 electrical meaning and conversion formula;
4. exact GPIO3 PWM consumer;
5. remaining GPIO initialization/configuration;
6. LCD LVGL object tree and touch event routing;
7. full application global map and cross-module data flow;
8. final unused-code/data sweep.
