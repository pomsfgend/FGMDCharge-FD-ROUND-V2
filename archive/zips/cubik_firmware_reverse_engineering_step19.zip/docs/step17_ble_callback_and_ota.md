# Step 17 — BLE GATTS callback / OTA / event map

## Scope
This pass traces the actual GATTS profile callback at `0x42009E1C` and the surrounding event-specific code in the RISC-V disassembly. It replaces earlier broad labels with the ESP-IDF `esp_gatts_cb_event_t` numbering where the event number is unambiguous.

## Confirmed callback
`0x42009E1C` is a central GATTS profile/event callback. Arguments are used as:
- `a0`: GATTS event number
- `a1`: interface/profile context
- `a2`: event parameter structure (`s0`)

Observed dispatch includes:
- event `1` — READ
- event `2` — WRITE
- event `3` — EXEC_WRITE
- event `4` — MTU
- event `12` — STOP
- event `14` — DISCONNECT
- event `15` — OPEN
- event `22` — SET_ATTR_VAL
- event `0x16` is therefore not an OTA command byte; it is an ESP-IDF GATTS event number.

This is important because previous passes occasionally mixed GATT event numbers with application command values.

## WRITE path
Event 2 reaches the characteristic-write dispatcher. The code checks the incoming attribute handle against a runtime handle table at approximately `0x3FC981C4`, then uses the write parameter fields:
- offset `+0x0`: handle/related attribute field
- `+0xE`: value length
- `+0x10`: offset
- `+0x12`: need-response flag
- `+0x14`: value length/packet length
- `+0x18`: value pointer

The callback contains separate handling for:
- ordinary short writes;
- prepared writes;
- OTA data/control writes;
- command bytes `0x11` and `0x13` after the characteristic/application layer has identified the relevant attribute.

## Prepared writes
The callback contains the standard ESP-IDF prepared-write flow:
- allocates a 0x400-byte accumulation buffer when needed;
- tracks total received length separately;
- rejects writes when `offset + len > 0x400`;
- stores fragments by offset;
- EXEC_WRITE later commits or cancels the prepared write.

This matches the strings in the firmware:
`ESP_GATTS_EXEC_WRITE_EVT`, `prepare write`, `ESP_GATT_PREP_WRITE_CANCEL`, `Send response error`.

## MTU
Event 4 is present and reads the MTU from the event parameter. This confirms MTU handling is part of the same application callback, not a separate transport protocol.

## Disconnect / restart state
Event 14 is the disconnect path. The callback reaches the common connection-state cleanup and disables notification/indication state. This is separate from the application command protocol.

## OTA evidence
Firmware strings and call sites confirm the OTA path is in `main/BLE.c` and includes:
- `esp_ota_begin`
- `esp_ota_write`
- `esp_ota_end`
- `esp_ota_set_boot_partition`
- image validation
- restart after successful boot-partition selection.

The firmware contains `ota_0` and `ota_1` partitions. OTA control is logged by the string `ota-control = %x` and OTA data writes by `write:0x%x` / `ota-data = %d`.

## Important separation
There are now three distinct layers:
1. GB/T CAN protocol and its transport (`RTS/CTS/DATA/EOM`);
2. BLE GATT transport and prepared-write handling;
3. Cubik application commands carried through the GATT write callback.

They must not be conflated. A GATT WRITE event number such as `2` is not the same thing as an application command byte `0x02`.

## Next target
The next pass should resolve the runtime GATT handle table at `0x3FC981C4`, identify which handle corresponds to FFE1/FFE2/FFE3/CCC, and trace the OTA-control/data branch to the exact framing and characteristic. After that, finish the LVGL event tree and perform the residual-function sweep.
