# Cubik firmware reverse engineering — Step 12

## Scope
Large application-level pass: complete the static GATTS attribute database, resolve custom UUIDs, correct the BLE write-command interpretation, and trace the ADC runtime arithmetic. PWM remains hardware-confirmed but its physical consumer is still unresolved.

## 1. GATTS UUID database — CONFIRMED

The application contains an 8-entry `esp_gatts_attr_db_t`-style static attribute table immediately before the literal `GATTS_TABLE_DEMO`.

The table is backed by DROM constants at flash offset `0x173b8`:

```text
e1 ff  e2 ff  e3 ff  e0 ff
3a 08 00 00
11 22 33 44
02 29
03 28
00 00 00 28 ...
```

The pointer values in the attribute records resolve into these constants. The custom 16-bit UUIDs are therefore:

| UUID | Role | Confidence |
|---|---|---|
| `0xFFE0` | primary service | CONFIRMED |
| `0xFFE1` | characteristic 1 value | CONFIRMED |
| `0xFFE2` | characteristic 2 value | CONFIRMED |
| `0xFFE3` | characteristic 3 value | CONFIRMED |
| `0x2803` | characteristic declaration | CONFIRMED |
| `0x2902` | CCC descriptor | CONFIRMED |

The three characteristic UUID pointers are directly visible:

- `0x3C0F73B8` -> `E1 FF` -> `0xFFE1`
- `0x3C0F73BA` -> `E2 FF` -> `0xFFE2`
- `0x3C0F73BC` -> `E3 FF` -> `0xFFE3`
- `0x3C0F73BE` -> `E0 FF` -> `0xFFE0`

### Attribute sequence

The static table contains the expected service/characteristic/CCC pattern:

```text
0  Primary Service       UUID 0xFFE0
1  Characteristic decl   UUID 0x2803
2  Characteristic value  UUID 0xFFE1
3  CCC descriptor        UUID 0x2902
4  Characteristic decl   UUID 0x2803
5  Characteristic value  UUID 0xFFE2
6  CCC descriptor        UUID 0x2902
7  Characteristic value  UUID 0xFFE3
```

The third characteristic has no separate declaration/CCC record in the static sequence; its exact generated handle linkage should be retained as an unresolved implementation detail until the table-creation handle array is traced.

## 2. Characteristic permissions / sizes — CONFIRMED

Decoded attribute descriptors show the three value attributes use permission `0x11` and a maximum length of `0x1F4` (500 bytes). Initial value length is 4 bytes.

The common initial value is backed by the DROM bytes:

```text
11 22 33 44
```

This is an application default/test value embedded in the firmware. It should NOT be interpreted as a runtime protocol packet without a writer trace.

The CCC descriptors use UUID `0x2902` and maximum length 2 bytes.

## 3. Characteristic property declaration — HIGH CONFIDENCE

The DROM declaration support bytes begin with:

```text
3A 08 00 00
```

`0x3A` is the GATT characteristic-property bitmask:

```text
0x02 READ
0x08 WRITE
0x10 NOTIFY
0x20 INDICATE
----------------
0x3A
```

Therefore the main characteristic property set is:

- READ
- WRITE
- NOTIFY
- INDICATE

The `0x0008` portion is associated with the generated declaration/handle representation and must not be treated as a fixed ATT handle in a replacement implementation; the Bluetooth stack allocates handles when the table is created.

## 4. BLE write command parser — CORRECTION / CONFIRMED

The previous pass over-generalized the command map. The actual GATTS write event path is at `0x42009E1C`, and the write-event branch parses the payload as a **little-endian 16-bit selector**.

Observed code:

```text
payload length == 2
selector = payload[0] | (payload[1] << 8)
```

The explicit application selectors in this path are:

| Selector | Effect | Confidence |
|---:|---|---|
| `0x0000` | clears application byte at `0x3FCA0ABC` | CONFIRMED |
| `0x0001` | sets application byte at `0x3FCA0ABC` to 1 | CONFIRMED |
| `0x0002` | sets application byte at `0x3FCA0ABC` to 1 | CONFIRMED |

The code does **not** directly toggle GPIO6/GPIO7 in this handler. The earlier interpretation that these BLE selectors themselves directly drove GPIO6 is therefore withdrawn.

The actual relay control remains in the GB/T/application state-machine functions already reconstructed in previous steps.

## 5. BLE variable controlled by selectors

The byte written by the three selectors is:

```text
0x3FCA0ABC
```

The handler uses it as an application flag. Its exact semantic name is not yet assigned because multiple downstream consumers exist.

Next writer/reader sweep should follow every reference to `0x3FCA0ABC` before assigning a semantic label.

## 6. BLE additional write path

The handler also contains a separate one-byte payload path. It reads `payload[0]` and explicitly recognizes:

```text
0x11
0x13
```

The `0x13` path performs application-level processing involving the data/configuration structures and CAN-side helpers. This is a separate command family from the two-byte selector above.

The payload length is explicitly checked as 1 byte before this path is accepted.

This gives the replacement-firmware protocol at least two application command formats:

```text
2-byte little-endian selector: 00 00 / 01 00 / 02 00
1-byte command:                 11 / 13 / ...
```

## 7. NVS `Alldata` — CONFIRMED raw storage model

The flash contains an NVS namespace/application block using the key:

```text
Alldata
```

There are multiple historical NVS entries/chunks for this key in the raw dump. This is consistent with repeated writes to a blob rather than a single immutable compile-time structure.

A recurring logical data region is 64 bytes long. Representative stored values include:

```text
30 30 30 30 30 30 30 30 30 30 30 30 30 00
02 94 00 32 10 68 00 00 00 64 00 00 00
25 1c fa 07 d0 fb 07 d0 34 00 00 9b
06 fe 34 00 00 9b 00 00 0d 08 00 00 00
00 b3 fe 7c 03 48 01 ff 67 21 f3 ec
```

Other historical versions contain changing configuration values such as:

```text
0x0294 / 0x0104 / 0x01F4 / 0x02BC / 0x07D0 / 0x08FC / 0x0BB8 / 0x0960 / 0x0320 ...
```

while the later portion remains largely stable.

This proves `Alldata` is a persistent **configuration/calibration/application-data blob**, not merely a BLE scratch buffer.

Exact field names are intentionally not assigned yet. The next pass must correlate every NVS read/write with the corresponding RAM globals and UI/CAN consumers.

## 8. Other persistent NVS keys

The application/storage region also contains:

- `BLEname`
- `Alldata`
- `cal_data`
- `cal_mac`
- `cal_version`

The default BLE name is `q7FGMDCharge`.

The raw NVS area contains multiple historical `Alldata` revisions, so the device evidently persists changes over its lifetime rather than only storing factory defaults.

## 9. ADC runtime — CONFIRMED

ADC processing function:

```text
0x4200D0C4
```

The function reads the calibrated ADC path and stores a filtered/scaled result into application globals.

The important arithmetic is:

```c
acc = acc + sample;
acc = acc - (acc >> 6);
```

followed by:

```c
x = acc >> 6;
x = acc & ~0x3F;
x = x - (acc >> 6);
x = x * 5;
x = x / 0x500;
```

with the resulting 16-bit value stored at:

```text
0x3FCA0C04
```

The function also calculates a second scaled value from the application variable at `0x3FCA0AA8` using:

```c
v = ((value - 0x14) * 5 * 256) / 0xFD;
```

and stores it at:

```text
0x3FCA0C08
```

The exact electrical unit represented by GPIO0 remains unresolved. The code proves the signal is application-used and calibrated/scaled, but not whether it is battery voltage, current, temperature, or another analog measurement.

## 10. ADC hardware path

Confirmed:

```text
GPIO0 -> ADC1 channel 0 -> ESP-IDF oneshot ADC -> calibration -> application filter/scaling
```

The firmware uses:

- `adc_oneshot_new_unit`
- `adc_oneshot_config_channel`
- `adc_oneshot_read`
- `adc_cali_raw_to_voltage`

Therefore the value is not a raw uncalibrated 12-bit number at the application boundary.

## 11. PWM GPIO3

Still CONFIRMED:

```text
GPIO3
LEDC channel 0
LEDC timer 0
10-bit duty
60 kHz
```

The firmware contains explicit duty-update and zero-duty paths.

The physical load driven by GPIO3 is deliberately left unresolved. The binary does not yet provide enough direct evidence to label it as LCD backlight, status LED, fan, etc. This distinction matters for replacement hardware and will be resolved by tracing all duty writers and the GPIO initialization sequence.

## 12. Updated BLE hardware/software model

```text
ESP32-C3
  |
  +-- Bluedroid GATTS
       |
       +-- Service 0xFFE0
       |    |
       |    +-- Char 0xFFE1
       |    +-- CCC  0x2902
       |    +-- Char 0xFFE2
       |    +-- CCC  0x2902
       |    +-- Char 0xFFE3
       |
       +-- READ / WRITE / NOTIFY / INDICATE
       |
       +-- NVS: BLEname / Alldata / calibration keys
```

## 13. Confidence corrections

The following are now explicitly corrected:

1. `0xFFE0..0xFFE3` are not guessed from a generic UART example; their byte sequences and attribute-table pointers are present in this exact firmware.
2. BLE selectors `0x0000/0001/0002` do not directly call the relay GPIO wrappers in the observed write handler.
3. GPIO6/GPIO7 remain controlled by the already reconstructed application/GB-T state machine.
4. `Alldata` is persistent NVS blob/configuration storage with repeated historical entries.

## 14. Next large pass

The next sweep should now cover the remaining application code rather than individual peripherals:

- all readers/writers of `0x3FCA0ABC`, `0x3FCA0C04`, `0x3FCA0C08`;
- complete BLE notification/indication payload generation;
- exact GATT handle mapping after table creation;
- `Alldata` field reconstruction through NVS read/write callers;
- all GPIO3 duty writers and GPIO2 initialization;
- LVGL object/event tree and displayed charging parameters;
- final application-code/data sweep and dead/unreferenced region classification.
