# Cubik firmware reverse engineering — Step 16

## Scope
Large pass over the actual GATTS WRITE callback and the LVGL timer initialization. This pass uses direct RISC-V control flow rather than inferring behavior from log strings.

## 1. GATTS WRITE callback — confirmed application command dispatcher

The function beginning at `0x42009E1C` is the custom GATTS event callback. Its event dispatch includes the ESP-IDF GATTS event values; the WRITE path reaches `0x4200A0D0` and consumes the write parameter block.

The WRITE path checks the received length and then interprets the first byte of the received value as an application command. The code at `0x4200A17C` reads a 16-bit command selector from the first two bytes when length is 2, while the larger command dispatcher at `0x4200A51E` uses the first received byte for the single-byte command protocol.

### Confirmed single-byte command selectors

| Command | Evidence / effect |
|---|---|
| `0x66` | Direct relay/state control. `value[1]` is tested: `0` → call `0x4200C882` (GPIO6 LOW), set application state byte `0x3FCA0B0C` to `6`; `1` → call `0x4200C870` (GPIO6 HIGH), set state to `3`. |
| `0x0D` | Sets application state byte `0x3FCA0B0C` to `6`. |
| `0x0E` | Stores `value[9]` into `0x3FCA0A88`-adjacent runtime field (`0x3FCA0A84`/`0x3FCA0A86` representation), then scales the two-byte value by `/10`. Exact UI/config semantic remains pending. |
| `0x09` | Stores two bytes `value[9]`, `value[10]` into a pair of 16-bit runtime fields at `0x3FCA0A80`-adjacent area. |
| `0x07` | Calls factory/default configuration routine `0x4200930E`. |
| `0x06` | Stores `value[10]` into runtime byte `0x3FCA0AC8`-adjacent field. |
| `0x02` | Stores `value[10]` into runtime byte at `0x3FCA0A90`-adjacent field. |
| `0x05` | Stores `value[10]` into runtime byte at `0x3FCA0AC9`-adjacent field. |
| `0x53` | Stores `value[10]` into runtime byte at `0x3FCA0A9D`-adjacent field. |
| `0x5B` | Stores big-endian 16-bit `value[9:10]` into runtime word at `0x3FCA0A9E`-adjacent field. |
| `0x03` | Copies a 10-byte region from the received packet into the persistent/configuration area at `gp-0x45c`; then rebuilds/persists the 64-byte `Alldata` path. |
| `0x08` | Variant of the `0x03` path with the loop index initialized to zero. |

The dispatcher also contains selectors `0x04`, `0x08`, `0x0A`, `0x0B`, `0x0C`, `0x0F`, `0x13`, and `0x11`; their full semantic classification is retained as an active target rather than guessed.

## 2. `0x66` correction / strongest evidence

This is now directly proven from the callback:

```text
received value[0] == 0x66
    value[1] == 0:
        0x4200C882()  -> GPIO6 LOW
        state = 6
    value[1] == 1:
        0x4200C870()  -> GPIO6 HIGH
        state = 3
```

Therefore `0x66` is a real application command with direct relay/state-machine control. This is stronger evidence than the previous inference based only on the presence of the GPIO wrappers.

## 3. GATTS event callback classification

`0x42009E1C` contains branches for event values corresponding to the normal ESP-IDF Bluedroid GATTS callback family, including WRITE, MTU, CONNECT/DISCONNECT and related events. The WRITE handler ultimately operates on the received value pointer and length fields.

The callback also has a handle/connection-related path at `0x42009DAE`, where a handle/value pair is dispatched through the application's generic table/handler mechanism. This is the remaining route to map the exact characteristic handles to command vs telemetry vs OTA.

## 4. LVGL tick — exact period recovered

The LCD initialization function contains the LVGL tick timer setup around `0x42008E5A`:

1. timer callback pointer is populated;
2. the timer argument structure contains the string `lvgl_tick` for logging/context;
3. timer creation is performed;
4. immediately afterward the code loads:

```text
li a1, 0x7d0
```

and passes it as the periodic interval to the timer-start call.

`0x7D0 = 2000` microseconds.

### CONFIRMED

**LVGL tick period = 2 ms (500 Hz).**

This should be used by a replacement implementation instead of the common-but-unproven 1 ms LVGL example value.

The same initialization then starts the LCD/application task path and calls a 200 ms timed operation (`0xC8`) in the surrounding setup; that 200 ms value is separate from the LVGL tick and must not be conflated with it.

## 5. Current LCD timing architecture

```text
LCD init
  |
  +-- LVGL tick timer
  |     period = 2000 us
  |     frequency = 500 Hz
  |
  +-- myTask_lcd / LVGL handler
  |
  +-- ILI9341 SPI
        20 MHz
        GPIO5 MOSI
        GPIO19 SCLK
        GPIO4 CS
        GPIO18 DC

CST816x
  |
  +-- I2C GPIO1/GPIO8 @ 100 kHz
  +-- address 0x15
```

## 6. Remaining BLE target

The next BLE pass should resolve the actual attribute handles by tracing the `0x42009DAE` table/handle dispatcher and the WRITE callback's handle comparisons. The current command bytes are now proven independently of the UUID interpretation.

OTA command framing is still deliberately not guessed: the callback contains distinct paths for OTA/control and the actual `esp_ota_*` backend, but the exact framing needs one more cross-reference pass.

## Confidence

- GATTS WRITE callback at `0x42009E1C`: **HIGH / direct control-flow evidence**
- `0x66` relay/state command: **CONFIRMED**
- `0x0D` state-6 command: **CONFIRMED**
- LVGL tick = 2 ms: **CONFIRMED**
- exact characteristic handle mapping: **NOT YET CLOSED**
- OTA framing bytes: **NOT YET CLOSED**
