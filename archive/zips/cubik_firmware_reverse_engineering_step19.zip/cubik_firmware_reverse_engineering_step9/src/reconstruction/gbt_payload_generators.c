/* Pseudocode reconstruction from ESP32-C3 RISC-V firmware.
 * Not a drop-in firmware module yet; formulas are intentionally kept close to
 * the observed machine code until all RAM writers are identified.
 */
#include <stdint.h>

static uint16_t rd_u16(uint32_t addr); /* reverse-engineering placeholder */
static int16_t  rd_s16(uint32_t addr);
static uint8_t  rd_u8(uint32_t addr);
static uint32_t rd_u32(uint32_t addr);

static uint8_t clamp_u8(uint32_t x, uint32_t max) {
    return (x > max) ? (uint8_t)max : (uint8_t)x;
}

/* PGN 0x600, sequence 1: application bytes (without TP sequence byte). */
void gen_bcp_seq1(uint8_t *d) {
    d[0] = 0x6D;
    d[1] = 0x01;
    d[2] = 0xDC;
    d[3] = 0x05;
    d[4] = 0xFE;
    d[5] = 0x01;
    d[6] = rd_u16(0x3FCA0A80) & 0xFF;
}

/* PGN 0x600, sequence 2. */
void gen_bcp_seq2(uint8_t *d) {
    uint16_t vmax = rd_u16(0x3FCA0A80);
    int32_t x = (int32_t)rd_u16(0x3FCA0AA8) - 20;
    uint16_t v = (uint16_t)(x * 10);
    d[0] = (uint8_t)vmax;
    d[1] = 0x69;
    d[2] = 0x64;
    d[3] = 0x00;
    d[4] = (uint8_t)v;
    d[5] = (uint8_t)((((int32_t)(int16_t)x) * 5) >> 7);
    d[6] = 0xFF;
}

/* PGN 0x1100, sequence 1. */
void gen_bcs_seq1(uint8_t *d) {
    uint16_t v = (uint16_t)(rd_u16(0x3FCA0C24) * 10u);
    int16_t i = rd_s16(0x3FC9820C);
    uint16_t enc_i = (uint16_t)((int32_t)i * 10 - 0x60);
    d[0] = (uint8_t)v;
    d[1] = (uint8_t)(v >> 8);
    d[2] = (uint8_t)enc_i;
    d[3] = (uint8_t)(enc_i >> 8);
    d[4] = 0x3E;
    d[5] = 0x21;
    d[6] = clamp_u8((uint32_t)rd_u8(0x3FCA0AD8) + 10u, 0x5F);
}

/* PGN 0x200 BRM: sequence 1, direct machine-code formula. */
void gen_brm_seq1(uint8_t *d) {
    uint16_t a = (uint16_t)(rd_u16(0x3FCA0C24) * 10u);
    int16_t i = rd_s16(0x3FC9820C);
    uint16_t b = (uint16_t)((int32_t)i * 10 - 0x60);
    d[0] = (uint8_t)a;
    d[1] = (uint8_t)(a >> 8);
    d[2] = (uint8_t)b;
    d[3] = (uint8_t)(b >> 8);
    d[4] = 0x3E;
    d[5] = 0x21;
    d[6] = clamp_u8((uint32_t)rd_u8(0x3FCA0AD8) + 10u, 0x5F);
}
