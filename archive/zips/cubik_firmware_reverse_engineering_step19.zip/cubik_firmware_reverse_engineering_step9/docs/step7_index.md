# Step 7 index

- `gbt_payload_step7_exact_generators.md` — detailed exact formulas and evidence.
- `step7_verification.md` — verification status and remaining unknowns.
- `step7_evidence_offsets.txt` — important disassembly offsets.
- `../src/reconstruction/gbt_payload_generators.c` — C-like reconstruction of the currently proven generators.
