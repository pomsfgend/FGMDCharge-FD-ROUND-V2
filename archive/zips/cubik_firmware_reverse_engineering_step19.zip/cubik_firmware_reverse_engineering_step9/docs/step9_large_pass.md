# Cubik firmware reverse engineering — Step 9 large pass

## Scope
This pass deliberately closes a larger block: GB/T runtime data flow, the application-side control protocol feeding that runtime, flash layout, task bootstrap, and the boundary into display/GUI initialization.

Confidence labels: CONFIRMED = directly observed in machine code; HIGH = strong cross-correlation; INFERRED = plausible but not yet proven.

## 1. GB/T runtime data model — consolidated

### 1.1 CCS receive path
RX dispatcher function around `0x4200A500` handles type `0x0E` at `0x4200A62A`.

- CAN payload byte 9 -> `0x3FCA0A88` low byte.
- CAN payload byte 10 -> `0x3FCA0A8A` low byte.
- Combined 16-bit value is interpreted big-endian.
- Division by 10 -> `0x3FCA0AA8`.

Thus the firmware's internal voltage representation is explicitly derived from a 0.1-unit CAN field.

### 1.2 Second measurement/configuration inputs
The same dispatcher has distinct branches:

- type `0x0F` (`0x4200A6EA`): payload bytes 9/10 -> `0x3FCA0A84`/`0x3FCA0A86`, combined `/10` -> `0x3FCA0AA6`.
- type `0x09` (`0x4200A722`): payload bytes 9/10 -> `0x3FCA0A80`/`0x3FCA0A82`.
- type `0x03` (`0x4200A5C2`): three-byte measurement block -> `0x3FCA0AAC..0x3FCA0AAE`, combined 24-bit value -> `0x3FCA0AA0` area.
- type `0x66` (`0x4200A774`): local relay/control command. byte 10 = 0 -> GPIO6 LOW and state 6; byte 10 = 1 -> GPIO6 HIGH and state 3.
- type `0x02`, `0x05`, `0x53`, `0x5B`: status/control bytes are stored in the `0x3FCA...` state area.
- type `0x04`, subcommand 4: a 9-byte block is copied into the runtime identity/configuration buffer.

This proves the Cubik application is not only a transparent GB/T bridge: it has a separate local/application command protocol which changes the values and relay state consumed by the GB/T engine.

## 2. BRM/BCS exact generator — corrected and consolidated

Generator entry around `0x4200B3B2` uses sequence number in byte 0.

For sequence 1 (`0x4200B3C4`):

- byte 1 = `0x00 + 5*X` encoded as `10*X` in the observed implementation, where `X = lhu(0x3FCA13? / source slot)`;
- byte 2 = corresponding high portion;
- byte 3 = `10*I - 0x60`, where **`I = signed halfword 0x3FC9820C`**;
- byte 4 = signed/high part of `(10*I - 0x60)`;
- byte 5 = `0x3E`;
- byte 6 = `0x21`;
- byte 7 = `(0x3FCA0AD8 + 10)`, saturated at `0x5F`.

The exact RISC-V operations are preserved in `src/reconstruction/gbt_payload_generators.c` and the original disassembly evidence.

For sequence 2 (`0x4200B44E`):

- source accumulator = `0x3FCA0AE8`;
- divisor = `0xEA60` = 60000 decimal;
- result = `600 - floor(accumulator/60000)`;
- result is emitted little-endian into bytes 1..2.

The BRM identity area is populated at `0x3FC981B0`; the RX/configuration code copies runtime data into that block. Therefore BRM is not simply a fixed compiled identity string.

## 3. BCP exact generator

For PGN `0x600`, the generator at `0x4200B316`/`0x4200B360` emits:

Sequence 1:
`[seq, 0x6D, 0x01, 0xDC, 0x05, 0xFE, 0x01, low(0x3FCA0A80)]`

Sequence 2:
- bytes 1..2 = `0x3FCA0A80` little-endian;
- byte 3 = `0x69`;
- byte 4 = `0x64`;
- bytes 5..6 = the signed/derived transformation of `0x3FCA0AA8 - 20`;
- byte 7 = `0xFF`.

The machine code implements the multiplication by 10 and signed `35/256` style transformation using shifts/adds, not floating point.

## 4. Application timer/data producer

Function `0x4200AAD0` consumes `0x3FCA0AE8` with divisor `0xEA60` and updates:

- `0x3FCA0A92` (16-bit quotient);
- `0x3FCA0A94..95` (high/low bytes of the quotient);
- a 16-bit value copied from `0x3FCA0AA?` measurement/configuration area.

It also evaluates state flags at `0x3FCA0A9C`, `0x3FCA0AA4`, `0x3FCA0AC8`, and invokes relay wrappers. This is the local timing/charge-data producer feeding the GB/T state machine.

## 5. Initial configuration block

`0x4200930E` initializes the application protocol state:

- `0x3FCA0A78` = `0x000E`;
- `0x3FCA0A7A` = `0x0010`;
- `0x3FCA0AA8` = `0x0168` (360);
- `0x3FCA0A80` = `0x0010`, `0x3FCA0A82` = `0x0068`;
- `0x3FCA0A84` = `3`, `0x3FCA0A86` = `0x00E8`;
- `0x3FCA0AA6` = `0x64`;
- `0x3FCA0A88`-related status bytes and the 3-byte measurement block are zeroed;
- `0x3FCA0AC9`-type state flag is initialized to 1;
- the 16-byte runtime identity/configuration buffer at `0x3FC981B0` is initialized from a static data block at `0x3C0F66A0`.

These defaults are important for reconstructing the device's power-on behavior before any external CAN/local command arrives.

## 6. Relay control — newly consolidated

The local application protocol directly controls the charging relay state:

- `0x4200A782`: GPIO6 LOW, application state = 6.
- `0x4200A792`: GPIO6 HIGH, application state = 3.

The GB/T state machine separately contains the already-established transitions involving GPIO6/GPIO7. Therefore there are **two control paths** into relay state: protocol state machine and local/application command dispatcher.

Do not infer global relay polarity from only one transition.

## 7. Flash image layout — CONFIRMED

The binary contains a standard ESP32-C3 image and partition table.

Partition table at `0x8000`:

| offset | type/subtype | label | size |
|---:|---|---|---:|
| `0x9000` | data/NVS (`01/02`) | `nvs` | `0x4000` |
| `0xD000` | data/OTA (`01/00`) | `otadata` | `0x2000` |
| `0xF000` | data/PHY (`01/01`) | `phy_init` | `0x1000` |
| `0x10000` | app/ota_0 (`00/10`) | `ota_0` | `0x190000` |
| `0x1A0000` | app/ota_1 (`00/11`) | `ota_1` | `0x190000` |

The supplied dump is therefore a **full flash image**, not merely an extracted application blob. The two OTA slots are each 1,638,400 bytes.

## 8. Bootstrap/task architecture — CONFIRMED

At `0x42007D2E` the CAN task executes:

`CAN_Mode_Init()` -> `0x4200B11C` data/timer update -> `0x4200C078` state machine -> `0x4200C7E4` RX processing -> `vTaskDelay(1)`.

The bootstrap around `0x42007D62` initializes peripherals and creates the application tasks. Known task functions from embedded source strings are:

- `myTask_BLE`
- `myTask_CAN`
- `myTask_lcd`
- `myTask_Timer`

The source paths embedded in the image include `main/BLE.c`, `main/CAN.c`, `main/esp_lcd_ili9341.c`, `main/time.c`, `main/ADC.c`.

## 9. LCD initialization boundary

`0x420096A4` is a high-confidence LCD/application initialization entry because it immediately invokes the application configuration initializer and uses the same runtime buffer that precedes the panel-driver setup. Embedded strings independently confirm:

- `lcd_main`
- `esp_lcd_new_panel_ili9341`
- `esp_lcd_new_panel_io_spi`
- `spi_bus_initialize(LCD_HOST, &buscfg, SPI_DMA_CH_AUTO)`
- `esp_lcd_panel_reset`
- `esp_lcd_panel_init`
- `esp_lcd_panel_mirror(... false, false)`
- `esp_lcd_panel_disp_on_off(... true)`
- `panel_ili9341_invert_color`
- `panel_ili9341_swap_xy`
- `panel_ili9341_draw_bitmap`

Previously recovered exact electrical configuration remains:

- ILI9341, logical 240x280;
- MOSI GPIO5;
- SCLK GPIO19;
- CS GPIO4;
- DC GPIO18;
- SPI mode 0;
- 20 MHz;
- no MISO usage;
- reset GPIO = -1 in driver configuration.

This establishes the next reverse-engineering boundary: reconstruct the complete `lcd_main`/LVGL object tree and touch event pipeline rather than revisiting the controller identification.

## 10. BLE/NVS boundary

The image contains application strings proving a Bluedroid GATT server implementation, not NimBLE:

- `GATTS_TABLE_DEMO`;
- `GATTS_NVS_DEMO`;
- `BLE_INIT`;
- NVS key `BLEname`;
- `gatts_profile_event_handler`;
- `esp_ble_gatts_send_indicate`;
- notify/indicate enable/disable handlers;
- MTU, connect, disconnect and prepare-write handling;
- source `./main/BLE.c`.

The next BLE pass should recover the attribute table's exact UUIDs, permissions, properties, handle order and NVS name-loading path.

## 11. Result of this large pass

GB/T is now structurally closed enough that the remaining uncertainty is primarily **semantic data provenance**, not protocol sequencing:

`local command/CAN RX -> runtime variables -> BRM/BCP/BCL/BCS/BSM -> GB/T state machine -> TWAI transport`.

The remaining GB/T work is therefore to resolve the final variable semantics and exact BCL source chain, after which the protocol portion can be treated as reconstructed.

Next large block: `lcd_main + LVGL + CST816S`, including GPIO/I2C configuration, touch register decoding, event-to-widget mapping, display update functions, task period and all UI values read from the GB/T runtime model.
