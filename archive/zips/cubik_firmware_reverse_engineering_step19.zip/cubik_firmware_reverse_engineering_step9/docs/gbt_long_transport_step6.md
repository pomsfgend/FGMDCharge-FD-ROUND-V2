# Cubik firmware reverse engineering — Step 6
## BRM/BCP transport and exact TX builder reconstruction

### 1. Scope
This step continues directly from the verified GB/T state machine and reconstructs the executable transport-layer logic around `0x4200B162`, `0x4200B472`, `0x4200B516`, `0x4200B5F8` and the generic CAN TX builder `0x4200B9F8`.

Confidence labels:
- CONFIRMED = directly visible in machine code.
- HIGH = direct code plus protocol correlation.
- INFERRED = interpretation not yet tied to a complete call trace.

## 2. Generic CAN TX constructor — CONFIRMED
Function `0x4200B9F8` receives:
- `a0` = pointer to payload bytes
- `a1` = DLC
- `a2` = 29-bit CAN identifier

It builds an ESP-IDF `twai_message_t` on the stack:
- flags = `0x05` (extended + single-shot)
- identifier = `a2`
- DLC = `a1`
- payload copied byte-for-byte
- calls `twai_transmit(..., portMAX_DELAY)`.

## 3. Application message dispatcher — CONFIRMED
`0x4200BA6E` dispatches by exact 29-bit identifier.

Recognized IDs in this dispatcher:
- `0x181056F4` BCL
- `0x181156F4` BCS
- `0x181356F4` BSM
- `0x181C56F4` BSD
- `0x101956F4` BST
- `0x180256F4` BRM
- `0x180656F4` BCP
- `0x081E56F4` BEM
- `0x100956F4` BRO
- `0x182756F4` BHM

The dispatcher also invokes transport handling for long-message PGNs.

## 4. BCP long-message registration — CONFIRMED
At `0x4200BB28`:
- exact PGN/identifier selected: `0x180656F4` (BCP)
- compares elapsed time against cached timestamp + `0xFA` (250 ms)
- invokes `0x4200B516` with:
  - `a0 = 0x600` (PGN 1536 / BCP)
  - `a1 = 0x0D` (13 bytes in this transport-registration path)
  - `a2 = 0xF4`
  - `a3 = 0x56`
- updates BCP timestamp.

The `0x600` value is the PGN used by the transport layer; it is not a RAM pointer.

## 5. BRM long-message registration — CONFIRMED
At `0x4200BFC8`:
- elapsed time checked against cached timestamp + `0xFA`
- invokes `0x4200B516` with:
  - `a0 = 0x200` (PGN 512 / BRM)
  - `a1 = 0x31` (49 bytes)
  - `a2 = 0xF4`
  - `a3 = 0x56`
- updates BRM timestamp.

Thus the firmware's BRM application payload length is **49 bytes** in this implementation.

## 6. BEM long-message registration — CONFIRMED
At `0x4200BFFA`:
- elapsed time checked against cached timestamp + `0xFA`
- invokes `0x4200B516` with:
  - `a0 = 0x1100` (PGN 4352)
  - `a1 = 0x09` (9 bytes)
  - `a2 = 0xF4`
  - `a3 = 0x56`
- updates timestamp.

This is the firmware's long-message path for PGN `0x1100`; exact application-name mapping should remain separate until the corresponding application-layer call site is fully correlated.

## 7. Transport registration — CONFIRMED
`0x4200B516`:
- accepts maximum application payload up to `0x6F0` (1776 bytes)
- stores PGN bytes at transport context `0x3FC981FA..FB`
- if an old transfer is in state 6, clears it
- initializes:
  - total length
  - frame count = `(length + 6) / 7`
  - current frame index = 1
  - received/ack flag = 0
  - source/destination bytes
- enters transport state 1.

The `+6` then `/7` calculation is exact evidence that the firmware uses **7 application bytes per CAN data frame** in this multi-frame transport path.

## 8. Transport sender — CONFIRMED
`0x4200B472` constructs the transport control/data frame using:
- PGN
- destination/source address
- current transport state
- sequence/frame counters.

The transport identifier construction explicitly uses:
- `0x1CEB...` family for data/CTS-related transport traffic
- `0x1CEC...` family for RTS/EOM/control traffic.

The firmware builds the 29-bit identifier by combining the supplied source/destination bytes with the `0x1CEB` / `0x1CEC` PGN family.

## 9. RTS frame construction — CONFIRMED
Within `0x4200B472`, the RTS/control branch constructs:
- control byte `0x10`
- total message length low/high bytes
- total frame count
- reserved byte `0xFF`
- target/source PGN bytes.

The frame-count formula is `(length + 6) / 7`.

For BCP length 13:
- total length = `0x000D`
- frame count = `(13 + 6) / 7 = 2`.

For BRM length 49:
- total length = `0x0031`
- frame count = `(49 + 6) / 7 = 7`.

This is directly visible in code, not inferred from a protocol table.

## 10. CTS / EOM ACK receive processing — CONFIRMED
`0x4200B5F8` maintains a transport context at `0x3FC981E8`.

Important fields:
- `+0x00` = total length
- `+0x02` = expected/current frame count
- `+0x04` = current frame index
- `+0x06` = remaining/received count flag
- `+0x08` = transport elapsed timer
- `+0x0C` = current PGN
- `+0x11` = transport state
- `+0x12/+0x13` = destination/source address
- `+0x14` = retry/error counter.

Observed states:
- 1 = initial / waiting for transport control
- 2 = data transmission phase
- 3 = receiving/processing CTS or related frame
- 4 = waiting for next transport condition
- 5 = timeout/retry state
- 6 = completed/closed transfer state.

Timeout constants visible in executable:
- `0x32` = 50 ms
- `0xC8` = 200 ms
- `0x1F4` = 500 ms
- `0x4E2` = 1250 ms.

## 11. CTS payload interpretation — CONFIRMED
When the expected `0x1CEC56F4` control identifier is received, the code validates:
- control byte `0x11`
- PGN match
- transfer/session identity
- requested frame count/position against total count.

When the expected `0x1CEB56F4` data/control family is received, the parser validates sequence information and updates the transport context.

## 12. End-of-message validation — CONFIRMED
The EOM path checks:
- control byte `0x13`
- control/target byte `0xFF`
- PGN match
- received byte count <= declared total length.

Successful completion resets transport counters and closes the transfer state.

## 13. Important correction
Earlier notes treated the `0x600`, `0x200`, and `0x1100` values as possible buffer addresses. They are **PGN values** passed to the transport layer. The transport context stores them in `+0x0C` and uses them when constructing RTS/CTS/EOM identifiers and validating incoming control frames.

## 14. Exact fixed payloads recovered in the previous step
These remain confirmed from `0x4200BA6E`:

### BCS — `0x181156F4`
`01 46 00 3C 00 00 10`

### BSM — `0x181356F4`
`01 46 00 3C 00 00 10`

### BST — `0x101956F4`
`40 00 40 00`

### BSD — `0x181C56F4`
`5F 40 01 68 01 4A 4B`

### BRO — `0x100956F4`
Status byte is generated as `0xAA` in the ready state.

## 15. New exact BRM/BCP lengths
The binary gives a much stronger reconstruction than protocol-only reasoning:

| Message | CAN ID | PGN | Application length used by firmware | Status |
|---|---:|---:|---:|---|
| BRM | `0x180256F4` | `0x200` | **49 bytes** | CONFIRMED |
| BCP | `0x180656F4` | `0x600` | **13 bytes** | CONFIRMED |
| PGN `0x1100` long message | transport ID depends on direction | `0x1100` | **9 bytes** | CONFIRMED |

## 16. Next exact target
The remaining missing part is no longer transport framing. It is the **49-byte BRM source fields and 13-byte BCP source fields**. The relevant application generator is `0x4200B162` and its call chain from the state machine. The next pass must correlate every byte to the globals at `0x3FCA...` / `0x3FC98...`, then reconstruct the actual byte arrays rather than merely their lengths.

After that, the GB/T section can be marked complete and analysis moves to LVGL/ILI9341/CST816/BLE/ADC/PWM and the remaining binary regions.
