# Cubik firmware — Step 8: runtime variable producers and corrections

## 1. Important correction

The earlier Step 7 pseudocode labelled `0x3FC98200` as the charging-current source. Direct disassembly proves the BCS/BRM generator reads **signed halfword at `0x3FC9820C`**:

`0x4200B3E8: 3fc98737 / 20070713` -> base `0x3FC98200`; `lh a5, 0x0c(a4)` -> `0x3FC9820C`.

Therefore:

- `0x3FC9820C` = signed current/charging-current source used by BRM/BCS generator.
- `0x3FC98200` itself is not the source for this field.

This supersedes the corresponding Step 7 wording.

## 2. CCS-derived voltage path

RX handling around `0x4200A62A` receives two CAN bytes at offsets 9 and 10 and stores them at:

- `0x3FCA0A88` / `+1` (`0x4200A638`, `0x4200A64A`)
- combined 16-bit value is divided by 10 and stored at `0x3FCA0AA8` (`0x4200A65E..0x4200A662`).

This is a direct raw-to-engineering conversion path.

A second path around `0x4200A6EA` stores bytes 9/10 at `0x3FCA0A7C`/`+2` and another path around `0x4200A722` stores bytes at `0x3FCA0A80`/`+2`.

The generator uses `0x3FCA0A80` and `0x3FCA0AA8` for BCP, so these variables are not arbitrary UI values: they are populated in the CAN receive path.

## 3. BCP exact machine formulas

`0x4200B316` sequence 1:

- byte 0 = transport sequence supplied by caller
- byte 1 = `0x6D`
- byte 2 = `0x01`
- byte 3 = `0xDC`
- byte 4 = `0x05`
- byte 5 = `0xFE`
- byte 6 = `0x01`
- byte 7 = low byte of `0x3FCA0A80`

`0x4200B360` sequence 2:

- byte 1..2 = `0x3FCA0A80` low/high
- byte 3 = `0x69`
- byte 4 = `0x64`
- byte 5 = 10 * (`0x3FCA0AA8 - 20`), low byte
- byte 6 = signed arithmetic equivalent of `35 * (x-20) / 256` (implemented by shifts/adds)
- byte 7 = `0xFF`

The exact code is retained in `src/reconstruction/gbt_payload_generators.c`.

## 4. BCS/BRM current source

At `0x4200B3E8`:

```text
base = 0x3FC98200
lh  a5, 0x0c(base)       ; signed 16-bit 0x3FC9820C
...
byte = 10 * current - 0x60
```

The same signed source is used by BCS and BRM sequence 1.

## 5. BCS sequence 2 energy/time source

At `0x4200B44E`:

- reads `0x3FCA0A??` word at offset `-0x518` from `0x3FCA1000`, i.e. `0x3FCA0AE8`;
- divides by `0xF A60` (machine literal constructed as `0xF000 - 0x5A0` = `0xEA60`, i.e. 60000 decimal);
- subtracts quotient from `0x258` (600 decimal);
- writes little-endian result to bytes 1..2.

Thus this field is explicitly a countdown/inverse-time style transformation of the runtime 32-bit accumulator at `0x3FCA0AE8`.

## 6. BRM identity block

The BRM generator copies from `0x3FC981B0` in several sequences. The RX/parser path also writes a 16-byte block starting at `0x3FC981B0` (`0x4200A742..0x4200A75C`). This establishes that the BRM identity/application data is populated at runtime, not compiled entirely as constants.

## 7. Startup/default configuration values

Function `0x4200930E` initializes several variables used by the charging UI/protocol. Direct constants include:

- `0x3FCA0A80`-area defaults: `0x0010`, `0x0068` in adjacent configuration slots;
- `0x3FCA0AA8` default `0x0168` (360 decimal);
- `0x3FCA0A80` adjacent configuration words `0x0010`, `0x0068`;
- `0x3FCA0A84` adjacent values `3`, `0xE8`;
- `0x3FCA0AA6`-adjacent byte `0x64`.

These are initialization/configuration values, not proof that all are direct CAN payload fields.

## 8. RX parser semantics recovered in this pass

The receive dispatcher around `0x4200A500` branches on the message type byte and writes protocol/application state:

- type `0x03`: 3-byte status/measurement block at `0x3FCA0AAC`; combined value to `0x3FCA0AA0`-area;
- type `0x0E`: two bytes to `0x3FCA0A88`, then `/10` to `0x3FCA0AA8`;
- type `0x09`: two bytes to `0x3FCA0A80`;
- type `0x07`: invokes the configuration initializer;
- type `0x66`: relay/state command; GPIO6 wrappers are selected according to byte 10;
- type `0x02`, `0x05`, `0x53`, `0x5B`: individual status bytes stored in the `0x3FCA...` state area;
- type `0x04` with subcommand `4`: copies a 9-byte block into a `gp`-relative buffer.

This is additional evidence that the firmware has a second application/control protocol layered around the GB/T CAN engine, and the charging variables are fed by both CAN receive processing and local control/UI logic.

## 9. Current confidence

CONFIRMED:
- exact BCP generator formulas;
- exact BCS/BRM current source address `0x3FC9820C`;
- exact BCS sequence-2 accumulator source `0x3FCA0AE8`;
- exact CCS conversion path into `0x3FCA0AA8`;
- BRM identity block runtime population at `0x3FC981B0`;
- relevant RX dispatcher branches.

NOT YET RESOLVED:
- semantic meaning of every `0x3FCA...` local variable;
- exact origin of `0x3FC9820C` before it is consumed by the generator;
- full BRM identity field decoding;
- BCL source-variable chain.

Next target: trace every writer of `0x3FC9820C`, `0x3FCA0AE8`, `0x3FCA0AD8`, and the BCL source variables, then close the GB/T runtime data model.
