# Step 7 verification

## Confirmed

- PGN 0x200 => 49-byte BRM transport path.
- PGN 0x600 => 13-byte BCP transport path.
- PGN 0x1100 => 9-byte BCS transport path.
- TP sequence byte is generated separately from application payload.
- Application payload generator is selected by PGN.
- `0x3FC981F4` is the transport PGN field, not a payload pointer.
- BCP first 16-bit field is encoded as `0x016D`, i.e. 3.65 V, directly matching the standard's 0.01 V/bit representation.
- BCP current field is `0x05DC`, which under the standard's 0.1 A/bit and -400 A offset represents -250 A.
- BRM uses a live-variable generator rather than a constant 49-byte table.

## External protocol cross-check

The public GB/T 27930 material lists BRM as PGN 512, 49 bytes, BCP as PGN 1536, 13 bytes, and BCS as PGN 4352, 9 bytes. It also defines the multi-information-frame transport for messages longer than 8 bytes. The firmware's identifiers, lengths and transport structure match these definitions.

## Remaining uncertainty

Runtime values are not inferred from the standard. The next pass will find every writer of the RAM variables used above and recover their initialization, UI source, ADC source, or CAN source. This will make the final byte stream deterministic rather than merely formulaic.
