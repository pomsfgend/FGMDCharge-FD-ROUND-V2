# Step 9 index

This is the first intentionally large-pass report. It consolidates the GB/T runtime data path, local application command path, full flash partition layout, task bootstrap, and the boundary into LCD/BLE reverse engineering.

Primary report: `step9_large_pass.md`
Evidence: `evidence_step9.txt`
Structured runtime map: `gbt_runtime_step9.json`
Flash map: `flash_layout_step9.csv`
