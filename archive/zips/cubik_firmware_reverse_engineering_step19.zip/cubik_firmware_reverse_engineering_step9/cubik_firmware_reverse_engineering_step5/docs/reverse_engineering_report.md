# Cubik firmware reverse-engineering report

## 1. Executive summary

The uploaded file is a 4 MiB ESP32-C3 flash dump containing an ESP-IDF application.
The firmware identifies itself as **ESP-IDF v5.0.9**.

The most important hardware reconstruction is:

| Subsystem | GPIO / parameter |
|---|---|
| LCD controller | **ILI9341** |
| LCD logical resolution | **240 x 280** in the LVGL application |
| LCD SPI host | **SPI2_HOST / host 1** |
| LCD MOSI | **GPIO5** |
| LCD MISO | **unused (-1)** |
| LCD SCLK | **GPIO19** |
| LCD CS | **GPIO4** |
| LCD DC | **GPIO18** |
| LCD RST | **not controlled by firmware (-1)** |
| LCD SPI mode | **0** |
| LCD pixel clock | **20 MHz** |
| LCD command/parameter width | **8 / 8 bits** |
| LCD transaction queue | **10** |
| Touch controller | **CST816S-compatible protocol; very strong identification** |
| Touch I2C | **I2C0** |
| Touch SDA | **GPIO1** |
| Touch SCL | **GPIO8** |
| Touch I2C speed | **100 kHz** |
| Touch address | **0x15 (7-bit)** |
| Touch reset/IRQ | **not controlled by the firmware code recovered here** |
| CAN/TWAI TX | **GPIO10** |
| CAN/TWAI RX | **GPIO9** |
| Relay/control output A | **GPIO6** |
| Relay/control output B | **GPIO7** |
| Auxiliary output | **GPIO2, initialized HIGH** |
| PWM/LEDC output | **GPIO3** |
| PWM | **60 kHz, 10-bit, LEDC channel 0/timer 0** |

## 2. ESP32-C3 / firmware layout

The application image has six segments. The factory application starts at flash offset 0x10000.
The dump also contains NVS, OTA data and an OTA application slot.

The application contains source-path/log strings such as:
- `./main/esp_lcd_ili9341.c`
- `./main/CAN.c`
- `./main/ADC.c`
- `ili9341`
- `CAN_Mode_Init`
- `adc_init`
- `pwm_init`
- `myTask_CAN`
- `myTask_lcd`
- `myTask_Timer`

Relevant reconstructed code locations are in the `0x42000020` application code segment:
- application/task startup: segment offset `0x7D42`
- touch I2C init: `0x8A96`
- touch low-level I2C register read wrapper: `0x898E`
- touch coordinate reader: `0x89CA`
- LCD main/init: `0x8B82`
- LCD/SPI configuration and panel creation: around `0x8BE0..0x8E00`
- board output initialization: `0xC80E`
- TWAI/CAN init: `0xB916`
- PWM/LEDC init: `0xCF7C`
- ADC init: `0xD00E`

Virtual addresses can be calculated as:
`0x42000020 + segment_relative_offset`.

## 3. LCD / ILI9341 reconstruction

The firmware explicitly uses the Espressif ILI9341 panel driver and LVGL.
The SPI bus is configured as:

```c
.mosi_io_num = 5,
.miso_io_num = -1,
.sclk_io_num = 19,
.quadwp_io_num = -1,
.quadhd_io_num = -1,
.max_transfer_sz = 38400,
```

The panel I/O configuration is reconstructed as:

```c
.cs_gpio_num = 4,
.dc_gpio_num = 18,
.spi_mode = 0,
.pclk_hz = 20000000,
.trans_queue_depth = 10,
.lcd_cmd_bits = 8,
.lcd_param_bits = 8,
```

The panel configuration has:
- `reset_gpio_num = -1`
- RGB order
- 16 bits per pixel

This means there is **no firmware-controlled LCD reset GPIO** in this image.

The application later configures an LVGL display area of **240 x 280**. Do not automatically assume the physical ILI9341 glass is only 240 x 280; the controller is normally capable of 240 x 320 and the firmware may deliberately use a 280-pixel logical/visible region.

## 4. Touchscreen reconstruction

The I2C initialization structure is unusually clear:

```c
.mode = I2C_MODE_MASTER,
.sda_io_num = 1,
.scl_io_num = 8,
.sda_pullup_en = GPIO_PULLUP_ENABLE,
.scl_pullup_en = GPIO_PULLUP_ENABLE,
.master.clk_speed = 100000,
```

The firmware uses device address **0x15** and performs:

1. write/read register `0x15`, one byte
2. write/read register `0xA7`, one byte
3. read register `0x02` for finger/touch count
4. when touched, read four bytes starting at `0x03`
5. assemble X from `0x03/0x04`
6. assemble Y from `0x05/0x06`

That startup and register sequence is characteristic of the **CST816S / CST816x family**. The `0xA7` access is the chip-ID register in CST816S-oriented drivers.

The firmware does **not** show a GPIO interrupt configuration for touch and does not show a dedicated touch reset GPIO in this application path. The touch data is therefore handled by I2C polling/reads rather than a firmware-configured IRQ line.

## 5. CAN / TWAI

The CAN configuration data is especially reliable because it maps exactly onto the ESP-IDF TWAI general configuration:

```text
mode           = 0  -> TWAI_MODE_NORMAL
tx_io_num      = 10
rx_io_num      = 9
clkout_io_num  = -1
bus_off_io_num = -1
tx_queue_len   = 10
rx_queue_len   = 10
alerts_enabled = 0
clkout_divider = 0
intr_flags     = 2
```

The firmware contains calls corresponding to:
- `twai_driver_install(...)`
- `twai_start()`
- `twai_transmit(...)`
- `twai_receive(...)`

The **pins are confirmed**. The exact CAN bitrate should be recovered from the TWAI timing configuration before reusing it; it is not safe to invent it from the GPIO map.

## 6. Relay / board outputs

The firmware contains a dedicated output initialization function that configures a bitmask covering GPIO2, GPIO6 and GPIO7, then performs:

```c
gpio_set_level(6, 0);
gpio_set_level(7, 0);
gpio_set_level(2, 1);
```

Separate helper paths explicitly switch:

```c
GPIO6 -> HIGH / LOW
GPIO7 -> HIGH / LOW
```

Therefore **GPIO6 and GPIO7 are confirmed switched control outputs** and are the strongest relay candidates.

The firmware itself does not contain a semantic string such as `RELAY1` / `RELAY2`, so the physical assignment of "relay A/B" should be verified against the PCB with a continuity/voltage test.

GPIO2 is initialized HIGH and is not identified conclusively as a relay. Treat it as an auxiliary enable/control output until the board is traced.

## 7. PWM output / possible indicator or backlight

`main/ADC.c` contains an LEDC timer configuration:

```c
speed_mode      = 0
duty_resolution  = 10 bits
timer_num       = 0
freq_hz         = 60000
clk_cfg         = 0
```

The channel configuration explicitly sets:

```c
gpio_num = 3
channel  = LEDC_CHANNEL0
timer    = LEDC_TIMER0
```

Therefore **GPIO3 is definitely a PWM/LEDC output**.

The binary does not contain a semantic name tying GPIO3 to a physical component. It may be the display backlight or a status/indicator LED depending on the PCB. If your observed delayed "station ready" LED is a discrete LED, GPIO3 is a strong candidate only if the LED is connected to the PWM output; verify electrically before designing the replacement PCB/firmware.

## 8. Other GPIOs

- GPIO0 is used as ADC1 channel 0.
- GPIO12..17 belong to the ESP32-C3 flash/system side and should not be reused casually.
- GPIO18 and GPIO19 are deliberately reused by the application for LCD DC/SCLK. This implies normal GPIO/peripheral routing has been configured accordingly.
- GPIO20/21 have no conclusive application-level assignment in the recovered code path.
- No custom UART peripheral mapping was recovered from the application strings/configuration.

## 9. Reproduction order

For a new personal firmware, the safest bring-up order is:

1. Boot ESP32-C3 with only serial logging.
2. Configure GPIO6/7 as outputs and verify relay polarity with no load.
3. Configure I2C0 GPIO1/8 at 100 kHz and verify address 0x15.
4. Read CST816S register 0xA7.
5. Read touch count 0x02 and coordinates 0x03..0x06.
6. Configure SPI2: MOSI5, SCLK19, MISO unused.
7. Configure CS4 and DC18.
8. Start ILI9341 in SPI mode 0 at 20 MHz.
9. Use logical LVGL size 240x280 initially.
10. Configure GPIO3 PWM only after the LCD/touch path is stable.
11. Add TWAI on TX10/RX9 and reproduce CAN timing separately.
12. Only then reproduce the higher-level GB/T-DC state machine.

This separates electrical bring-up from protocol debugging and makes it much easier to identify a wrong pin or polarity.

## 10. Important confidence notes

**High confidence**
- ESP32-C3 target
- ESP-IDF 5.0.9
- ILI9341
- LCD SPI pins 5/19, CS4, DC18, MISO unused
- LCD SPI mode 0 / 20 MHz
- I2C0 pins 1/8, 100 kHz
- touch address 0x15
- CST816x-family protocol; CST816S is the strongest match
- CAN TX10 / RX9
- relay/control outputs GPIO6/7
- PWM GPIO3
- GPIO2 initialized HIGH

**Needs PCB-level verification**
- whether GPIO6 is relay #1 or #2
- whether GPIO3 is the status LED, LCD backlight, or another PWM load
- physical role of GPIO2
- whether the touch IC is specifically CST816S vs another CST816x-family revision
- exact physical ILI9341 glass dimensions versus the firmware's 240x280 logical area
- exact CAN bitrate/timing

## 11. File hash

SHA-256 of the uploaded dump:

`1428dbddc0749eee8ac133b1e16b6c0805a2da4bb4b0c73bc759c1500b03f233`

## 12. Included reconstruction sources

See `src/`:
- `reconstructed_pins.h`
- `ili9341_reconstruction.c`
- `cst816s_reconstruction.c`
- `relay_outputs.c`
- `can_reconstruction.c`
- `pwm_gpio3.c`

The source files intentionally reconstruct the **hardware interface**, not the proprietary GB/T-DC state machine.
