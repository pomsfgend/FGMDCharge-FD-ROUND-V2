# Relay call map

Application wrappers:

0x4200C870 -> GPIO6 HIGH
0x4200C882 -> GPIO6 LOW
0x4200C894 -> GPIO7 HIGH
0x4200C8A6 -> GPIO7 LOW

Direct charging-state sequence:

0x4200C2FA -> call 0x4200C882 -> GPIO6 = 0
0x4200C2FC -> call 0x4200C894 -> GPIO7 = 1

This occurs after the state-5 elapsed-time check against 0x2710 (10000 ms)
and when the protocol substate at 0x3FCA0B0C is 3.
