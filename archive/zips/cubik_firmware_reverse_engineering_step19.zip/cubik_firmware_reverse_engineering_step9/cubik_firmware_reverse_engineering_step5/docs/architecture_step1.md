# Architecture recovery — Step 1
## Application/task skeleton

This is deliberately the first small reconstruction stage. It does NOT claim to have recovered
the complete function bodies. It establishes the module boundaries and the runtime skeleton that
can be proved from strings, source-path remnants and ESP-IDF symbols.

### Confirmed application modules

The binary retains source-path/function strings for these modules:

| Module | Evidence | Recovered role |
|---|---|---|
| `main/BLE.c` | `./main/BLE.c`, `BLE_init`, GATTS strings | BLE/GATT service and configuration |
| `main/CAN.c` | `./main/CAN.c`, `CAN_Mode_Init`, `Can_Send_Msg`, `CAN1Process_Mails_Receive` | CAN/TWAI transport |
| `main/esp_lcd_ili9341.c` | source path + `esp_lcd_new_panel_ili9341` | ILI9341 panel driver |
| LCD/LVGL code | `lcd_main`, `lvgl_tick`, LVGL strings | UI/display task |
| `main/time.c` | source path + `gptimer_*` API strings | hardware timer / periodic timing |
| `main/ADC.c` | source path + `adc_init`, `adc_loop`, `pwm_init` | ADC measurement + PWM |
| FreeRTOS | `xTaskCreateStaticPinnedToCore`, `vTaskDelay`, task-name strings | task scheduler/runtime |

### Named tasks

Four application task names survive intact:

```text
myTask_BLE
myTask_CAN
myTask_lcd
myTask_Timer
```

This is stronger than merely finding generic FreeRTOS symbols: these are application-specific
task names and therefore represent actual task objects/creation calls in the original firmware.

### Probable runtime topology

```text
                         +------------------+
                         |    app_main()    |
                         +---------+--------+
                                   |
                  +----------------+----------------+
                  |                |                |
             BLE_init()      CAN_Mode_Init()    lcd_main()
                  |                |                |
             myTask_BLE       myTask_CAN        myTask_lcd
                                   |
                              CAN RX/TX path
                                   |
                             GB/T-DC logic

                  +----------------+
                  |
             timer / time.c
                  |
             myTask_Timer
                  |
             periodic events /
             protocol timing

             ADC.c
              |
        +-----+------+
        |            |
     ADC input    LEDC PWM
       GPIO0       GPIO3
```

The exact call ordering and task priorities are intentionally left unresolved until the next
disassembly pass. Do not use guessed priorities/stack sizes in a replacement firmware.

## LCD task

The LCD path is unusually clear:

```text
lcd_main
  -> initialize SPI bus
  -> install esp_lcd SPI panel IO
  -> install ILI9341 panel
  -> panel reset
  -> panel init
  -> mirror(false,false)
  -> display ON
  -> initialize LVGL
  -> register display driver
  -> create/start LVGL tick timer
  -> display LVGL Meter Widget
```

The firmware also exposes these panel operations:

```text
panel_ili9341_invert_color
panel_ili9341_mirror
panel_ili9341_swap_xy
panel_ili9341_disp_on_off
panel_ili9341_reset
panel_ili9341_init
panel_ili9341_draw_bitmap
```

This strongly indicates that the display code is based on Espressif's `esp_lcd` ILI9341
driver with an LVGL front-end, rather than a completely custom framebuffer driver.

## BLE task

The BLE module contains:

```text
GATTS_TABLE_DEMO
BLEname
BLE_init
gatts_profile_event_handler
example_prepare_write_event_env
esp_ble_gatts_send_response
esp_ble_gatts_send_indicate
notify enable
indicate enable
notify/indicate disable
```

Therefore the BLE part is not just scanning: it implements a GATT server/profile and supports
notifications/indications and writable attributes.

The firmware also persists a `BLEname` through NVS:

```text
Open NVS Table fail
Save BLEname Fail !!
Save BLEname ok !!
```

The exact service/characteristic UUIDs will be recovered separately.

## CAN task

The CAN module exposes application-level wrappers:

```text
CAN_Mode_Init
Can_Send_Msg
CAN1Process_Mails_Receive
```

and ESP-IDF TWAI operations:

```text
twai_driver_install
twai_start
twai_transmit
twai_receive
```

The hardware mapping is already confirmed:

```text
TX = GPIO10
RX = GPIO9
mode = TWAI_MODE_NORMAL
TX queue = 10
RX queue = 10
```

The next CAN pass should recover:
1. TWAI timing/bitrate
2. filter configuration
3. transmit frame construction
4. receive frame parsing
5. relationship between CAN frames and the timer/state machine

## Timer module

`main/time.c` survives in the binary and uses the ESP-IDF GPTimer API:

```text
gptimer_new_timer
gptimer_register_event_callbacks
gptimer_enable
gptimer_set_alarm_action
gptimer_start
```

The exact alarm period and callback behavior are not yet asserted.

This is important for GB/T-DC because protocol timing is likely spread between:
- the GPTimer callback,
- `myTask_Timer`,
- `myTask_CAN`.

We should recover these together rather than treating them as unrelated code.

## ADC/PWM module

`main/ADC.c` contains two independent hardware functions:

### ADC
```text
adc_oneshot_new_unit
adc_oneshot_config_channel
adc_oneshot_read
adc_cali_raw_to_voltage
```

ESP32-C3 ADC channel 0 is GPIO0.

### PWM
```text
ledc_timer_config
ledc_channel_config
ledc_set_duty
ledc_update_duty
```

PWM is:
```text
GPIO3
LEDC channel 0
LEDC timer 0
10-bit duty
60 kHz
```

The semantic identity of the physical GPIO3 load remains a PCB-tracing question.

## What is intentionally NOT reconstructed in Step 1

Do not yet assume:
- FreeRTOS task priorities
- task stack sizes
- task creation order
- GPTimer frequency
- CAN bitrate
- CAN IDs
- GB/T-DC state numbers
- BLE UUIDs
- relay polarity under the real load
- physical identity of GPIO3

Those are the next small recovery targets.

## Next recovery unit

The highest-value next unit is:

**`myTask_CAN` + `CAN_Mode_Init` + `CAN1Process_Mails_Receive` + `Can_Send_Msg`**

because this should reveal the actual communication architecture and give us a bridge
between the hardware pinout and the GB/T-DC state machine.

After that:
1. `myTask_Timer` / `main/time.c`
2. relay/control state transitions
3. LCD/LVGL screen objects
4. touch event handling
5. BLE GATT UUIDs and writable characteristics
6. ADC/PWM semantics
