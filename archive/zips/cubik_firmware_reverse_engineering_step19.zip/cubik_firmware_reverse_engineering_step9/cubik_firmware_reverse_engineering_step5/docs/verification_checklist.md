# PCB verification checklist

1. With power removed, continuity-test GPIO6 and GPIO7 from MCU to the two relay-driver transistor/optocoupler inputs.
2. Identify the polarity of each relay input by applying firmware test levels with the high-voltage/load side disconnected.
3. Trace GPIO3 to determine whether it goes to the TFT backlight transistor or a discrete status LED.
4. Trace GPIO2; firmware drives it HIGH at startup, but the binary does not give it a semantic name.
5. Verify the touch IC marking. The firmware protocol is a very strong CST816S/CST816x match, but the exact silicon suffix is a board-level fact.
6. Verify the TFT glass dimensions and visible area before reproducing LVGL coordinates; firmware uses 240x280.
7. Recover TWAI timing before connecting to the real GB/T-DC control electronics.
