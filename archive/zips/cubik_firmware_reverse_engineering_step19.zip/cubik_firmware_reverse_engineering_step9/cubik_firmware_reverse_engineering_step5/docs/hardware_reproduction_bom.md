# Reproduction BOM / hardware interface

MCU
- ESP32-C3

Display
- ILI9341 SPI TFT
- SPI2
- MOSI GPIO5
- SCLK GPIO19
- CS GPIO4
- DC GPIO18
- MISO NC
- RST firmware-controlled: NO
- 20 MHz, mode 0
- logical UI: 240x280
- RGB565 / 16 bpp

Touch
- Hynitron CST816x family; CST816S strongest match
- I2C0
- SDA GPIO1
- SCL GPIO8
- 100 kHz
- 7-bit address 0x15
- no firmware IRQ/reset recovered

Power / switching
- GPIO6 switched output
- GPIO7 switched output
- GPIO2 auxiliary output, initial HIGH
- GPIO3 LEDC/PWM output, 60 kHz, 10-bit
