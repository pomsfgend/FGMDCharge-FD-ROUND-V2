# Cubik firmware reverse engineering — GB/T payload reconstruction, step 4

## Status

This step continues directly from the recovered GB/T state machine. The firmware is an ESP32-C3 application using ESP-IDF TWAI at 250 kbit/s, extended 29-bit CAN identifiers.

**Confidence labels:** CONFIRMED = directly visible in disassembly; HIGH = direct disassembly + standard semantics; INFERRED = interpretation not yet uniquely proven.

## 1. RX parser: exact field extraction

Function: `0x4200C4A8`.

Input is a `twai_message_t *`. The firmware:

1. rejects NULL;
2. reads the CAN identifier from offset `+0x04`;
3. requires identifier low byte `0x56` and the following byte `0xF4`, i.e. charger-source/BMS-destination address pattern;
4. uses payload beginning at `message + 9`;
5. records the current firmware time into per-message timestamps;
6. decodes selected charger messages into a persistent RAM structure based at `0x3FC98200`.

This is direct evidence that the adapter is not merely passing CAN through: it maintains a protocol state/cache layer.

### Charger message cache offsets

| CAN ID | Message | RAM field | Exact action |
|---|---|---:|---|
| `0x1826F456` | CHM | `+0x18` | timestamp |
| `0x1801F456` | CRM | `+0x1C` | timestamp; payload byte 0 -> `+0x3C` |
| `0x1807F456` | CTS | `+0x20` | timestamp |
| `0x1808F456` | CML | `+0x24` | timestamp + max voltage/current decode |
| `0x100AF456` | CRO | `+0x28` | timestamp; payload byte 0 -> `+0x3E` |
| `0x1812F456` | CCS | `+0x2C` | timestamp + voltage/current decode |
| `0x101AF456` | CST | `+0x30` | timestamp |
| `0x181DF456` | CSD | `+0x34` | timestamp |
| `0x081FF456` | CEM | `+0x38` | timestamp |

The exact executable constants above are not inferred from a protocol table; they are literal comparisons in the binary.

## 2. CCS decode — exact arithmetic

At `0x4200C5C0..0x4200C674`, CCS payload is decoded.

### Measured voltage

Bytes:

- `data[0]`
- `data[1]`

are combined as a 16-bit little-endian value:

`raw_voltage = data[0] | (data[1] << 8)`

The value is retained at structure offset `+0x12`.

Then:

`voltage_10V = raw_voltage / 10`

and a firmware global at `0x3FCA1508` receives this reduced value.

This is consistent with GB/T SPN 3075: 0.1 V/bit.

### Measured current

Bytes:

- `data[2]`
- `data[3]`

are combined as a signed 16-bit value:

`raw_current = int16(data[2] << 8 | data[3])`

The firmware then applies:

`current_A = raw_current / 10 - 400`

The result is clamped to zero if negative in the local cache.

The standard's current encoding is 0.1 A/bit with -400 A offset, matching this implementation exactly.

### Derived current bytes

The firmware additionally computes a signed/negated current representation and scales it by 60:

`x = -current_A * 60`

followed by extraction of high/low bytes into globals around `0x3FCA160C`.

This is an application-specific representation used by the Cubik output/control path; the exact consumer will be traced in the next TX/UI pass.

## 3. CML decode — exact arithmetic

Function block `0x4200C68A..0x4200C79A`.

### Maximum output voltage

`data[0..1]` are combined little-endian and retained at cache offset `+0x0E`.

A byte copy is also kept in application RAM.

### Maximum output current

`data[2..3]` are combined as a 16-bit value and retained at cache offset `+0x10`.

The firmware computes:

`max_current_A = raw / 10 - 400`

Then derives a signed/negated representation multiplied by 60 for application use.

Again, this matches the GB/T 27930 current encoding.

### Additional CML voltage field

`data[4..5]` are decoded into cache offset `+0x08`, then:

`value = raw / 10 - 400`

followed by negation and conversion into the same 60x representation.

`data[6..7]` are decoded similarly into cache offset `+0x0A`.

The exact semantic names of these fields will be resolved against the standard table and their TX consumers; the byte-level behavior is already confirmed.

## 4. TX dispatcher: exact message set

Function: `0x4200BA6E`.

The dispatcher receives the CAN identifier and constructs the payload in a local 8-byte buffer. It contains direct cases for the Cubik/BMS-side GB/T identifiers.

### BCL — `0x181056F4`

**CONFIRMED.**

The function throttles BCL using a timestamp at cache `+0x54`, requiring at least `0x32 = 50 ms` between sends.

This exactly matches the GB/T BCL cycle.

Payload construction begins at `0x4200BC5C`.

- DLC = 5.
- Byte 0/1: charging-voltage demand, source selected from application state.
- Byte 2/3: charging-current demand, source selected from application state.
- Byte 4: charging mode / control byte.

The source values are not constants: they are calculated from RAM and charger feedback. Therefore BCL is a true dynamic control message, not a canned response.

A key arithmetic block:

```text
value = source_value * 10
if compared against charger-side current capability:
    choose the appropriate application current representation
```

The firmware stores intermediate values around `0x3FCA1508`, `0x3FCA1550`, `0x3FCA1608`, and related globals.

**Important:** do not replace this with a guessed fixed payload. The next pass will trace every source global backwards to ADC/UI/BLE/control inputs.

The public GB/T specification confirms BCL is the vehicle charging-demand message, 5 bytes, 50 ms, with voltage resolution 0.1 V/bit and current resolution 0.1 A/bit with -400 A offset. citeturn0search5turn0search8

### BCS — `0x181156F4`

**CONFIRMED.**

- DLC = 7.
- Timestamp gate uses cache `+0x5C`.
- The firmware constructs:

`46 00 00 3C 00 00 10`

in the local payload buffer before transmission, then records the send time.

This is not merely a protocol default: the literal bytes are present in executable code at `0x4200BBBC..0x4200BC0A`.

The message is periodically transmitted as the battery charging total-status message.

Because standard BCS is a multi-parameter status message and the normal GB/T payload is larger than 8 bytes in newer protocol descriptions, the exact relationship between this 7-byte implementation and the protocol variant will be retained as a compatibility finding rather than silently "corrected". The firmware's actual bytes are the authoritative source for the replacement implementation.

### BSM — `0x181356F4`

**CONFIRMED.**

- DLC = 7.
- Timestamp gate uses cache `+0x60`.
- Literal payload:

`5F 40 01 68 01 4A 4B`

at `0x4200BD68..0x4200BDC4`.

This is a fixed battery-status payload in the original firmware.

The implementation therefore exposes a major design characteristic of Cubik: it emulates a battery/BMS with largely static identity/status values rather than deriving every battery parameter from sensors.

### BST — `0x101956F4`

**CONFIRMED.**

- DLC = 4.
- Timestamp gate uses cache `+0x64`.
- Payload:

`40 00 40 00`

at `0x4200BD26..0x4200BD62`.

This is sent as the BMS/vehicle stop-charging message when the state machine reaches the termination path.

### BSD — `0x181C56F4`

**CONFIRMED.**

This is the BMS/vehicle statistics message.

The code path at `0x4200BDCA` performs a timestamp check against cache `+0x68`, then enters a multi-stage construction path. It is **not** a simple fixed one-frame payload.

It uses several status bytes assembled from state/timing conditions. Exact semantic mapping will be handled after the transport and termination path are fully reconstructed.

### BHM — `0x182756F4`

**CONFIRMED.**

The dispatcher has a direct BHM case. It waits for a minimum interval of `0xC8 = 200 ms` before entering the BCP/handshake-related dispatch region.

The standard specifies a 250 ms BHM cycle; the apparent 200 ms guard here is therefore an implementation scheduling/guard interval rather than proof of a 200 ms protocol period. The actual task-level cadence and call frequency must be considered together.

### BRM — `0x180256F4`

**CONFIRMED.**

BRM does not fit into one ordinary 8-byte CAN frame in this implementation. The dispatcher routes it through the transport machinery.

At `0x4200BFB6`, after a `0xFA = 250 ms` send guard, it invokes:

`transport_send(payload_length=0x200, destination=0xF4, source=0x56, pgn=0x0200)`

The literal `0x200` argument is the application/transport length parameter used by the firmware's transport routine.

This is the strongest direct evidence that BRM is generated as a multi-frame identification block rather than an ordinary single-frame packet.

### BCP — `0x180656F4`

**CONFIRMED.**

The dispatcher checks cache timestamp `+0x4C` with a `0xFA = 250 ms` interval.

When due, it invokes the transport function:

`transport_send(length=0x600, destination=0xF4, source=0x56, pgn=0x0600)`

and updates the timestamp.

Thus BCP is explicitly treated as a long/multi-frame message by the firmware.

The `0x600` argument is the internal length parameter; the transport layer validates lengths against approximately `0x6F0`, so it is not a literal "1536-byte payload" assumption without tracing the transport buffer representation. The exact serialized payload length will be recovered from the transport buffer.

## 5. Charger-side timing cache

The TX dispatcher uses these persistent timestamp fields:

| Cache offset | Message | Guard |
|---:|---|---:|
| `+0x44` | BHM-related path | 200 ms |
| `+0x48` | BRM | 250 ms |
| `+0x4C` | BCP | 250 ms |
| `+0x50` | BRO | 250 ms |
| `+0x54` | BCL | 50 ms |
| `+0x58` | BEM/error-related path | 1000 ms |
| `+0x5C` | BCS | 250 ms |
| `+0x60` | BSM | 250 ms |
| `+0x64` | BST | 10 ms |
| `+0x68` | BSD | 250 ms |
| `+0x6C` | BEM/CEM termination path | 1000 ms |

The existence of these independent gates is useful for reconstructing the original task loop: the CAN task can run frequently while individual protocol messages are rate-limited internally.

## 6. Fixed payloads recovered so far

```text
BSM  0x181356F4  DLC 7
     5F 40 01 68 01 4A 4B

BST  0x101956F4  DLC 4
     40 00 40 00

BCS  0x181156F4  DLC 7
     46 00 00 3C 00 00 10

BRO  0x100956F4  DLC 1
     01 or AA depending on state/CRM progression
```

The last line reflects the state-dependent BRO/CRO negotiation path; it must not be treated as one universal value.

## 7. Critical architectural finding

The firmware has three distinct layers:

```text
charger CAN RX
      │
      ▼
0x4200C4A8
RX decoder/cache
      │
      ├── charger timestamps
      ├── decoded voltage/current limits
      ├── CRO/CRM status
      └── protocol state machine
               │
               ▼
        0x4200C078
       GB/T state machine
               │
               ▼
        0x4200BA6E
       TX dispatcher
               │
       ┌───────┴────────┐
       │                │
single-frame TX     transport TX
(BCL/BCS/BSM/BST)   (BRM/BCP/BSD etc.)
       │                │
       └───────┬────────┘
               ▼
         TWAI transmit
```

This architecture is now sufficiently established that a replacement implementation can be designed around the actual firmware behavior rather than around a generic GB/T implementation.

## 8. Next exact target

The next binary pass should trace:

1. the BCL source globals backwards to their writers;
2. the BRM/BCP transport buffers to recover their complete serialized payloads;
3. BSD/BEM payload generation;
4. exact BRO/CRO handshake bytes;
5. all remaining state-machine transition conditions;
6. then LCD/LVGL/CST816S/BLE.

The protocol standard is used as a semantic cross-check, not as a substitute for binary evidence. GB/T 27930 explicitly defines the charger/BMS message sequence and the 250 kbit/s, 29-bit extended CAN physical/data-link behavior; the binary independently exhibits those same properties. citeturn0search0turn0search4
