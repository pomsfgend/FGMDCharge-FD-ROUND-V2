# Cubik firmware — GB/T TX payload reconstruction, Step 5

Source: ESP32-C3 RISC-V disassembly of dump1.bin.

## Confirmed short-message TX builders

TX dispatcher: `0x4200BA6E`. It receives CAN identifier in `a0`, payload source in `a1`, DLC in `a2`, timestamp/elapsed value in `a4`.

### BCL — 0x181056F4
Function branch: `0x4200BC4A`.
DLC = 5.
Rate gate: current time must be >= cached BCL timestamp (`0x3FC98254`) + 50 ms.

Payload:
- byte 0 = `0x00` in normal path? The dispatcher reserves payload starting at stack+5; branch writes bytes 0..4 there. Exact byte-0 source is the global at `0x3FCA0AA8` (see below); do not replace with a constant.
- bytes 1..2 = `0x3FCA0AA8` (16-bit value, low byte then high byte), copied from two-byte representation at `0x3FCA0AA8`.
- bytes 3..4 are derived from the 16-bit value at `0x3FCA0A84` and transformed as `0x1960 - value`; stored to `0x3FCA0AF2`, then low/high bytes emitted.
- a counter at `0x3FCA0B24` is incremented after each BCL generation.

More exact mapping of the first payload byte requires tracing the caller's preloaded `a1` buffer; branch itself is byte-accurate for bytes 1..4.

### BCS — 0x181156F4
Function branch: `0x4200BBA4` → `0x4200BBCE`.
DLC = 7.
Rate gate: >= cached timestamp `0x3FC9825C` + 250 ms.
Payload is fixed:
`01 46 00 3C 00 00 10`

### BSM — 0x181356F4
Function branch: `0x4200BBA4` → `0x4200BBCE`.
DLC = 7.
Rate gate: >= cached timestamp `0x3FC9825C` + 250 ms.
Payload is also fixed in this firmware:
`01 46 00 3C 00 00 10`

Note: The two message IDs share the same literal payload in this firmware. This is a firmware-specific implementation choice, not a statement that all GB/T implementations do so.

### BST — 0x101956F4
Function branch: `0x4200BAF8` → `0x4200BD26`.
DLC = 4.
Rate gate: >= cached timestamp `0x3FC98264` + 10 ms.
Payload:
`40 00 40 00`

### BSD — 0x181C56F4
Function branch: `0x4200BACE` → `0x4200BD68`.
DLC = 7.
Rate gate: >= cached timestamp `0x3FC98260` + 250 ms.
Payload:
`5F 40 01 68 01 4A 4B`

### BRO — 0x100956F4
Function branch: `0x4200BB58` → `0x4200BBA4`-adjacent path.
DLC = 1.
The caller passes the actual status byte; in the READY transition it is `0xAA`.

## RX-derived physical quantities

### CCS — 0x1812F456
RX parser `0x4200C5C0`:
- bytes 0..1 of CAN data are combined as little-endian 16-bit value.
- voltage raw = `data[0] | data[1]<<8`.
- voltage / 10 is stored as a scaled value.
- current raw = `data[2] | data[3]<<8`, interpreted signed.
- current = current_raw / 10 - 400 A.
- negative current is clamped to 0 for the unsigned/display representation.
- separate signed/absolute representations are produced for subsequent BCL/BCS/UI use.

### CML — 0x1808F456
RX parser `0x4200C68A`:
- maximum voltage = `data[0] | data[1]<<8`.
- maximum current = `data[2] | data[3]<<8`.
- additional fields are parsed from data[4..7], including a current-like field using `/10 - 400` conversion.

## Long messages

### BCP — 0x180656F4
Dispatcher invokes transport `0x4200B516` with length `0xFA` (250 bytes) once the cached CTS/CML timing gate is satisfied.
The source buffer is assembled before transport; complete field mapping remains to be traced.

### BRM — 0x180256F4
Dispatcher invokes the long-message path when its timing gate is satisfied. Complete BRM length/content remains to be traced from the transport source buffer.

## Standard correlation

The reconstructed IDs and stage order match the GB/T 27930 charging sequence. The current official 2023 standard specifies 250 kbit/s, 29-bit extended CAN identifiers and low-byte-first transmission. The standard's charging-stage message set places BCL/BCS/BSM/BST in the charging stage and BSD in the charging-ending stage.

Important: the binary is the authoritative source for what this particular Cubik sends; the standard is used to name and validate the protocol semantics, not to invent missing firmware bytes.
