# Architecture recovery — Step 2
# CAN / TWAI / GB-T protocol layer

## 1. This stage produced a major breakthrough

The CAN configuration is now reconstructed at register/API-structure level.

### TWAI hardware

```text
TX GPIO = 10
RX GPIO = 9
Mode    = TWAI_MODE_NORMAL
```

### General configuration

Recovered static `twai_general_config_t` at:

```text
0x3C0F7578
```

Values:

```text
mode             = 0
tx_io_num        = 10
rx_io_num        = 9
clkout_io_num    = -1
bus_off_io_num   = -1
tx_queue_len     = 10
rx_queue_len     = 10
alerts_enabled   = 0
clkout_divider   = 0
intr_flags       = 2
```

### Timing configuration

Recovered directly from `CAN_Mode_Init()`:

```text
brp             = 16
tseg_1          = 15
tseg_2          = 4
sjw             = 3
triple_sampling = 0
```

For the ESP32 TWAI APB clock of 80 MHz:

```text
bitrate = 80,000,000 / (16 * (1 + 15 + 4))
        = 250,000 bit/s
```

So the Cubik firmware is configured for **250 kbit/s**.

This agrees with the GB/T 27930 physical-layer requirement. citeturn0search0turn1search2

### Acceptance filter

Recovered filter configuration:

```text
acceptance_code = 0x00000000
acceptance_mask = 0xFFFFFFFF
single_filter   = 1
```

In practical terms the controller is configured to accept all CAN identifiers and the application performs protocol-level filtering itself.

---

# 2. CAN task architecture

A real application task was recovered at:

```text
0x42007D2E
```

Its loop is:

```c
CAN_Mode_Init();

for (;;) {
    function_B11C();
    function_C078();
    function_C7E4();

    vTaskDelay(1);
}
```

The `vTaskDelay(1)` is a one-tick yield/delay.

`function_C7E4()` performs a blocking:

```c
twai_receive(&RxMessage, portMAX_DELAY);
```

and then dispatches the received message to the application parser.

Therefore the actual architecture is approximately:

```text
             CAN peripheral
                  │
          TWAI RX GPIO9
                  │
          twai_receive()
                  │
             C7E4()
                  │
          received-frame
              dispatcher
                  │
             C4A8()
                  │
       GB/T-27930 message parser
                  │
       protocol state / timestamps
```

At the same time the task repeatedly executes the protocol/state update functions around:

```text
B11C
C078
```

before waiting for the next CAN frame.

---

# 3. The CAN message structure is confirmed

The application wrapper around TWAI constructs a message with this logical layout:

```c
typedef struct {
    uint32_t flags;
    uint32_t identifier;
    uint8_t  data_length_code;
    uint8_t  data[8];
} CubikTwaiMessageLayout;
```

The original firmware sets:

```text
flags = 0x00000005
```

and then:

```text
identifier       = supplied CAN ID
data_length_code = supplied length
data[]           = supplied payload
```

ESP-IDF defines `TWAI_MSG_FLAG_EXTD` as the extended 29-bit frame flag and `TWAI_MSG_FLAG_SS` as single-shot transmission. Therefore:

```text
0x05 = EXTENDED + SINGLE_SHOT
```

So the Cubik's application-level transmit helper is explicitly producing:

**29-bit extended, single-shot CAN frames.**

This is independently confirmed by the GB/T IDs below. citeturn0search0

---

# 4. Major discovery: the firmware is implementing GB/T 27930

The receive parser at:

```text
0x4200C4A8
```

does this before processing:

```c
identifier = RxMessage.identifier;

if ((identifier & 0xFF) != 0x56)
    ignore;

if (((identifier >> 8) & 0xFF) != 0xF4)
    ignore;
```

So it explicitly expects:

```text
SA = 0x56
DA/PS = 0xF4
```

for the charger -> BMS direction.

This is exactly the conventional GB/T addressing used by the 2015 protocol:

```text
charger = 0x56
BMS     = 0xF4
```

The protocol uses J1939-style 29-bit extended IDs. citeturn1search0turn1search1

---

# 5. Charger -> Cubik receive IDs recovered from the binary

These identifiers are not guessed from a protocol table. They are literal constants reconstructed from the executable.

| CAN ID | GB/T message | Direction | Evidence |
|---|---|---|---|
| `0x1826F456` | CHM | Charger -> BMS | direct constant |
| `0x1801F456` | CRM | Charger -> BMS | direct constant |
| `0x1807F456` | CTS | Charger -> BMS | direct constant |
| `0x1808F456` | CML | Charger -> BMS | direct constant |
| `0x100AF456` | CRO | Charger -> BMS | direct constant |
| `0x1812F456` | CCS | Charger -> BMS | direct constant |
| `0x101AF456` | CST | Charger -> BMS | direct constant |
| `0x181DF456` | CSD | Charger -> BMS | direct constant |
| `0x081FF456` | CEM | Charger -> BMS | direct constant |

These mappings agree with published GB/T 27930 message tables. citeturn1search0turn2search0turn2search1

This is a very strong confirmation that the firmware is not merely using CAN generically: it contains the expected GB/T charging state machine.

---

# 6. Receive parser behaviour

The parser first passes the payload to a protocol/state function:

```c
CAN1Process_Mails_Receive(
    identifier,
    RxMessage.data
);
```

The payload pointer is:

```text
RxMessage.data = &RxMessage + 9
```

The parser then stores timestamps and selected values into a global protocol-state structure around:

```text
0x3FC98200
```

The following fields were directly observed.

## 0x1826F456 — CHM

```text
timestamp -> 0x3FC98220
```

This is the charger handshake/version message.

## 0x1807F456 — CTS

```text
timestamp -> 0x3FC98218
```

This is the optional charger time-synchronisation message.

## 0x1808F456 — CML

```text
timestamp -> 0x3FC9822C

data[0..1] -> protocol variable at offset +0x12
data[2..3] -> protocol variable at offset +0x0C
```

The second 16-bit value is converted approximately as:

```text
value / 10 - 400
```

That matches the GB/T current encoding:

```text
0.1 A/bit
offset = -400 A
```

The public GB/T CML description independently specifies the same encoding. citeturn1search0

## 0x1801F456 — CRM

```text
timestamp -> 0x3FC9821C
data[0]    -> 0x3FC9823C
```

This is the charger identification/handshake message.

The parser therefore preserves the CRM result byte.

## 0x100AF456 — CRO

```text
timestamp -> 0x3FC98228
data[0]    -> 0x3FC9823E
```

This is charger-output-ready.

## 0x1812F456 — CCS

```text
timestamp -> 0x3FC98224
```

The firmware parses several little-endian values:

```text
data[0..1] -> 16-bit value
data[2..3] -> 16-bit value
data[4..5] -> 16-bit value
```

and performs the expected GB/T scale/offset conversions on the voltage/current-related fields.

## 0x101AF456 — CST

```text
timestamp -> 0x3FC98230
```

The charger termination frame is therefore explicitly tracked by the application.

## 0x181DF456 — CSD

```text
timestamp -> 0x3FC98234
```

This is the charger statistics/end-of-charge message.

## 0x081FF456 — CEM

```text
timestamp -> 0x3FC98238
```

This is the charger error message.

---

# 7. Outgoing BMS -> charger message set

A separate large function beginning around:

```text
0x4200BA6E
```

is clearly an outgoing GB/T message generator.

It contains direct comparisons against these BMS-side IDs:

```text
0x181056F4  BCL
0x181156F4  BCS
0x181356F4  BSM
0x181C56F4  BSD
0x101956F4  BST
0x180256F4  BRM
0x180656F4  BCP
0x081E56F4  BEM
0x100956F4  BRO
```

This is another major architectural confirmation.

The published GB/T message tables identify these as BMS-side messages. citeturn2search0turn2search1

---

# 8. Confirmed outgoing message construction

## BCL — `0x181056F4`

The firmware constructs:

```text
DLC = 5
```

and fills:

```text
byte 0/1 = requested charging voltage
byte 2/3 = requested charging current
byte 4   = 0x01
```

The values are converted into the expected GB/T representation.

The constant final `0x01` corresponds to the charging mode field.

So this is not a generic CAN packet — it is the actual **battery charging demand (BCL)** message.

---

## BSM — `0x181356F4`

The firmware constructs:

```text
DLC = 7
```

and fills the packet from the internal battery-state variables.

This corresponds to the standard BSM packet containing:

- highest cell-voltage position
- highest battery temperature
- highest-temperature sensor position
- lowest battery temperature
- lowest-temperature sensor position
- voltage/SOC/current/temperature status bits
- insulation/connector/charging-permission status bits

The standard description confirms this layout. citeturn2search4

---

## BSD — `0x181C56F4`

The firmware constructs:

```text
DLC = 4
```

or a related short statistics payload depending on the state path.

The actual state-specific contents require the next pass through the surrounding state variables.

---

## BST — `0x101956F4`

The firmware constructs:

```text
DLC = 4
```

and uses:

```text
40 00 40 00
```

in one of the observed paths.

This is the BMS stop/termination message path.

---

## BEM — `0x081E56F4`

The firmware contains a dedicated error-message construction path.

It derives individual bits from internal timeout/state flags rather than simply transmitting a static packet.

This is important because it means the firmware has an actual **GB/T timeout/error supervisor**, not merely a packet forwarder.

---

## BRO — `0x100956F4`

The firmware constructs:

```text
DLC = 1
data[0] = state-dependent value
```

and sends it to the charger.

This is the BMS "ready for charging" message.

---

# 9. Multi-frame transport is implemented

The following outgoing message types are longer than 8 bytes:

```text
BRM  0x180256F4
BCP  0x180656F4
BCS  0x181156F4
```

The binary contains a separate transport-layer function around:

```text
0x4200B516
```

which builds the J1939/GB-T multi-frame transport structures.

The code contains constants associated with:

```text
0x1CEC56F4
0x1CEB56F4
0x1CECF456
```

These correspond to the GB/T/J1939 transport protocol:

```text
RTS
CTS
End Of Message ACK
```

This is especially important because it means the Cubik firmware implements not only the short GB/T CAN frames but also the **multi-packet transport layer** required for BRM/BCP/BCS.

Published GB/T analyses show the same transport identifiers and sequence. citeturn2search2

---

# 10. What we can already reconstruct as a protocol state machine

At this stage the architecture can be represented as:

```text
                    ┌─────────────────────┐
                    │      CAN/TWAI       │
                    │ 250 kbit/s, 29-bit  │
                    └──────────┬──────────┘
                               │
                   ┌───────────▼───────────┐
                   │     myTask_CAN        │
                   │       1-tick loop     │
                   └───────────┬───────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
          timing/state    receive task      TX scheduler
              │                │                │
              │          twai_receive           │
              │                │                │
              │                ▼                │
              │        GB/T RX parser           │
              │          0xC4A8                 │
              │                │                │
              │       charger messages         │
              │                │                │
              └────────────┬───┴────────────────┘
                           ▼
                    GB/T state variables
                       @ 0x3FC98200
                           │
                 ┌─────────┼─────────┐
                 ▼         ▼         ▼
               relay      timers    TX data
                 │         │         │
                 └─────────┴─────────┘
                           │
                    BMS messages
                           │
                           ▼
                     CAN TX 10
```

---

# 11. Important architectural discovery

The firmware is **not simply a GB/T-to-GB/T bridge**.

It maintains its own protocol state and timing variables.

Evidence:

- timestamps are saved independently for individual charger messages;
- timeout comparisons use those timestamps;
- a dedicated state byte around `0x3FCA0B1D` is compared against values `1..7`;
- BEM error flags are derived from timeout conditions;
- the CAN task contains a periodic state-processing path;
- output/relay state is tied to this protocol state.

Therefore the next most valuable target is **the timer/state machine**, not the CAN driver itself.

---

# 12. Next recovery unit

The next pass should reconstruct:

```text
myTask_Timer
        +
main/time.c
        +
0x4200C078 state machine
        +
0x4200B11C periodic protocol update
```

The goal will be to determine:

1. exact meaning of states 1..7;
2. when GPIO6 is switched;
3. when GPIO7 is switched;
4. what conditions enable charging;
5. timeout values for CRM/CML/CRO/CCS/CST/CSD;
6. what condition generates BEM;
7. what condition generates BST/CST;
8. which state corresponds to:
   - idle
   - handshake
   - parameter configuration
   - ready
   - charging
   - termination
   - fault.

That should allow us to reconstruct the **actual GB/T charging state diagram** instead of merely reproducing CAN frames.

---

# 13. Confidence

### Confirmed from executable

- 250 kbit/s
- 29-bit extended CAN
- single-shot TX
- CAN TX GPIO10
- CAN RX GPIO9
- accept-all hardware filter
- charger address 0x56
- BMS address 0xF4
- GB/T charger-side IDs
- GB/T BMS-side IDs
- multi-frame transport
- dedicated RX parser
- dedicated TX generator
- protocol timestamps
- timeout/error supervision
- state machine values 1..7

### Not yet fully recovered

- exact semantic names of every internal global variable
- exact transition table for states 1..7
- exact relay transition conditions
- all BCP/BRM/BCS long-message payload fields
- exact timer periods for every timeout
- exact mapping of every internal variable to display fields

