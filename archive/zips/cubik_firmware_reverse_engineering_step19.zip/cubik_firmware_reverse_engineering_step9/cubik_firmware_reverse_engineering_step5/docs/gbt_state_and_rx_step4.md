# GB/T 27930 firmware reconstruction — step 4

## Scope

This step correlates the binary's central charging state machine (`0x4200C078`), RX parser (`0x4200C4A8`) and TX generator (`0x4200BA6E`) with the public GB/T 27930 message sequence.

Confidence labels:
- **CONFIRMED** — directly observed in executable control flow/data.
- **HIGH** — direct binary behavior plus exact GB/T semantics.
- **INFERRED** — plausible but not yet uniquely proven.

## 1. State variable and 10 ms scheduler

Main charging state:
- RAM address: `0x3FCA0B1D`
- read at `0x4200C102`
- values 1..7 are explicitly dispatched.

The central routine `0x4200C078` first checks bit0 of `0x3FCA0B10`, then calls `0x4200B910(10)`.
`0x4200B910` adds 10 to a 16-bit accumulator at `0x3FC981F0`.

**CONFIRMED:** state-machine timebase is 10 ms.

## 2. Main state map

| State | Binary behavior | Protocol interpretation |
|---|---|---|
| 0 | idle/reset; initialization branch returns to state 1 | IDLE / new charging cycle |
| 1 | clears timing/receive state; sets state=2 | handshake start |
| 2 | repeatedly sends BHM; waits for CRM | WAIT CRM / vehicle handshake |
| 3 | sets internal substate=2; sends BCP; waits for CTS/CML timestamps | parameter configuration |
| 4 | GPIO6 HIGH; substate=3; sends BRO with SPN2829=AA; waits for CRO=AA | ready / pre-charge |
| 5 | sends BCL, BSM, BCS; after conditions changes relays; later termination | charging |
| 6 | sends BCL while ending; after counter >9 sends BST; waits ~1s | stop charging |
| 7 | waits up to ~5s, sends BSD; may send BEM; then returns to idle | charging end / finalization |

**HIGH:** this is the standard GB/T phase order. The public standard explicitly lists handshake, parameter configuration, charging, charging-end and error messages in the same sequence. See GB/T 27930-2023 preview and message-start/end table. citeturn0search0turn0search24

## 3. State 1 -> 2

At `0x4200C1C6`:
- clears receive timestamps/flags:
  - `0x3FC9821C`
  - `0x3FC98220`
  - `0x3FC98224`
  - `0x3FC9823C`
- writes state `2` to `0x3FCA0B1D`
- stores current 10-ms time to `0x3FCA0B20`
- clears `0x3FCA0B15` (16-bit)
- clears `0x3FCA0B21`
- clears `0x3FCA0B11`.

**CONFIRMED.**

## 4. State 2: BHM + CRM

At `0x4200C1AA`:
- sends ID `0x182756F4` = BHM.
- payload length is 2 bytes.
- transmission is gated by an internal timestamp plus 200 ms (`0xC8`) in the TX generator.

The RX parser stores:
- CRM timestamp at `0x3FC9821C`
- CRM byte 0 at `0x3FC9823C`.

State 2 transitions to state 3 only when:
- CRM timestamp is valid, and
- CRM byte 0 == `0xAA`.

This exactly matches GB/T: CRM starts with SPN2560=0x00 and changes to 0xAA after BRM; BCP starts after CRM(AA). citeturn0search0turn0search24

**HIGH:** firmware is explicitly implementing the CRM recognition byte as the gate for leaving handshake.

## 5. State 3: BCP and CML/CTS

At `0x4200C11C`:
- sets internal substate `0x3FCA0B15 = 2`
- sends BCP `0x180656F4`.

Transition to state 4 at `0x4200C158` occurs after both:
- timestamp at `0x3FC98220` (CTS) is nonzero
- timestamp at `0x3FC98224` (CML) is nonzero.

The RX parser maps:
- CTS `0x1807F456` -> `0x3FC98220`
- CML `0x1808F456` -> `0x3FC98224`

**CONFIRMED:** the firmware requires both CTS and CML before proceeding.

The public GB/T start/end table places BCP in parameter configuration and ends it on CML reception; CTS is optional in the standard. The Cubik firmware nevertheless records CTS and uses its timestamp as an additional transition condition. citeturn0search24

## 6. State 4: BRO -> CRO

At `0x4200C388`:
- calls relay wrapper `0x4200C870` -> GPIO6 HIGH
- sets internal substate `0x3FCA0B15 = 3`
- sends BRO `0x100956F4`
- payload byte 0 is explicitly `0xAA`.

Then it requires:
- CRO timestamp (`0x3FC98228`) nonzero
- CRO data byte 0 (`0x3FC9823E`) == `0xAA`.

Then state becomes 5 and state timer is reset.

This is the direct firmware implementation of the GB/T BRO/CRO ready handshake. citeturn0search0turn0search24

## 7. State 5: charging loop

At `0x4200C28E` the firmware repeatedly sends:
- BCL `0x181056F4`
- BSM `0x181356F4`
- BCS `0x181156F4`

The TX generator has independent minimum-period gates:
- BCL: 50 ms (`0x32`)
- BSM: 250 ms (`0xFA`)
- BCS: 250 ms (`0xFA`)

These periods match the published GB/T message timing tables. The public overview also classifies these three as charging-phase messages. citeturn0search3turn0search8

### Relay transition

After state-5 timer reaches 10 s (`0x2710`) AND internal substate is 3:
- `0x4200C2FA` -> GPIO6 LOW
- `0x4200C2FC` -> GPIO7 HIGH
- substate becomes 4.

**CONFIRMED:** this is a real executable transition, not a protocol inference.

The exact electrical meaning of GPIO6/GPIO7 remains hardware-dependent; do not globally label them as AC/charge relays until PCB tracing confirms it.

## 8. State 5 -> 6

At `0x4200C180`:
- if state == 6 it is handled elsewhere;
- the state-5 path is reached from the charging branch.
- transition condition is tied to the charging termination flags generated by RX/parser/application state.

The exact semantic source of `0x3FCA0B15 == 1` is not yet uniquely proven.

**INFERRED:** it represents an application-level request/termination condition rather than a direct single GB/T frame.

## 9. State 6: BCL tail + BST

At `0x4200C406`:
- sets internal substate = 5.
- while counter at `0x3FCA0B24` <= 9, sends BCL.
- once counter > 9:
  - sets counter to 20 (`0x14`)
  - sends BST `0x101956F4`.
- waits until timestamp at `0x3FC98230` (BST/CST-related stored time) + 1 s.
- then sets state 7.

The counter is a software pacing mechanism, not a protocol field.

## 10. State 7: BSD / BEM finalization

State 7 starts with a ~5 s deadline:
- state timer base at `0x3FCA0B20`
- deadline + `0x1388` (5000 ms).

At timeout path `0x4200C48C` the firmware sends:
- BSD `0x181C56F4`.

Important correction:
- `0x181C56F4` is **BSD** (BMS -> charger).
- `0x181DF456` is **CSD** (charger -> BMS).

The previous report had one direction label wrong; this step fixes it.

The code may additionally send BEM `0x081E56F4` at `0x4200C27A` depending on the final timing/error condition.

## 11. RX identifier and direction filtering

`0x4200C4A8`:
1. receives pointer to `twai_message_t`
2. reads identifier at offset +4
3. accepts only:
   - low byte = `0x56` (charger source address)
   - next byte = `0xF4` (vehicle/BMS destination)
4. passes payload at `message+9` to transport parser `0x4200B5F8`.

This is direct J1939/GB/T source/destination filtering.

## 12. Exact RX map recovered

| CAN ID | Message | Stored data |
|---|---|---|
| `0x1826F456` | CHM | timestamp `0x3FC98218` |
| `0x1801F456` | CRM | timestamp `0x3FC9821C`; byte0 -> `0x3FC9823C` |
| `0x1807F456` | CTS | timestamp `0x3FC98220` |
| `0x1808F456` | CML | timestamp `0x3FC98224`; decoded output limits |
| `0x100AF456` | CRO | timestamp `0x3FC98228`; byte0 -> `0x3FC9823E` |
| `0x1812F456` | CCS | timestamp `0x3FC9822C`; decoded charger voltage/current |
| `0x101AF456` | CST | timestamp `0x3FC98230` |
| `0x181DF456` | CSD | timestamp `0x3FC98234` |
| `0x081FF456` | CEM | timestamp `0x3FC98238` |

## 13. CCS exact conversion

For CCS (`0x1812F456`):

Voltage:
- bytes 0..1, little-endian
- raw stored at `0x3FC98212`
- displayed/internal voltage = raw / 10.

Current:
- bytes 2..3, little-endian signed/converted path
- raw / 10 - 400
- negative values are clamped to 0 in one internal representation.
- another representation stores the negative current as a positive magnitude using multiplication by 10.

The standard states that charging current is represented as a negative value and uses 0.1 A resolution with a -400 A offset. citeturn0search0

## 14. CML exact conversion

CML bytes 0..1 are decoded as a little-endian 16-bit value and converted with:
`value / 10 - 400`

This is consistent with the GB/T current encoding.

Additional CML fields are stored:
- bytes 2..3 -> internal 16-bit value
- bytes 4..5 -> internal 16-bit value
- bytes 6..7 -> internal 16-bit value
- derived current bytes are mirrored into `0x3FCA...` display/control globals.

The exact semantic labels for all four CML fields will be resolved against the standard's SPN table in the next payload-mapping pass.

## 15. Outgoing TX generator architecture

`0x4200B9F8` is the low-level single-frame sender:
- creates a `twai_message_t`
- clears it
- sets `flags = 0x05`
- sets identifier
- sets DLC
- copies payload
- calls `twai_transmit(..., portMAX_DELAY)`.

`0x4200BA6E` is the high-level periodic message generator:
- argument `a0` = CAN ID
- `a1` = payload length
- `a2` = timestamp/current-time parameter
- it builds payload bytes on the stack
- dispatches through `0x4200B9F8`.

## 16. TX timing gates recovered

Directly visible in `0x4200BA6E`:

- BHM `0x182756F4`: 200 ms minimum gate (`+0xC8`)
- BCP `0x180656F4`: 250 ms minimum gate (`+0xFA`)
- BST `0x101956F4`: 10 ms/100 ms-specific helper path; final exact period still to be correlated
- BCL `0x181056F4`: 50 ms (`+0x32`)
- BCS `0x181156F4`: 250 ms (`+0xFA`)
- BSM `0x181356F4`: 250 ms (`+0xFA`)
- BEM `0x081E56F4`: 250 ms (`+0xFA`)
- BRO `0x100956F4`: direct state-machine invocation, not just generic periodic path
- BSD `0x181C56F4`: 250 ms gate (`+0xFA`)
- BHM/BRM/BCP use multi-frame transport where required.

Some standard intervals differ slightly depending on whether the firmware's generic gate is measured from first transmission or from a state-specific timer; exact cycle behavior will be verified with the remaining disassembly.

## 17. Long-frame transport

`0x4200B516` and `0x4200B5F8` implement the J1939/GB/T transport protocol.

Confirmed:
- RTS `0x1CEC56F4`
- CTS `0x1CEB56F4`
- EOM ACK `0x1CECF456`
- maximum payload check is `<= 0x6F0` bytes
- transport state machine has states 1..6
- tracks total length, packet count, sequence number, timeout and acknowledgements.

BRM and BCP/other variable-length messages are therefore not ordinary 8-byte CAN frames.

## 18. Current firmware charging sequence

```text
IDLE
  |
  v
STATE 1: initialize handshake
  |
  v
STATE 2: BHM <---- CHM/CRM
  |       wait CRM[0] == 0xAA
  v
STATE 3: BCP ---->
  |       wait CTS + CML
  v
STATE 4: BRO[0] = 0xAA ---->
  |       wait CRO[0] == 0xAA
  v
STATE 5: CHARGING
  |       BCL 50ms
  |       BSM 250ms
  |       BCS 250ms
  |       relay transition after 10s/substate 3
  |
  v
STATE 6: STOP
  |       BCL tail
  |       BST
  |       wait ~1s
  v
STATE 7: END
  |       BSD / optional BEM
  v
IDLE
```

## 19. Next exact target

The next binary pass should resolve **payload bytes and formulas**, not general protocol theory:

1. BHM 2-byte payload.
2. BRM long-frame source buffer and its exact 49-byte contents.
3. BCP long-frame source buffer and all SPNs.
4. BRO/CRO exact status semantics.
5. BCL voltage/current/SoC/remaining-time fields.
6. BCS voltage/current/SOC/charge-state fields.
7. BSM status bits.
8. BST stop reason.
9. BSD statistics payload.
10. BEM error code.
11. exact transport packetization and sequence numbering.

Only after those are recovered should the analysis move to LCD/LVGL, touch, BLE, ADC/PWM and remaining GPIOs.

## 16. RX parser: exact byte extraction recovered

### CRM (`0x1801F456`)
- `data[0]` is copied to `0x3FC9823C` and used as the `0xAA` recognition gate.
- Timestamp is copied to `0x3FC9821C`.

### CRO (`0x100AF456`)
- `data[0]` is copied to `0x3FC9823E` and compared against `0xAA`.
- Timestamp is copied to `0x3FC98228`.

### CCS (`0x1812F456`)
The binary performs all conversions explicitly:
- voltage raw = `data[1]<<8 | data[0]`; stored at `0x3FC98212`; engineering value = raw / 10.
- current raw = `data[3]<<8 | data[2]`, interpreted as signed 16-bit after construction.
- engineering current = raw / 10 - 400.
- one internal current value is clamped to 0 when negative.
- the negative-current magnitude is also converted back into the 0.1-A encoded form for another application/display path.

### CML (`0x1808F456`)
Four 16-bit fields are explicitly extracted:
- bytes 0..1 -> `0x3FC9820E`
- bytes 2..3 -> `0x3FC98210`
- bytes 4..5 -> `0x3FC98208`
- bytes 6..7 -> `0x3FC9820A`

The latter three are subsequently converted using the GB/T 0.1-unit / -400-offset convention where applicable. The raw byte pairs are also mirrored into `0x3FCA0AFC..0x3FCA0B03` for application use.

## 17. TX generator: exact periodic gates

The function at `0x4200BA6E` is the common message dispatcher. Before constructing a payload it zeroes an 8-byte local buffer and selects a payload constructor based on the CAN identifier.

The timing gates recovered from the executable are:

| ID | Message | Gate | Binary location |
|---|---|---:|---|
| `0x181056F4` | BCL | 50 ms | `0x4200BC4A` |
| `0x101956F4` | BST | 10 ms | `0x4200BD26` |
| `0x180256F4` | BRM | 250 ms | `0x4200BFB6` |
| `0x180656F4` | BCP | 500 ms | `0x4200BB10..0x4200BB56` |
| `0x100956F4` | BRO | 250 ms | `0x4200BB58..0x4200BB9E` |
| `0x181156F4` | BCS | 250 ms | `0x4200BBA4..0x4200BC12` |
| `0x181356F4` | BSM | 250 ms | `0x4200BBB0..0x4200BC12` |
| `0x181C56F4` | BSD | 250 ms | `0x4200BD68` |
| `0x081E56F4` | BEM | 250 ms | `0x4200BDCA` |
| `0x182756F4` | BHM | 250 ms after its initial gate | `0x4200BAD2..0x4200BC14` |

The exact CAN IDs and cycle times match the published GB/T message table. citeturn0search0turn0search5

## 18. Exact BCL constructor

At `0x4200BC4A` the payload length is exactly 5 bytes.

The first two bytes are selected from one of two 16-bit application globals, depending on a comparison against the currently received CCS/CML-related value. The selected 16-bit value is emitted little-endian.

The next 16-bit field is explicitly formed as:

`encoded = 0x0FA0 - internal_value`

and emitted little-endian.

Byte 4 is explicitly set to `0x01`.

Therefore the firmware's BCL wire format is:

`BCL = [target_voltage_L, target_voltage_H, target_current_L, target_current_H, 0x01]`

with the current field using the GB/T offset encoding. The precise semantic identity of the two source globals is being resolved against their writers in the next pass.

## 19. Exact fixed payloads already recovered

### BST (`0x101956F4`)
At `0x4200BD26`, DLC=4 and payload is exactly:

`40 00 40 00`

No dynamic payload bytes are used in this constructor.

### BCS (`0x181156F4`)
At `0x4200BBA4..0x4200BC12`, DLC=7. The current constructor emits the fixed portion:

`01 46 00 3C 00 00 10`

This is then transmitted after the 250-ms gate. The values correspond to the firmware's fixed/test operating limits; their final SPN names will be assigned only after correlating all writers and the standard table.

### BSD (`0x181C56F4`)
At `0x4200BD68`, DLC=7 and payload is exactly:

`5F 40 01 68 01 4A 4B`

This is not a guessed protocol frame: every byte is loaded as an immediate in the executable.

## 20. BRM/BCP/BRO/BEM remaining dynamic fields

The payload constructor uses the same common sender, but long messages are passed to the transport function rather than directly to TWAI as a single frame.

Confirmed from the constructor:
- BRM is a long message and enters the transport layer with PGN `0x0200`, source `0xF4`, destination `0x56`.
- BCP is a long message and enters the transport layer with PGN `0x0600`, source `0xF4`, destination `0x56`.
- BCS is a long message and is assembled into the transport buffer before transmission.
- The transport layer enforces a maximum long-message payload of approximately `0x6F0` bytes, consistent with the GB/T/J1939 transport range.

The binary therefore does not merely imitate the message IDs: it implements the expected long-message transport mechanism as executable state, including RTS/CTS/EOM handling.

## 21. Important correction to the previous state report

The state-7 timeout path at `0x4200C48C` transmits **BSD `0x181C56F4`**, not CSD. CSD is the charger-to-BMS frame `0x181DF456`, which is only observed in the RX parser. This is now treated as CONFIRMED throughout the reconstruction.

## 22. Current reconstruction status

**CONFIRMED:**
- 10-ms charging state scheduler.
- states 1..7 and their dispatch paths.
- charger RX filtering by SA/DA bytes.
- all charger-side IDs parsed by the firmware.
- BHM/BRM/BCP/BRO/BCL/BCS/BSM/BST/BSD/BEM transmit IDs.
- periodic timing gates for the principal BMS-originated messages.
- exact BST and BSD payloads.
- exact BCL payload length, mode byte and current-offset operation.
- exact CCS/CML arithmetic paths.

**NEXT:**
1. trace every writer of the BCL source globals;
2. reconstruct complete BCS/BSM dynamic payloads;
3. reconstruct BRM and BCP long-message byte arrays and transport metadata;
4. resolve termination/error flag writers;
5. then move directly to LCD/LVGL and CST816S.
