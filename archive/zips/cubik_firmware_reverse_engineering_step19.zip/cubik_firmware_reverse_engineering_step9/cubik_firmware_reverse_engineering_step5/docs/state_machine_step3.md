# Architecture recovery — Step 3
# GB/T charging state machine, timing and relay control

## 1. Major result

The function at application address:

```text
0x4200C078
```

is a central **GB/T charging state-machine/timing function**.

The state byte is:

```text
0x3FCA0B1D
```

because the code accesses:

```text
0x3FCA1 - 0x4E3 = 0x3FCA0B1D
```

The function explicitly dispatches states:

```text
0 = idle/reset
1
2
3
4
5
6
7
```

The exact semantic names below are based on the transition conditions and the GB/T messages emitted in each state.

---

# 2. Time base

The protocol timer function calls:

```c
function_B910(10);
```

on every active state-machine iteration.

`B910` adds its argument to an internal 16-bit timing accumulator.

Therefore the state machine operates on a **10 ms logical time quantum**.

This is important: constants such as:

```text
0x64    = 100
0x3E8   = 1000
0x1388  = 5000
0x2710  = 10000
```

can be interpreted directly as:

```text
100 ms
1 s
5 s
10 s
```

for the protocol timing logic.

This matches the expected GB/T 27930 timing domain.

---

# 3. Internal state variables

A key protocol structure begins at:

```text
0x3FC98200
```

Important recovered offsets:

| Address | Offset | Observed role |
|---|---:|---|
| `0x3FC98218` | +0x18 | CHM timestamp |
| `0x3FC9821C` | +0x1C | CRM timestamp |
| `0x3FC98220` | +0x20 | CTS timestamp |
| `0x3FC98224` | +0x24 | CML timestamp |
| `0x3FC98228` | +0x28 | CRO timestamp |
| `0x3FC9822C` | +0x2C | CCS timestamp |
| `0x3FC98230` | +0x30 | CST timestamp |
| `0x3FC98234` | +0x34 | CSD timestamp |
| `0x3FC98238` | +0x38 | CEM timestamp |
| `0x3FC9823C` | +0x3C | CRM confirmation/status byte |
| `0x3FC98208` | +0x08 | state-machine elapsed counter |
| `0x3FC9820C` | +0x0C | BRM/vehicle data-related value |
| `0x3FC98210` | +0x10 | charging/current-related value |
| `0x3FC9821?` | nearby | additional protocol values |
| `0x3FCA0B1D` | global | **main GB/T state** |
| `0x3FCA0B13` | global | transport/substate |
| `0x3FCA0B20` | global | protocol error/flag |
| `0x3FCA0B24` | global | protocol status/flag |

The exact C structure layout will be reconstructed later after all read/write references are collected.

---

# 4. State 0 — idle / reset

State 0 is the resting state.

When the protocol is reset, the firmware clears major timestamps and protocol variables.

Observed reset operations include:

```c
state = 0;
elapsed = 0;
selected protocol counters = 0;
transport substate = 0;
```

The state machine can return here after completion/error handling.

### Semantic confidence

**HIGH**

This is the only state with no active charging-message scheduling and acts as the reset point.

---

# 5. State 1 — initialization / handshake preparation

When state 1 is entered:

```c
state = 2;
state_entry_timestamp = now;
```

and protocol variables such as CRM/CTS/CML state are cleared.

Therefore state 1 is extremely short-lived and functions as the **initialization transition into the handshake phase**.

### Semantic name

```text
HANDSHAKE_INIT
```

### Confidence

**HIGH**

---

# 6. State 2 — wait for charger recognition

State 2 sends the BMS handshake/vehicle recognition sequence.

The firmware transmits:

```text
0x182756F4  BHM
```

and:

```text
0x180256F4 / BRM
```

through the multi-frame path when appropriate.

The binary also explicitly checks:

```c
protocol_status == 0xAA
```

at:

```text
0x3FC9823C
```

This is the CRM recognition result.

The CRM standard value is:

```text
0xAA = charger/BMS recognition successful
```

So state 2 is the **identification/handshake state**.

### Important timeout

The state-machine code uses a:

```text
~1 second
```

timeout path for waiting on the charger handshake before retransmission/error handling.

The precise retry policy is implemented in the surrounding state/timer code and will be documented separately.

### Semantic name

```text
WAIT_CRM / IDENTIFICATION
```

### Confidence

**HIGH**

---

# 7. State 3 — parameter configuration

State 3 contains a direct transmission of:

```text
0x180656F4
BCP
```

This is the BMS Charging Parameter configuration packet and is sent through the GB/T multi-frame transport mechanism.

The state then waits for the charger-side parameter/capability information.

The code requires relevant timestamp fields to have been populated before advancing.

The observed fields are:

```text
0x3FC98220 -> CTS timestamp
0x3FC98224 -> CML timestamp
```

So the firmware is explicitly tracking charger capability/configuration messages.

### Semantic name

```text
PARAMETER_CONFIGURATION
```

### Confidence

**HIGH**

---

# 8. State 4 — BMS ready / charger ready phase

State 4 executes:

```c
GPIO6 = LOW;
```

through the dedicated GPIO helper in some transition paths and sends:

```text
0x100956F4
BRO
```

with:

```text
data[0] = 0xAA
```

The exact code is:

```text
jal GPIO6_LOW helper
substate = 3
send ID 0x100956F4
```

The firmware then waits for:

```text
CRO
0x100AF456
```

with the expected:

```text
0xAA
```

recognition/ready value.

### Semantic name

```text
READY
```

or more precisely:

```text
BMS_READY_WAIT_CRO
```

### Confidence

**HIGH**

---

# 9. State 5 — active charging

This is the most important state.

The firmware repeatedly sends:

```text
BCL  0x181056F4
BSM  0x181356F4
BCS  0x181156F4
```

This is the actual charging loop.

The standard timing is consistent with:

```text
BCL ≈ 50 ms
BSM ≈ 250 ms
BCS ≈ 250 ms
CCS received ≈ 50 ms
```

The firmware's internal scheduling code maintains separate timestamps/counters for these messages.

---

# 10. Direct relay control during charging

A particularly important piece occurs in state 5.

The firmware waits approximately:

```text
0x2710 = 10000 ms = 10 seconds
```

after the relevant state-entry event.

Then, if the transport/protocol substate is:

```text
3
```

it executes:

```text
GPIO6 = LOW
GPIO7 = HIGH
```

via:

```text
0x4200C2FA -> 0x4200C882 -> GPIO6 LOW
0x4200C2FC -> 0x4200C894 -> GPIO7 HIGH
```

and changes the substate:

```text
3 -> 4
```

This is a **direct firmware-proven relay sequence**, not an inference.

Therefore:

```text
GPIO6 = 0
GPIO7 = 1
```

is the state of the two outputs after the firmware's delayed charging transition.

This is one of the most important pieces for reproducing the power-stage control.

---

# 11. State 6 — controlled charging termination

State 6 is reached after the charging phase determines that termination is required.

It sends:

```text
BCL 0x181056F4
```

while the termination procedure is being completed.

The firmware contains a counter at:

```text
0x3FCA0B1C
```

that is compared against:

```text
9
```

If the termination sequence has not completed, the BCL path is repeated.

Once the counter reaches the required threshold, the firmware constructs and transmits:

```text
BST
0x101956F4
```

with the termination-related data.

It then waits approximately:

```text
1 second
```

before advancing toward the final state.

### Semantic name

```text
STOP_CHARGING
```

### Confidence

**HIGH**

---

# 12. State 7 — post-stop / error-completion phase

State 7 waits for a further completion condition.

A timeout of:

```text
0x1388 = 5000 ms
```

is used.

After this path the firmware can transmit:

```text
BEM
0x081E56F4
```

when the appropriate error/termination conditions are present.

It also tracks:

```text
CSD
0x181CF456 / 0x181C56F4
```

and other completion timestamps.

The exact distinction between:

```text
normal completion
vs
error completion
```

is still being separated in the next pass because both use parts of the same state machine.

### Current semantic name

```text
FINALIZE / ERROR-CHECK
```

### Confidence

**MEDIUM-HIGH**

---

# 13. Reconstructed state diagram

At this stage the best executable-backed reconstruction is:

```text
                    ┌───────────────┐
                    │      0        │
                    │     IDLE      │
                    └───────┬───────┘
                            │ start/reset
                            ▼
                    ┌───────────────┐
                    │      1        │
                    │ HANDSHAKE_INIT│
                    └───────┬───────┘
                            │
                            ▼
                    ┌───────────────┐
                    │      2        │
                    │ WAIT CRM/BRM   │
                    └───────┬───────┘
                            │ CRM=AA
                            ▼
                    ┌───────────────┐
                    │      3        │
                    │ PARAMETER CFG  │
                    └───────┬───────┘
                            │ CML/CTS conditions
                            ▼
                    ┌───────────────┐
                    │      4        │
                    │     READY      │
                    │    BRO/CRO     │
                    └───────┬───────┘
                            │ CRO=AA
                            ▼
                    ┌───────────────┐
                    │      5        │
                    │   CHARGING     │
                    │ BCL/BSM/BCS    │
                    └───────┬───────┘
                            │ stop/error
                            ▼
                    ┌───────────────┐
                    │      6        │
                    │ STOP CHARGING  │
                    │     BST        │
                    └───────┬───────┘
                            │
                            ▼
                    ┌───────────────┐
                    │      7        │
                    │   FINALIZE     │
                    └───────┬───────┘
                            │
                            ▼
                    ┌───────────────┐
                    │      0        │
                    │     IDLE      │
                    └───────────────┘
```

This diagram will be refined as the remaining RX transition code and error paths are reconstructed.

---

# 14. Important timing constants recovered

| Constant | Decimal | Protocol meaning |
|---:|---:|---|
| `0x64` | 100 | 100 ms |
| `0x3E8` | 1000 | 1 s |
| `0x1388` | 5000 | 5 s |
| `0x2710` | 10000 | 10 s |
| `0x32` | 50 | 50 ms |
| `0xC8` | 200 | 200 ms |
| `0x1F4` | 500 | 500 ms |

The values are used in different sub-functions, so they should not all be interpreted as
identical timeout types. Some are message scheduling intervals and some are watchdog limits.

---

# 15. Direct relay API reconstruction

The original firmware's wrappers are now fully clear:

```c
static inline void relay6_low(void)
{
    gpio_set_level(6, 0);
}

static inline void relay6_high(void)
{
    gpio_set_level(6, 1);
}

static inline void relay7_low(void)
{
    gpio_set_level(7, 0);
}

static inline void relay7_high(void)
{
    gpio_set_level(7, 1);
}
```

The wrappers are called from the protocol state machine.

Known direct transitions:

```text
Initialization:
    GPIO6 = 0
    GPIO7 = 0

Charging transition:
    GPIO6 = 0
    GPIO7 = 1
```

There is also an explicit GPIO6-high helper elsewhere in the application. Its exact state-machine call site is being mapped in the next GPIO/reference pass.

---

# 16. New understanding of the architecture

The Cubik is therefore structured approximately as:

```text
                       ┌─────────────────────┐
                       │       ESP32-C3      │
                       └──────────┬──────────┘
                                  │
          ┌───────────────────────┼───────────────────────┐
          │                       │                       │
          ▼                       ▼                       ▼
       CAN/TWAI               Timer/Time               GPIO
       250 kbit/s                10 ms                  6/7
          │                       │                       │
          └───────────┬───────────┘                       │
                      ▼                                   │
               GB/T state machine                         │
                      │                                   │
       ┌──────────────┼───────────────┐                   │
       │              │               │                   │
       ▼              ▼               ▼                   ▼
     RX parser     TX scheduler    timeout logic       relays
       │              │
       ▼              ▼
 Charger frames     BMS frames
```

The display/BLE/ADC subsystems are not the core charging control loop; they are parallel
application subsystems.

---

# 17. What is now confirmed versus inferred

### CONFIRMED

- main GB/T state variable address: `0x3FCA0B1D`
- states 0..7 are explicitly compared
- 10 ms timing quantum in the state-machine path
- BHM transmission
- BRM transmission
- BCP transmission
- BRO transmission
- BCL transmission
- BSM transmission
- BCS transmission
- BST transmission
- BEM transmission
- CRO/CRM/CML/CTS/CCS/CST/CSD/CEM timestamps
- GPIO6/7 are directly controlled by state logic
- GPIO6 LOW + GPIO7 HIGH occurs after a 10-second charging-state delay

### HIGH CONFIDENCE

- state 0 = idle
- state 1 = initialization
- state 2 = identification/handshake
- state 3 = parameter configuration
- state 4 = ready
- state 5 = charging
- state 6 = stopping
- state 7 = finalization/error

### STILL TO PROVE

- every exact transition trigger
- exact meaning of every substate
- exact BCL/BMS/BCS repetition timers
- exact GPIO6-HIGH condition
- all fault paths
- exact relationship between CST/CSD/BST/BEM and state 6/7
- complete payload generation for every message

---

# 18. Next recovery target

The next pass should NOT move to the display yet.

The next target is the **GB/T RX parser from `0x4200C4A8` through `0x4200C7E2`**, combined with the state machine.

That will let us prove:

```text
received CAN frame
       ↓
which internal variable changes
       ↓
which timer is started
       ↓
which state changes
       ↓
which relay changes
       ↓
which outgoing CAN message follows
```

After that we can reconstruct the complete GB/T sequence as executable pseudocode.

Only then will we move to:
- LCD/LVGL,
- touch,
- BLE,
- ADC,
- PWM,
- NVS,
- bootloader/partition configuration,
- and finally a full file-by-file replacement project.
