# Evidence map

All offsets below are relative to application code segment 3 loaded at 0x42000020.

- 0x8A96: I2C configuration and driver installation.
  SDA=1, SCL=8, master, pull-ups enabled, 100000 Hz.
- 0x898E: low-level I2C register transaction helper.
  Device address is hard-coded to 0x15.
- 0x89CA: touch reader.
  Reads register 0x02 and then 0x03..0x06 for X/Y.
- 0x8B82: LCD main initialization.
- 0x8BE0..0x8C98: SPI bus and LCD panel-I/O configuration.
  Bus: MOSI=5, MISO=-1, SCLK=19.
  Panel IO: CS=4, DC=18, mode=0, pclk=20 MHz, queue=10, command/parameter=8/8.
- 0x8CE4: ILI9341 panel constructor path.
- 0xC80E: GPIO2/6/7 output initialization.
- 0xC834..0xC846: initial output levels:
  GPIO6=0, GPIO7=0, GPIO2=1.
- 0xC850 / 0xC862: GPIO6 HIGH / LOW.
- 0xC874 / 0xC886: GPIO7 HIGH / LOW.
- 0xB916: TWAI/CAN configuration copied from the global config at 0x3C0F7578.
  TX=10, RX=9.
- 0xCF7C: LEDC/PWM initialization.
  Channel config explicitly uses GPIO3; timer is 60 kHz / 10-bit.
- 0xD00E: ADC one-shot initialization.
  Channel 0 is used; on ESP32-C3 ADC1_CH0 is GPIO0.
